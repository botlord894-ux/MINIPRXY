# OmniProxy implementation audit (this pass)

## Files changed

- `app/src/main/java/com/omniproxy/app/appearance/Appearance.kt` — added a persistent built-in wallpaper key.
- `app/src/main/java/com/omniproxy/app/appearance/AppearanceStore.kt` — schema version, load-time normalization, safe bounds and allow-list validation, and a single SharedPreferences snapshot write.
- `app/src/main/java/com/omniproxy/app/appearance/Resolver.kt` — bundled wallpapers participate in photo contrast/scrim logic.
- `app/src/main/java/com/omniproxy/app/ui/components/OmniBackground.kt` — renders bundled wallpaper resources offline with the existing fit, colour adjustment, and overlay path.
- `app/src/main/java/com/omniproxy/app/ui/screens/studio/StudioBackgroundTab.kt` — five bundled wallpaper choices; selecting a photo clears the bundled resource and vice versa.
- `app/src/main/java/com/omniproxy/app/ui/screens/studio/ThemeStudioScreen.kt` and `StudioThemeTab.kt` — custom theme create/rename/duplicate/delete edits stay in the draft until Apply rather than writing from those controls immediately.
- `app/src/main/java/com/omniproxy/app/ui/OmniApp.kt` — navigation height is clamped to 80–120 dp at render time.
- `app/src/main/java/com/omniproxy/app/TransportSecurity.kt` and `ui/screens/PrivacyScreen.kt` — typed transport-security status; current proxy path honestly reports unknown TLS negotiation and distinguishes it from HTTPS to destinations.
- `app/src/test/java/com/omniproxy/app/AppearanceTest.kt` and `VpnStateMachineTest.kt` — added deterministic tests for sanitation, wallpaper allow-listing, stale connection attempts, and unexpected tunnel loss.
- `.github/workflows/build.yml` — unit tests now block the workflow on failure and run before APK assembly.
- `app/src/main/res/drawable-nodpi/wallpaper_*.jpg` — five optimized, bundled, offline abstract wallpapers.
- `README.md` — documents these changes and limitations.

## Verification available in this environment

- ZIP structure and source files were inspected.
- Resource references were cross-checked against the five added image files.
- A local Android build/test was **not run**: this environment has Java 21 but no Gradle executable/wrapper, no Android SDK (`android.jar`), and the source ZIP contains no Gradle wrapper. Therefore no successful compile, test result, APK, emulator test, or physical-device test is claimed.

## Remaining limitations

- The liquid orb still uses Canvas gradients/highlights and organic geometry. It does **not** implement true background refraction or a runtime distortion shader.
- TLS negotiation is not exposed by the current SOCKS5/HTTP transport. The UI reports unknown rather than claiming TLS 1.3. The upstream phone-to-proxy transport remains unencrypted in the current implementation.
- The existing proxy engine does not provide simultaneous independent per-app outbound IPs. sing-box integration is not implemented in this pass.
- Connection-state behavior has deterministic unit tests added, but real service cancellation, native startup/shutdown, and device lifecycle behavior still require an Android build and device/server testing.
- Adaptive two-column Theme Studio layout, exhaustive small-screen/landscape/large-font Compose UI tests, automated visual clipping checks, and measured performance profiling are not completed.
- Existing custom-photo import and cache handling remain largely as before; no full image lifecycle/reference-counting audit was possible through a build/device test.
