package com.omniproxy.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class VpnStateMachineTest {
    @Test fun duplicateEquivalentConnectIsRejected() {
        val m = VpnStateMachine()
        assertTrue(m.tryBeginConnect("profile-a", false) > 0)
        assertEquals(-1, m.tryBeginConnect("profile-a", false))
    }

    @Test fun staleAttemptCannotMarkConnectionConnected() {
        val m = VpnStateMachine()
        val old = m.tryBeginConnect("old", false)
        m.beginDisconnect()
        m.finishDisconnect()
        val current = m.tryBeginConnect("current", false)
        assertFalse(m.connected(old))
        assertTrue(m.connected(current))
        assertEquals(VpnPhase.CONNECTED, m.phase.value)
    }

    @Test fun unexpectedTunnelLossMovesConnectedStateToFailed() {
        val m = VpnStateMachine()
        val id = m.tryBeginConnect("profile", false)
        assertTrue(m.connected(id))
        assertTrue(m.reconcile(false))
        assertEquals(VpnPhase.FAILED, m.phase.value)
    }
}
