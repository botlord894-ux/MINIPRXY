package com.omniproxy.app

import com.omniproxy.app.appearance.*
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

/** Pure-Kotlin checks (no Android needed). They cover the readability rules and the preset data. */
class AppearanceTest {

    @Test fun everyPresetKeepsTextReadable() {
        for (t in Presets.themes) {
            val r = Resolver.resolve(Appearance(themeId = t.id, palette = t.palette))
            val cardOnBg = ColorUtils.composite(r.palette.card, r.cardAlpha, r.palette.bg)
            assertTrue("${t.name}: text on card", ColorUtils.contrast(r.palette.text, cardOnBg) >= 4.5f)
            assertTrue("${t.name}: text on background", ColorUtils.contrast(r.palette.text, r.palette.bg) >= 4.5f)
        }
    }

    @Test fun unreadableCustomTextIsFixedWithoutChangingTheSavedPalette() {
        val bad = Presets.OMNI.copy(text = Presets.OMNI.bg) // text same colour as background
        val a = Appearance(themeId = "custom", palette = bad)
        val r = Resolver.resolve(a)
        assertTrue(ColorUtils.contrast(r.palette.text, bad.bg) >= 4.5f)
        assertEquals(bad.text, a.palette.text) // stored value untouched
    }

    @Test fun lightBackgroundIsDetected() {
        val light = Presets.themes.first { it.id == "light" }
        assertTrue(Resolver.resolve(Appearance(palette = light.palette)).light)
        assertTrue(!Resolver.resolve(Appearance()).light)
    }

    @Test fun photoBackgroundGetsAScrimAndFirmCards() {
        val bright = Appearance(bg = BackgroundSpec(mode = BgMode.IMAGE, imageFile = "bg_1.jpg", imageLum = 0.95f))
        val r = Resolver.resolve(bright)
        assertTrue(r.cardAlpha >= 0.72f)
        assertTrue(Resolver.scrims(bright).isNotEmpty()) // a bright photo under a dark theme gets an automatic dark scrim
        assertTrue(ColorUtils.contrast(r.palette.text, ColorUtils.gray(r.bgLum)) >= 4.5f)
        val light = Presets.themes.first { it.id == "light" }
        val dark = Appearance(palette = light.palette, bg = BackgroundSpec(mode = BgMode.IMAGE, imageFile = "bg_1.jpg", imageLum = 0.05f))
        assertTrue(ColorUtils.contrast(Resolver.resolve(dark).palette.text, ColorUtils.gray(Resolver.resolve(dark).bgLum)) >= 4.5f)
    }

    @Test fun hexParsing() {
        assertEquals(0xFF6C2EFF.toInt(), ColorUtils.parseHex("#6C2EFF"))
        assertEquals(0xFF6C2EFF.toInt(), ColorUtils.parseHex("6c2eff"))
        assertNull(ColorUtils.parseHex("#12345"))
        assertNull(ColorUtils.parseHex("#GGGGGG"))
        assertEquals("#6C2EFF", ColorUtils.hex(0xFF6C2EFF.toInt()))
    }

    @Test fun presetsAreCompleteAndDefaultsAreProtected() {
        assertEquals(10, Presets.themes.size)
        assertTrue(Presets.themes.all { it.builtIn })
        assertEquals(8, Presets.liquids.size)
        assertEquals(8, Presets.gradients.size)
        assertNotNull(Presets.themes.firstOrNull { it.id == "omni_purple" })
        assertEquals("Omni Purple", Appearance().themeName)
    }

    @Test fun invalidAppearanceValuesAreClampedBeforeRendering() {
        val unsafe = Appearance(
            themeId = "not-a-theme",
            bg = BackgroundSpec(imageFile = "../../secrets", bundledWallpaper = "unknown", overlay = 4f, scale = 99f),
            liquid = LiquidStyle(size = -20f, posX = 8f, speed = 20f),
            nav = NavStyle(height = 20f),
            button = ButtonStyle(height = 1f),
            card = CardStyle(alpha = 4f)
        )
        val safe = AppearanceStore.sanitize(unsafe)
        assertEquals("omni_purple", safe.themeId)
        assertNull(safe.bg.imageFile)
        assertNull(safe.bg.bundledWallpaper)
        assertEquals(0.95f, safe.bg.overlay, 0.001f)
        assertEquals(3f, safe.bg.scale, 0.001f)
        assertEquals(48f, safe.liquid.size, 0.001f)
        assertEquals(1f, safe.liquid.posX, 0.001f)
        assertEquals(3f, safe.liquid.speed, 0.001f)
        assertEquals(80f, safe.nav.height, 0.001f)
        assertEquals(48f, safe.button.height, 0.001f)
        assertEquals(1f, safe.card.alpha, 0.001f)
    }

    @Test fun builtInWallpaperIdsAreAllowlisted() {
        assertTrue("midnight" in AppearanceStore.BUILT_IN_WALLPAPERS)
        assertTrue("dark_technology" in AppearanceStore.BUILT_IN_WALLPAPERS)
        assertTrue("../midnight" !in AppearanceStore.BUILT_IN_WALLPAPERS)
    }

    @Test fun staleVpnConnectionResultsCannotOverrideNewerAttempt() {
        val machine = VpnStateMachine()
        val old = machine.tryBeginConnect("old", false)
        assertTrue(old > 0)
        assertTrue(machine.beginDisconnect())
        machine.finishDisconnect()
        val fresh = machine.tryBeginConnect("fresh", false)
        assertTrue(fresh > old)
        assertTrue(!machine.connected(old))
        assertTrue(machine.connected(fresh))
        assertEquals(VpnPhase.CONNECTED, machine.phase.value)
    }

    @Test fun transportSecurityNeverClaimsTlsWithoutVerification() {
        val info = TransportSecurityInfo.forCurrentProxy()
        assertEquals(TransportSecurityStatus.ENCRYPTION_UNKNOWN, info.status)
        assertEquals("Encryption status unknown", info.title)
        assertNull(info.protocol)
    }

    @Test fun contrastRatioIsSane() {
        assertEquals(21f, ColorUtils.contrast(0xFFFFFFFF.toInt(), 0xFF000000.toInt()), 0.1f)
        assertEquals(1f, ColorUtils.contrast(0xFF123456.toInt(), 0xFF123456.toInt()), 0.001f)
    }
}
