package hev.htproxy

/**
 * Thin wrapper around the native tun2socks core (hev-socks5-tunnel).
 * The package + class name MUST stay hev.htproxy.TProxyService: the native
 * library registers its functions under exactly this name.
 */
object TProxyService {
    external fun TProxyStartService(config_path: String, fd: Int): Boolean
    external fun TProxyStopService(): Boolean
    external fun TProxyIsRunning(): Boolean
    /** [txPackets, txBytes, rxPackets, rxBytes] */
    external fun TProxyGetStats(): LongArray

    init {
        System.loadLibrary("hev-socks5-tunnel")
    }
}
