package com.omniproxy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

/** Route Rules: each app goes through one profile, or stays direct (outside the VPN). */
@Composable
fun RulesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val router = remember { StickyRouter(ctx) }
    val ver by StickyRouter.version.collectAsState()
    val sver by ServerStore.version.collectAsState()
    val servers = remember(sver) { SmartRouter.SERVERS }
    val rows = remember(ver, sver) {
        StickyRouter.PICKABLE_APPS.map { pkg -> pkg to router.get(pkg)?.ip }
    }
    var editing by remember { mutableStateOf<String?>(null) }
    var note by remember { mutableStateOf<String?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Route Rules", "Choose where each app connects.")
        note?.let { Spacer(Modifier.height(10.dp)); InfoBanner(it) }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            items(rows, key = { it.first }) { (pkg, ip) ->
                val server = servers.firstOrNull { it.host == ip }
                OmniCard(Modifier.fillMaxWidth(), onClick = { editing = pkg }) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        AppIcon(pkg, 42.dp); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(appName(ctx, pkg), color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text(
                                if (server != null) "${server.name}  ·  ${server.host}" else "Direct connection (not in the VPN)",
                                color = if (server != null) PurpleLight else TextSecondary, fontSize = 12.sp
                            )
                        }
                        Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary)
                    }
                }
            }
            item { InfoBanner("Apps that are not listed here always connect directly. OmniProxy never routes an app you did not choose.") }
        }
    }

    editing?.let { pkg ->
        val oldIp = router.get(pkg)?.ip
        AlertDialog(
            onDismissRequest = { editing = null }, containerColor = CardBg,
            title = { Text("Route ${appName(ctx, pkg)} via", color = Color.White) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    RuleOption("Direct connection", "Stays outside the VPN", oldIp == null) {
                        router.setDirect(pkg); editing = null; note = explain(oldIp, null)
                    }
                    servers.forEach { s ->
                        RuleOption(s.name, "${s.host}  ·  ${s.type.name}", oldIp == s.host) {
                            router.assignTo(pkg, s.host); editing = null; note = explain(oldIp, s.host)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

/** Says whether the change needs a reconnect, based on the session that is running right now. */
private fun explain(oldIp: String?, newIp: String?): String {
    val active = OmniVpnService.stickyIp.value
    return when {
        oldIp == newIp -> "No change."
        active != null && (active == oldIp || active == newIp) ->
            "Saved. This changes the running session, so reconnect it from Sticky Apps to apply the change."
        else -> "Saved. No reconnect is needed because that route is not running."
    }
}

@Composable
private fun RuleOption(title: String, sub: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .background(if (selected) Purple.copy(alpha = 0.25f) else Color(0xFF1B1830)).clickable(onClick = onClick).padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold)
            Text(sub, color = TextSecondary, fontSize = 12.sp)
        }
        if (selected) Text("Current", color = PurpleLight, fontSize = 12.sp)
    }
}
