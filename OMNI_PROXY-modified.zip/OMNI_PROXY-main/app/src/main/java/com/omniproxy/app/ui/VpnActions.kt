package com.omniproxy.app.ui

import com.omniproxy.app.TaskMode

/** What the screens can ask the activity to do (VPN permission lives in the activity). */
class VpnActions(
    val toggleMode: (TaskMode) -> Unit,
    val toggleSticky: (String) -> Unit,
    val disconnect: () -> Unit,
    val returnToOriginal: () -> Unit,
    val approveFailover: () -> Unit,
    val declineFailover: () -> Unit
)
