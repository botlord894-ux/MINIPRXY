package com.omniproxy.app.ui.screens.studio

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.*
import com.omniproxy.app.R
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private val IMAGE_MODES = setOf(BgMode.IMAGE, BgMode.IMAGE_DARK, BgMode.IMAGE_COLOR, BgMode.IMAGE_BLUR)

@Composable
fun BackgroundTab(draft: Appearance, upd: ((Appearance) -> Appearance) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val bg = draft.bg
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var colorEdit by remember { mutableStateOf<String?>(null) }

    // System photo picker: no storage permission needed. The photo is copied into the app's own storage.
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                val r = withContext(Dispatchers.IO) { BackgroundImages.import(ctx, uri) }
                busy = false
                if (r == null) error = "That image could not be read. Try another one."
                else {
                    error = null; AppearanceStore.imageMissing = false
                    upd { a -> a.copy(bg = a.bg.copy(imageFile = r.file, bundledWallpaper = null, imageLum = r.lum, imageAccent = r.accent,
                        mode = if (a.bg.mode in IMAGE_MODES) a.bg.mode else BgMode.IMAGE_DARK)) }
                }
            }
        }
    }
    fun pickPhoto() = picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))

    Column(Modifier.fillMaxWidth()) {
        SectionTitle("Background type")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            BgMode.values().forEach { m ->
                Chip(m.label, bg.mode == m) {
                    upd { a -> a.copy(bg = a.bg.copy(mode = m)) }
                    if (m in IMAGE_MODES && bg.imageFile == null && bg.bundledWallpaper == null) pickPhoto()
                }
            }
        }
        if (bg.mode in IMAGE_MODES && (bg.imageFile == null && bg.bundledWallpaper == null || (AppearanceStore.imageMissing && bg.imageFile != null && BackgroundImages.exists(ctx, bg.imageFile).not()))) {
            Spacer(Modifier.height(8.dp))
            InfoBanner("No usable photo is selected, so the original background is shown. Choose a photo below.", accent = Amber, icon = Icons.Filled.Warning)
        }
        error?.let { Spacer(Modifier.height(8.dp)); InfoBanner(it, accent = Danger, icon = Icons.Filled.Warning) }

        SectionTitle("Built-in wallpapers · works offline")
        val wallpapers = listOf(
            "midnight" to "Midnight", "deep_ocean" to "Deep Ocean",
            "northern_lights" to "Northern Lights", "abstract_glass" to "Abstract Glass",
            "dark_technology" to "Dark Technology"
        )
        wallpapers.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { (id, label) ->
                    val selected = bg.bundledWallpaper == id
                    Box(Modifier.weight(1f).height(74.dp).clip(RoundedCornerShape(14.dp))
                        .background(when (id) {
                            "deep_ocean" -> Brush.linearGradient(listOf(Color(0xFF020E1F), Color(0xFF00435B), Color(0xFF041736)))
                            "northern_lights" -> Brush.linearGradient(listOf(Color(0xFF020917), Color(0xFF00494E), Color(0xFF2C1656)))
                            "abstract_glass" -> Brush.linearGradient(listOf(Color(0xFF070712), Color(0xFF2C1859), Color(0xFF083749)))
                            "dark_technology" -> Brush.linearGradient(listOf(Color(0xFF04070E), Color(0xFF0C1B2A), Color(0xFF1E1232)))
                            else -> Brush.linearGradient(listOf(Color(0xFF040814), Color(0xFF111730), Color(0xFF221244)))
                        }).border(if (selected) 2.dp else 1.dp, if (selected) Purple else Border, RoundedCornerShape(14.dp))
                        .clickable { upd { a -> a.copy(bg = a.bg.copy(mode = BgMode.IMAGE_DARK, imageFile = null, bundledWallpaper = id, overlay = 0.2f)) } },
                        contentAlignment = Alignment.BottomStart) {
                        Text(label, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(8.dp))
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }
        SectionTitle("Pick a background")
        val gradients = Presets.gradients.entries.toList()
        (0..gradients.size).toList().chunked(3).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { idx ->
                    if (idx == 0) {
                        Box(Modifier.weight(1f).height(64.dp).clip(RoundedCornerShape(14.dp)).background(Surface2)
                            .border(1.dp, Border, RoundedCornerShape(14.dp)).clickable { if (!busy) pickPhoto() },
                            contentAlignment = Alignment.Center) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(Icons.Filled.AddPhotoAlternate, null, tint = PurpleLight)
                                Text(if (busy) "Loading…" else "Your photo", color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    } else {
                        val (id, v) = gradients[idx - 1].toPair()
                        val c = v.second
                        val sel = bg.mode == BgMode.GRADIENT && bg.gradientPreset == id
                        Box(Modifier.weight(1f).height(64.dp).clip(RoundedCornerShape(14.dp))
                            .background(Brush.linearGradient(listOf(Color(c.first), Color(c.second), Color(c.third))))
                            .border(if (sel) 2.dp else 1.dp, if (sel) Purple else Border, RoundedCornerShape(14.dp))
                            .clickable { upd { a -> a.copy(bg = a.bg.copy(mode = BgMode.GRADIENT, gradientPreset = id, gradA = c.first, gradB = c.second, gradC = c.third)) } },
                            contentAlignment = Alignment.BottomStart) {
                            Text(v.first, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(6.dp))
                        }
                    }
                }
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }

        when (bg.mode) {
            BgMode.DEFAULT -> Text("The original OmniProxy background: your theme color with a soft accent glow.", color = TextSecondary, fontSize = 12.sp)
            BgMode.SOLID -> { SectionTitle("Color"); ColorRow("Background color", bg.solid) { colorEdit = "solid" } }
            BgMode.GRADIENT, BgMode.ANIMATED -> {
                SectionTitle("Gradient colors")
                ColorRow("Start", bg.gradA) { colorEdit = "ga" }
                ColorRow("Middle", bg.gradB) { colorEdit = "gb" }
                ColorRow("End", bg.gradC) { colorEdit = "gc" }
            }
            else -> {
                SectionTitle("Image position")
                Row(Modifier.horizontalScroll(rememberScrollState())) {
                    ImageFit.values().forEach { f -> Chip(f.label, bg.fit == f) { upd { a -> a.copy(bg = a.bg.copy(fit = f)) } } }
                }
                if (bg.fit == ImageFit.SCALE) LabeledSlider("Scale", bg.scale, 0.5f..3f, { "%.1fx".format(it) }) { v -> upd { a -> a.copy(bg = a.bg.copy(scale = v)) } }
                SectionTitle("Adjust")
                if (bg.mode != BgMode.IMAGE) LabeledSlider("Overlay opacity", bg.overlay, 0f..0.9f, ::pct) { v -> upd { a -> a.copy(bg = a.bg.copy(overlay = v)) } }
                if (bg.mode == BgMode.IMAGE_COLOR || bg.mode == BgMode.IMAGE_BLUR) ColorRow("Overlay color", bg.overlayColor) { colorEdit = "ov" }
                if (bg.mode == BgMode.IMAGE_BLUR) LabeledSlider("Blur intensity", bg.blur, 0f..1f, ::pct) { v -> upd { a -> a.copy(bg = a.bg.copy(blur = v)) } }
                LabeledSlider("Brightness", bg.brightness, -0.5f..0.5f, { "${(it * 200).toInt()}%" }) { v -> upd { a -> a.copy(bg = a.bg.copy(brightness = v)) } }
                LabeledSlider("Saturation", bg.saturation, 0f..2f, { "${(it * 100).toInt()}%" }) { v -> upd { a -> a.copy(bg = a.bg.copy(saturation = v)) } }
                SwitchLine("Keep text readable", "Adds a light dark scrim and firmer cards over photos", bg.autoContrast) { v -> upd { a -> a.copy(bg = a.bg.copy(autoContrast = v)) } }
                if (bg.imageAccent != 0) {
                    Spacer(Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(28.dp).clip(RoundedCornerShape(8.dp)).background(Color(bg.imageAccent)))
                        Spacer(Modifier.width(10.dp))
                        Text("Color found in your photo", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        OmniOutlinedButton(onClick = {
                            upd { a ->
                                val c = a.bg.imageAccent
                                val np = a.palette.copy(accent = c, accent2 = ColorUtils.blend(c, 0xFFFFFFFF.toInt(), 0.35f),
                                    connect = c, connectGlow = ColorUtils.blend(c, 0xFFFFFFFF.toInt(), 0.2f))
                                var out = a.copy(palette = np, themeId = "custom")
                                if (a.liquid.autoHarmony && a.liquid.preset != "custom_liquid" && !a.liquid.adaptive)
                                    out = out.copy(liquid = AppearanceStore.harmonized(out.liquid, np))
                                out
                            }
                        }) { Text("Use as accent") }
                    }
                }
            }
        }
    }

    colorEdit?.let { which ->
        val initial = when (which) { "solid" -> bg.solid; "ga" -> bg.gradA; "gb" -> bg.gradB; "gc" -> bg.gradC; else -> bg.overlayColor }
        ColorPickerDialog("Choose color", initial, onDismiss = { colorEdit = null }) { c ->
            colorEdit = null
            upd { a ->
                a.copy(bg = when (which) {
                    "solid" -> a.bg.copy(solid = c)
                    "ga" -> a.bg.copy(gradA = c); "gb" -> a.bg.copy(gradB = c); "gc" -> a.bg.copy(gradC = c)
                    else -> a.bg.copy(overlayColor = c)
                })
            }
        }
    }
}
