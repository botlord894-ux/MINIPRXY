package com.omniproxy.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.Fmt
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.Quality
import com.omniproxy.app.QualityTest
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.launch

/** Raw measurements per server. There is deliberately no mystery score here; sort by what matters to you. */
@Composable
fun QualityScreen(onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var results by remember { mutableStateOf<List<Quality>?>(null) }
    var running by remember { mutableStateOf(false) }
    var speed by remember { mutableStateOf(false) }
    var sort by remember { mutableStateOf("Latency") }

    val sorted = results?.let { l ->
        when (sort) {
            "Loss" -> l.sortedBy { it.lossPct }
            "Speed" -> l.sortedByDescending { it.kbps ?: -1 }
            "Stability" -> l.sortedByDescending { ProfileStore.reliability(it.server)?.let { r -> r.first * 100 / r.second } ?: -1 }
            else -> l.sortedBy { it.avgMs ?: Int.MAX_VALUE }
        }
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Quality Test", "Measured, not guessed.")
        Spacer(Modifier.height(12.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Include speed test", color = Color.White, fontSize = 14.sp)
                Text("Downloads about 2 MB per server through the proxy", color = TextSecondary, fontSize = 11.sp)
            }
            Switch(checked = speed, onCheckedChange = { speed = it },
                colors = SwitchDefaults.colors(checkedTrackColor = Purple, checkedThumbColor = Color.White,
                    uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
        }
        Spacer(Modifier.height(10.dp))
        PrimaryButton(if (running) "Testing…" else "Run quality test") {
            if (!running) {
                running = true
                scope.launch { results = QualityTest.run(SmartRouter.SERVERS, speed); running = false }
            }
        }
        if (sorted != null) {
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Latency", "Loss", "Speed", "Stability").forEach { k -> Segment(k, sort == k, Modifier.weight(1f)) { sort = k } }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
            if (sorted == null) item { InfoBanner("Run the test to see latency, jitter, packet loss, speed and stability for each server.") }
            else {
                items(sorted) { q -> QualityCard(q) }
                item { InfoBanner("Loss is the share of TCP connection tests that got no answer. It is a simple proxy for packet loss, not a full packet-loss measurement.", accent = Amber) }
            }
        }
    }
}

@Composable
private fun QualityCard(q: Quality) {
    val rel = ProfileStore.reliability(q.server)
    val p = ProfileStore.get(q.server)
    OmniCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FlagBadge(q.server.country, 36.dp); Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(q.server.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("${q.server.host}:${q.server.port} · ${q.server.type.name}", color = TextSecondary, fontSize = 12.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            M("Latency", q.avgMs?.let { "$it ms" } ?: "No answer")
            M("Jitter", q.jitterMs?.let { "$it ms" } ?: "Not enough answers")
            M("Loss", "${q.lossPct}% (${q.ok} of ${q.sent} answered)")
            M("Speed", q.kbps?.let { Fmt.speed(it) } ?: "Not tested")
            M("Recent stability", rel?.let { "${it.first} of ${it.second} checks" } ?: "Not enough data")
            M("IP consistency", if (p.exitChecks >= 3) "${p.exitChanges} change(s) in ${p.exitChecks} checks" else "Not enough data")
            M("DNS", when (p.dns) { 1 -> "Working"; 0 -> "Failed"; else -> "Not tested" })
        }
    }
}

@Composable
private fun M(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp)
    }
}
