package com.omniproxy.app.ui.components

import android.provider.Settings
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.omniproxy.app.appearance.AppearanceStore

/** True while the app is visible. Animations pause when it goes to the background. */
@Composable
fun rememberStarted(): Boolean {
    val owner = LocalLifecycleOwner.current
    var started by remember { mutableStateOf(owner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED)) }
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            if (e == Lifecycle.Event.ON_START) started = true else if (e == Lifecycle.Event.ON_STOP) started = false
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }
    return started
}

/** Reduced motion: the app setting, or Android's "remove animations" (animator scale 0). */
@Composable
fun rememberReduceMotion(): Boolean {
    val ctx = LocalContext.current
    val systemOff = remember {
        try { Settings.Global.getFloat(ctx.contentResolver, Settings.Global.ANIMATOR_DURATION_SCALE, 1f) == 0f } catch (e: Exception) { false }
    }
    return AppearanceStore.current.reduceMotion || systemOff
}

suspend fun withFrameNanosCompat(): Long = androidx.compose.runtime.withFrameNanos { it }
