package com.omniproxy.app.ui.theme

import android.app.Activity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.appearance.ColorUtils

// Every colour is a getter that reads the active theme. Because the theme is Compose state, any
// composable that uses one of these updates automatically when the user changes the theme.
val Purple: Color get() = Color(AppearanceStore.palette.accent)
val PurpleLight: Color get() = Color(AppearanceStore.palette.accent2)
val Bg: Color get() = Color(AppearanceStore.palette.bg)
val Green: Color get() = Color(AppearanceStore.palette.connected)
val Cyan: Color get() = Color(AppearanceStore.palette.accent2)
val Amber: Color get() = Color(AppearanceStore.palette.warning)
val Danger: Color get() = Color(AppearanceStore.palette.error)
val CardBg: Color get() = Color(AppearanceStore.palette.card)
val Border: Color get() = Color(AppearanceStore.palette.border)
val TextPrimary: Color get() = Color(AppearanceStore.palette.text)
val TextSecondary: Color get() = Color(AppearanceStore.palette.textSecondary)

/** A slightly raised surface used for chips and list rows inside cards. */
val Surface2: Color get() = Color(ColorUtils.blend(AppearanceStore.palette.card, AppearanceStore.palette.accent, 0.12f))
/** Background of the selected navigation item. */
val NavSelectedBg: Color get() = Color(ColorUtils.blend(AppearanceStore.palette.nav, AppearanceStore.palette.navSelected, 0.22f))

@Composable
fun OmniTheme(content: @Composable () -> Unit) {
    val r = AppearanceStore.resolved
    val p = r.palette
    val scheme = if (r.light) lightColorScheme(
        primary = Color(p.accent), onPrimary = Color.White, background = Color(p.bg), onBackground = Color(p.text),
        surface = Color(p.card), onSurface = Color(p.text), surfaceVariant = Color(p.card), onSurfaceVariant = Color(p.textSecondary),
        outline = Color(p.border), error = Color(p.error)
    ) else darkColorScheme(
        primary = Color(p.accent), onPrimary = Color.White, background = Color(p.bg), onBackground = Color(p.text),
        surface = Color(p.card), onSurface = Color(p.text), surfaceVariant = Color(p.card), onSurfaceVariant = Color(p.textSecondary),
        outline = Color(p.border), error = Color(p.error)
    )
    val view = LocalView.current
    SideEffect {
        (view.context as? Activity)?.window?.let { w ->
            WindowCompat.getInsetsController(w, view).apply {
                isAppearanceLightStatusBars = r.light
                isAppearanceLightNavigationBars = r.light
            }
        }
    }
    MaterialTheme(colorScheme = scheme, content = content)
}
