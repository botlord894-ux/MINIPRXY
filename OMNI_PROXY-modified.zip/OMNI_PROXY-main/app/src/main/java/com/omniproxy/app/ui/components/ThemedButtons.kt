package com.omniproxy.app.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ButtonColors
import androidx.compose.material3.LocalContentColor
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.foundation.LocalIndication
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.unit.dp
import com.omniproxy.app.appearance.ButtonStyle
import com.omniproxy.app.appearance.ColorUtils
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ui.theme.*

fun buttonShapeOf(s: ButtonStyle): Shape = when (s.shape) {
    "pill" -> RoundedCornerShape(50)
    "square" -> RoundedCornerShape(2.dp)
    "custom" -> CutCornerShape(s.radius.coerceAtLeast(6f).dp)
    else -> RoundedCornerShape(s.radius.dp)
}

/**
 * The app's button. Shape, radius, height, colours, ripple, shadow and press animation come from the
 * personalization settings, so every screen stays consistent. Minimum touch target is 48dp.
 */
@Composable
fun OmniButton(
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    colors: ButtonColors? = null, // accepted so older call sites compile; the theme decides the colours
    secondary: Boolean = false,
    content: @Composable RowScope.() -> Unit
) {
    val s = AppearanceStore.current.button
    val shape = buttonShapeOf(s)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(if (pressed) 1f - 0.05f * s.animation else 1f, label = "btnPress")
    val variant = if (secondary && s.variant == "filled") "outlined" else s.variant
    val accent = Purple
    val container = when (variant) {
        "outlined" -> Color.Transparent
        "transparent" -> accent.copy(alpha = 0.16f)
        else -> accent
    }
    val onAccent = ColorUtils.readable(0xFFFFFFFF.toInt(), accent.toArgb()).let { Color(it) }
    val content0 = if (variant == "filled") onAccent else PurpleLight
    val alpha = if (enabled) 1f else 0.4f
    Box(
        modifier
            .scale(scale)
            .then(if (variant == "filled" && s.elevation > 0f) Modifier.shadow(s.elevation.dp, shape, clip = false) else Modifier)
            .heightIn(min = s.height.coerceAtLeast(48f).dp)
            .clip(shape)
            .background(container.copy(alpha = container.alpha * alpha))
            .then(if (variant == "outlined") Modifier.border(BorderStroke(1.5.dp, accent.copy(alpha = alpha)), shape) else Modifier)
            .clickable(
                interactionSource = interaction,
                indication = if (s.ripple) LocalIndication.current else null,
                enabled = enabled, role = Role.Button, onClick = onClick
            )
            .padding(horizontal = 20.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        CompositionLocalProvider(LocalContentColor provides content0.copy(alpha = alpha)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(s.spacing.dp), content = content)
        }
    }
}

/** Secondary button: outlined unless you chose a different style. */
@Composable
fun OmniOutlinedButton(onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, content: @Composable RowScope.() -> Unit) =
    OmniButton(onClick, modifier, enabled, null, secondary = true, content = content)

