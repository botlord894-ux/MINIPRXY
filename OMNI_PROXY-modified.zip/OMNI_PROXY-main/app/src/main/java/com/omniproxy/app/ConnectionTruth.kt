package com.omniproxy.app

import android.content.Context

enum class CheckStatus { PASS, WARN, FAIL, NOT_TESTED }
data class CheckResult(val title: String, val status: CheckStatus, val detail: String)

/** Runs real checks against one server and reports exactly what was and wasn't verified. Blocking. */
object ConnectionTruth {

    fun run(ctx: Context, server: ProxyServer): List<CheckResult> {
        val out = mutableListOf<CheckResult>()
        fun add(t: String, s: CheckStatus, d: String) { out += CheckResult(t, s, d) }
        val localOnly = ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE).getBoolean("local_only", false)

        // 1) VPN tunnel (state only, not a test)
        if (OmniVpnService.currentIp.value == server.host)
            add("VPN tunnel", CheckStatus.PASS, "Active through this server.")
        else add("VPN tunnel", CheckStatus.NOT_TESTED, "Not connected through this server right now.")

        // 2) Proxy reachable
        val ms = SmartRouter.pingMs(server)
        ProfileStore.recordPing(server, ms >= 0)
        if (ms < 0) {
            add("Proxy server", CheckStatus.FAIL, "No answer from ${server.host}:${server.port}.")
            for (t in listOf("Exit IP", "Expected country", "DNS", "IP reputation"))
                add(t, CheckStatus.NOT_TESTED, "Skipped because the server did not answer.")
            ProfileStore.recordTruth(server, -1, -1, -1, "")
            addTail(server, ::add)
            HistoryStore.add(server.name, "Connection test: server unreachable")
            return out
        }
        add("Proxy server", CheckStatus.PASS, "Reachable, $ms ms.")

        // 3) Exit IP as the internet sees it
        var countryOk = -1; var dns = -1; var rep = ""
        val info = ExitProbe.probe(server)
        if (info == null) {
            add("Exit IP", CheckStatus.FAIL,
                "Could not read the exit IP. The login may be wrong, the proxy may block HTTPS, or ipinfo.io may be rate-limiting.")
            add("Expected country", CheckStatus.NOT_TESTED, "Needs the exit IP.")
            add("DNS", CheckStatus.NOT_TESTED, "Needs a successful request through the proxy.")
            add("IP reputation", CheckStatus.NOT_TESTED, "Needs the exit IP.")
            dns = 0
        } else {
            val changed = ProfileStore.recordExit(server, info)
            if (changed) HistoryStore.add(server.name, "IP change detected: now ${info.ip}")
            val prof = ProfileStore.get(server)
            val where = listOfNotNull(info.city, info.country).joinToString(", ")
            val base = info.ip + (if (where.isNotEmpty()) " ($where)" else "") + (info.org?.let { " - $it" } ?: "")
            when {
                prof.alertNew != null -> add("Exit IP", CheckStatus.WARN, "$base. Differs from your locked IP ${prof.alertOld}.")
                changed -> add("Exit IP", CheckStatus.WARN, "$base. Changed since the last test.")
                else -> add("Exit IP", CheckStatus.PASS, "$base. This is the IP websites see, which can differ from the server address.")
            }
            val expected = server.country.uppercase()
            when {
                expected.length != 2 -> add("Expected country", CheckStatus.NOT_TESTED, "No country is set for this server.")
                info.country.equals(expected, true) -> { countryOk = 1; add("Expected country", CheckStatus.PASS, "Matched ($expected).") }
                else -> { countryOk = 0; add("Expected country", CheckStatus.WARN, "Expected $expected but the exit IP is in ${info.country ?: "an unknown country"}.") }
            }
            dns = 1
            add("DNS", CheckStatus.PASS,
                "The proxy resolved ipinfo.io itself, so that lookup did not come from your phone. One successful lookup does not prove every app is leak-free.")
            if (localOnly) {
                add("IP reputation", CheckStatus.NOT_TESTED, "Skipped: Local-Only Mode is on.")
            } else when (StickyRouter(ctx).checkIpReputation(info.ip)) {
                Reputation.CLEAN -> { rep = "CLEAN"; add("IP reputation", CheckStatus.PASS, "Not flagged as Tor by ipinfo.io. This is a limited free check, not a full blacklist lookup.") }
                Reputation.BANNED -> { rep = "BANNED"; add("IP reputation", CheckStatus.FAIL, "ipinfo.io flags this IP (Tor exit).") }
                Reputation.UNKNOWN -> { rep = "UNKNOWN"; add("IP reputation", CheckStatus.NOT_TESTED, "Could not be checked.") }
            }
        }
        ProfileStore.recordTruth(server, ms, countryOk, dns, rep)
        addTail(server, ::add)
        HistoryStore.add(server.name, "Connection test run")
        return out
    }

    private fun addTail(server: ProxyServer, add: (String, CheckStatus, String) -> Unit) {
        val last = HistoryStore.list().firstOrNull { it.profile == server.name && it.text == "Proxy unreachable" }
        when {
            !HistoryStore.enabled() -> add("Last interruption", CheckStatus.NOT_TESTED, "Connection history is turned off.")
            last == null -> add("Last interruption", CheckStatus.PASS, "None recorded in your history.")
            else -> add("Last interruption", CheckStatus.WARN, "${Fmt.ago(last.time)}.")
        }
        add("App routing", CheckStatus.NOT_TESTED, "Android places the chosen apps in the tunnel, but this report does not test each app.")
    }
}
