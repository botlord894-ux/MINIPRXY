package com.omniproxy.app.appearance

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/**
 * Single source of truth for personalization. [current] and [resolved] are Compose state, so any
 * composable that reads a colour (via the getters in Theme.kt) updates automatically when they change.
 * Saved as JSON in SharedPreferences (the project's existing storage), so it survives restarts.
 */
object AppearanceStore {
    val BUILT_IN_WALLPAPERS = setOf("midnight", "deep_ocean", "northern_lights", "abstract_glass", "dark_technology")
    private var prefs: SharedPreferences? = null
    private const val SCHEMA_VERSION = 2

    var current by mutableStateOf(Appearance())
        private set
    var resolved by mutableStateOf(Resolver.resolve(Appearance()))
        private set

    /** True when the saved background image could not be loaded (we show a safe fallback instead). */
    var imageMissing by mutableStateOf(false)

    val palette: Palette get() = resolved.palette

    fun init(ctx: Context) {
        if (prefs != null) return
        val p = ctx.applicationContext.getSharedPreferences("appearance", Context.MODE_PRIVATE)
        prefs = p
        val loaded = p.getString("json", null)?.let { runCatching { fromJson(JSONObject(it)) }.getOrNull() } ?: Appearance()
        val a = sanitize(loaded)
        current = a
        resolved = Resolver.resolve(a)
        if (a != loaded || p.getInt("schemaVersion", 1) < SCHEMA_VERSION) {
            p.edit().putString("json", toJson(a).put("schemaVersion", SCHEMA_VERSION).toString()).putInt("schemaVersion", SCHEMA_VERSION).apply()
        }
    }

    /** Make [a] the active look and save it. */
    fun apply(a: Appearance) {
        val safe = sanitize(a)
        current = safe
        resolved = Resolver.resolve(safe)
        prefs?.edit()?.putString("json", toJson(safe).put("schemaVersion", SCHEMA_VERSION).toString())?.putInt("schemaVersion", SCHEMA_VERSION)?.apply()
    }

    /** Clamp persisted user-controlled values and reject invalid resource references before rendering. */
    fun sanitize(a: Appearance): Appearance {
        val b = a.bg
        val l = a.liquid
        val n = a.nav
        return a.copy(
            themeId = a.themeId.takeIf { id -> id == "custom" || Presets.themes.any { it.id == id } || a.customThemes.any { it.id == id } } ?: "omni_purple",
            bg = b.copy(
                bundledWallpaper = b.bundledWallpaper?.takeIf { it in BUILT_IN_WALLPAPERS },
                imageFile = b.imageFile?.takeIf { it.matches(Regex("bg_[0-9]+\\.jpg")) },
                scale = b.scale.coerceIn(0.5f, 3f), overlay = b.overlay.coerceIn(0f, 0.95f),
                blur = b.blur.coerceIn(0f, 1f), brightness = b.brightness.coerceIn(-0.5f, 0.5f),
                saturation = b.saturation.coerceIn(0f, 2f)
            ),
            liquid = l.copy(transparency = l.transparency.coerceIn(0f, 1f), speed = l.speed.coerceIn(0f, 3f),
                movement = l.movement.coerceIn(0f, 2f), deformation = l.deformation.coerceIn(0f, 2f),
                size = l.size.coerceIn(48f, 320f), floatSize = l.floatSize.coerceIn(48f, 180f),
                posX = l.posX.coerceIn(0f, 1f), posY = l.posY.coerceIn(0f, 1f)),
            nav = n.copy(height = n.height.coerceIn(80f, 120f), bgAlpha = n.bgAlpha.coerceIn(0f, 1f)),
            button = a.button.copy(height = a.button.height.coerceIn(48f, 96f), radius = a.button.radius.coerceIn(0f, 48f)),
            card = a.card.copy(alpha = a.card.alpha.coerceIn(0f, 1f), radius = a.card.radius.coerceIn(0f, 48f))
        )
    }

    /** Custom-theme edits are saved right away (they are not part of the draft). */
    fun setCustomThemes(list: List<ThemeEntry>) = apply(current.copy(customThemes = list))

    fun resetAll(ctx: Context) {
        BackgroundImages.cleanup(ctx, null)
        imageMissing = false
        apply(Appearance(customThemes = current.customThemes)) // your own saved themes are kept
    }

    fun allThemes(a: Appearance): List<ThemeEntry> = Presets.themes + a.customThemes

    /** Switch palette. Non-custom liquid colours follow the theme only if Automatic harmony is on. */
    fun withTheme(a: Appearance, e: ThemeEntry): Appearance {
        var out = a.copy(themeId = e.id, palette = e.palette)
        if (a.liquid.autoHarmony && a.liquid.preset != "custom_liquid" && !a.liquid.adaptive)
            out = out.copy(liquid = harmonized(out.liquid, e.palette))
        return out
    }

    fun harmonized(l: LiquidStyle, p: Palette) =
        l.copy(color1 = p.connect, color2 = ColorUtils.hueShift(p.connect, 35f), glow = p.connectGlow)

    // ---------------- JSON ----------------
    private fun Palette.json() = JSONObject().put("bg", bg).put("bg2", bg2).put("card", card).put("accent", accent)
        .put("accent2", accent2).put("connect", connect).put("glow", connectGlow).put("text", text)
        .put("sec", textSecondary).put("border", border).put("nav", nav).put("sel", navSelected)
        .put("ok", connected).put("warn", warning).put("err", error)

    private fun JSONObject.palette(d: Palette) = Palette(
        optInt("bg", d.bg), optInt("bg2", d.bg2), optInt("card", d.card), optInt("accent", d.accent),
        optInt("accent2", d.accent2), optInt("connect", d.connect), optInt("glow", d.connectGlow),
        optInt("text", d.text), optInt("sec", d.textSecondary), optInt("border", d.border),
        optInt("nav", d.nav), optInt("sel", d.navSelected), optInt("ok", d.connected),
        optInt("warn", d.warning), optInt("err", d.error)
    )

    private fun JSONObject.f(k: String, d: Float) = optDouble(k, d.toDouble()).toFloat()
    private inline fun <reified E : Enum<E>> JSONObject.e(k: String, d: E): E =
        runCatching { enumValueOf<E>(optString(k)) }.getOrDefault(d)

    private fun toJson(a: Appearance): JSONObject {
        val b = a.bg; val l = a.liquid; val bt = a.button; val c = a.card; val n = a.nav
        val themes = JSONArray()
        a.customThemes.forEach { themes.put(JSONObject().put("id", it.id).put("name", it.name).put("p", it.palette.json())) }
        return JSONObject()
            .put("themeId", a.themeId).put("palette", a.palette.json()).put("themes", themes)
            .put("reduce", a.reduceMotion).put("hc", a.highContrast)
            .put("bg", JSONObject().put("mode", b.mode.name).put("solid", b.solid).put("gp", b.gradientPreset)
                .put("ga", b.gradA).put("gb", b.gradB).put("gc", b.gradC).put("file", b.imageFile ?: "")
                .put("wallpaper", b.bundledWallpaper ?: "")
                .put("lum", b.imageLum.toDouble()).put("acc", b.imageAccent).put("fit", b.fit.name)
                .put("scale", b.scale.toDouble()).put("oc", b.overlayColor).put("ov", b.overlay.toDouble())
                .put("blur", b.blur.toDouble()).put("br", b.brightness.toDouble()).put("sat", b.saturation.toDouble())
                .put("auto", b.autoContrast))
            .put("liquid", JSONObject().put("preset", l.preset).put("c1", l.color1).put("c2", l.color2)
                .put("hi", l.highlight).put("glow", l.glow).put("icon", l.iconColor)
                .put("tr", l.transparency.toDouble()).put("blur", l.blur.toDouble())
                .put("gi", l.glowIntensity.toDouble()).put("speed", l.speed.toDouble())
                .put("move", l.movement.toDouble()).put("def", l.deformation.toDouble())
                .put("size", l.size.toDouble()).put("fsize", l.floatSize.toDouble())
                .put("fh", l.floatHeight.toDouble()).put("hl", l.highlightIntensity.toDouble())
                .put("ov", l.outlineVisibility.toDouble()).put("ot", l.outlineThickness.toDouble())
                .put("sh", l.shadow.toDouble()).put("bl", l.blend.toDouble()).put("is", l.iconSize.toDouble())
                .put("adapt", l.adaptive).put("harm", l.autoHarmony).put("pos", l.position)
                .put("px", l.posX.toDouble()).put("py", l.posY.toDouble()))
            .put("button", JSONObject().put("shape", bt.shape).put("r", bt.radius.toDouble()).put("v", bt.variant)
                .put("h", bt.height.toDouble()).put("sp", bt.spacing.toDouble()).put("is", bt.iconSize.toDouble())
                .put("end", bt.iconAtEnd).put("rip", bt.ripple).put("el", bt.elevation.toDouble())
                .put("an", bt.animation.toDouble()))
            .put("card", JSONObject().put("a", c.alpha.toDouble()).put("r", c.radius.toDouble())
                .put("bw", c.borderWidth.toDouble()).put("sh", c.shadow.toDouble()))
            .put("nav", JSONObject().put("a", n.bgAlpha.toDouble()).put("ind", n.showIndicator)
                .put("lab", n.alwaysLabels).put("h", n.height.toDouble()))
    }

    private fun fromJson(o: JSONObject): Appearance {
        val d = Appearance()
        val themes = ArrayList<ThemeEntry>()
        o.optJSONArray("themes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val t = arr.getJSONObject(i)
                themes.add(ThemeEntry(t.getString("id"), t.getString("name"), t.getJSONObject("p").palette(Presets.OMNI), false))
            }
        }
        val b = o.optJSONObject("bg") ?: JSONObject(); val db = d.bg
        val l = o.optJSONObject("liquid") ?: JSONObject(); val dl = d.liquid
        val bt = o.optJSONObject("button") ?: JSONObject(); val dbt = d.button
        val c = o.optJSONObject("card") ?: JSONObject(); val dc = d.card
        val n = o.optJSONObject("nav") ?: JSONObject(); val dn = d.nav
        return Appearance(
            themeId = o.optString("themeId", d.themeId),
            palette = (o.optJSONObject("palette") ?: JSONObject()).palette(d.palette),
            customThemes = themes,
            reduceMotion = o.optBoolean("reduce", false), highContrast = o.optBoolean("hc", false),
            bg = BackgroundSpec(
                mode = b.e("mode", db.mode), solid = b.optInt("solid", db.solid), gradientPreset = b.optString("gp", db.gradientPreset),
                gradA = b.optInt("ga", db.gradA), gradB = b.optInt("gb", db.gradB), gradC = b.optInt("gc", db.gradC),
                imageFile = b.optString("file").ifEmpty { null }, bundledWallpaper = b.optString("wallpaper").takeIf { it in BUILT_IN_WALLPAPERS }, imageLum = b.f("lum", db.imageLum),
                imageAccent = b.optInt("acc", 0), fit = b.e("fit", db.fit), scale = b.f("scale", db.scale),
                overlayColor = b.optInt("oc", db.overlayColor), overlay = b.f("ov", db.overlay), blur = b.f("blur", db.blur),
                brightness = b.f("br", db.brightness), saturation = b.f("sat", db.saturation), autoContrast = b.optBoolean("auto", true)
            ),
            liquid = LiquidStyle(
                preset = l.optString("preset", dl.preset), color1 = l.optInt("c1", dl.color1), color2 = l.optInt("c2", dl.color2),
                highlight = l.optInt("hi", dl.highlight), glow = l.optInt("glow", dl.glow), iconColor = l.optInt("icon", dl.iconColor),
                transparency = l.f("tr", dl.transparency), blur = l.f("blur", dl.blur), glowIntensity = l.f("gi", dl.glowIntensity),
                speed = l.f("speed", dl.speed), movement = l.f("move", dl.movement), deformation = l.f("def", dl.deformation),
                size = l.f("size", dl.size), floatSize = l.f("fsize", dl.floatSize), floatHeight = l.f("fh", dl.floatHeight),
                highlightIntensity = l.f("hl", dl.highlightIntensity), outlineVisibility = l.f("ov", dl.outlineVisibility),
                outlineThickness = l.f("ot", dl.outlineThickness), shadow = l.f("sh", dl.shadow), blend = l.f("bl", dl.blend),
                iconSize = l.f("is", dl.iconSize), adaptive = l.optBoolean("adapt", false), autoHarmony = l.optBoolean("harm", true),
                position = l.optString("pos", dl.position), posX = l.f("px", dl.posX), posY = l.f("py", dl.posY)
            ),
            button = ButtonStyle(
                shape = bt.optString("shape", dbt.shape), radius = bt.f("r", dbt.radius), variant = bt.optString("v", dbt.variant),
                height = bt.f("h", dbt.height), spacing = bt.f("sp", dbt.spacing), iconSize = bt.f("is", dbt.iconSize),
                iconAtEnd = bt.optBoolean("end", false), ripple = bt.optBoolean("rip", true),
                elevation = bt.f("el", dbt.elevation), animation = bt.f("an", dbt.animation)
            ),
            card = CardStyle(c.f("a", dc.alpha), c.f("r", dc.radius), c.f("bw", dc.borderWidth), c.f("sh", dc.shadow)),
            nav = NavStyle(n.f("a", dn.bgAlpha), n.optBoolean("ind", true), n.optBoolean("lab", true), n.f("h", dn.height))
        )
    }
}
