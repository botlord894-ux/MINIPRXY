package com.omniproxy.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.DevLog
import com.omniproxy.app.Diagnostics
import com.omniproxy.app.Fmt
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import hev.htproxy.TProxyService
import kotlinx.coroutines.delay

/** Developer Mode: state log, packet counters, route configuration, protocol capabilities. No passwords, ever. */
@Composable
fun DevScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val lines by DevLog.lines.collectAsState()
    val currentIp by OmniVpnService.currentIp.collectAsState()
    var stats by remember { mutableStateOf<LongArray?>(null) }
    var copied by remember { mutableStateOf(false) }
    LaunchedEffect(currentIp) {
        while (true) {
            stats = if (currentIp != null) try { TProxyService.TProxyGetStats() } catch (_: Throwable) { null } else null
            delay(1000)
        }
    }
    val server = SmartRouter.SERVERS.firstOrNull { it.host == currentIp }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Developer Panel", "For troubleshooting. No passwords are shown.")
        Spacer(Modifier.height(14.dp))

        Block("State") {
            Line("Mode", "${OmniVpnService.mode.value ?: "none"}")
            Line("Sticky session", OmniVpnService.stickyIp.value ?: "none")
            Line("Active server", server?.let { "${it.name} ${it.host}:${it.port}" } ?: "none")
            Line("Ping", "${OmniVpnService.pingMs.value} ms")
        }
        Block("Route configuration") { Mono(DevLog.engine) }
        Block("Packet counters") {
            val st = stats
            if (st == null || st.size < 4) Mono("Not available (not connected, or no tun2socks core running).")
            else {
                Line("Sent", "${st[0]} packets, ${Fmt.bytes(st[1])}")
                Line("Received", "${st[2]} packets, ${Fmt.bytes(st[3])}")
            }
        }
        Block("Protocol capabilities") {
            Mono("SOCKS5: TCP yes. UDP relay only if the server supports it (set per server). Works for any app in the tunnel.\n" +
                "HTTP proxy: browsers that honor the system proxy only. No UDP.")
        }
        Block("Event log") {
            if (lines.isEmpty()) Mono("No events yet.") else Mono(lines.takeLast(60).joinToString("\n"))
        }

        Spacer(Modifier.height(8.dp))
        PrimaryButton(if (copied) "Report copied" else "Copy diagnostic report") {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("OmniProxy report", Diagnostics.report(ctx))); copied = true
        }
        TextButton(onClick = { DevLog.clear() }, modifier = Modifier.fillMaxWidth()) { Text("Clear log", color = PurpleLight) }
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Block(title: String, content: @Composable ColumnScope.() -> Unit) {
    Text(title.uppercase(), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(start = 6.dp, bottom = 6.dp))
    OmniCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp), content = content) }
    Spacer(Modifier.height(14.dp))
}

@Composable
private fun Line(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun Mono(text: String) {
    Text(text, color = Color.White, fontSize = 11.sp, fontFamily = FontFamily.Monospace, lineHeight = 16.sp)
}
