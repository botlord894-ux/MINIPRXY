package com.omniproxy.app

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Represents the user-visible phase of the OmniProxy VPN connection.
 */
enum class VpnPhase {
    DISCONNECTED,
    CONNECTING,
    RECONNECTING,
    CONNECTED,
    DISCONNECTING,
    FAILED
}

/**
 * Small, thread-safe state machine used by OmniVpnService.
 *
 * Attempt IDs prevent an old connection attempt from overwriting the state
 * produced by a newer attempt.
 */
class VpnStateMachine {

    private val lock = Any()
    private val _phase = MutableStateFlow(VpnPhase.DISCONNECTED)
    val phase: StateFlow<VpnPhase> = _phase.asStateFlow()

    private var nextAttemptId = 0
    private var currentAttemptId = 0
    private var currentRequestKey: String? = null

    /**
     * Starts a connection attempt.
     *
     * Returns a positive attempt ID when accepted, or -1 when an equivalent
     * attempt is already running or a disconnect is in progress.
     */
    fun tryBeginConnect(requestKey: String, hasTunnel: Boolean): Int = synchronized(lock) {
        val phaseNow = _phase.value

        if (phaseNow == VpnPhase.DISCONNECTING) return@synchronized -1

        if ((phaseNow == VpnPhase.CONNECTING || phaseNow == VpnPhase.RECONNECTING) &&
            currentRequestKey == requestKey
        ) {
            return@synchronized -1
        }

        nextAttemptId += 1
        currentAttemptId = nextAttemptId
        currentRequestKey = requestKey
        _phase.value = if (hasTunnel) VpnPhase.RECONNECTING else VpnPhase.CONNECTING
        currentAttemptId
    }

    /** True only if this is still the latest attempt. */
    fun isCurrent(attempt: Int): Boolean = synchronized(lock) {
        attempt == currentAttemptId &&
            _phase.value != VpnPhase.DISCONNECTING &&
            _phase.value != VpnPhase.DISCONNECTED &&
            _phase.value != VpnPhase.FAILED
    }

    /** Marks the current attempt connected; false means it is stale. */
    fun connected(attempt: Int): Boolean = synchronized(lock) {
        if (attempt != currentAttemptId ||
            (_phase.value != VpnPhase.CONNECTING && _phase.value != VpnPhase.RECONNECTING)
        ) {
            return@synchronized false
        }
        _phase.value = VpnPhase.CONNECTED
        true
    }

    /** Marks the current attempt failed; false means it is stale. */
    fun failed(attempt: Int): Boolean = synchronized(lock) {
        if (attempt != currentAttemptId ||
            (_phase.value != VpnPhase.CONNECTING && _phase.value != VpnPhase.RECONNECTING)
        ) {
            return@synchronized false
        }
        _phase.value = VpnPhase.FAILED
        currentRequestKey = null
        true
    }

    /** Reports whether the current attempt has timed out. */
    fun timedOut(attempt: Int): Boolean = synchronized(lock) {
        if (attempt != currentAttemptId ||
            (_phase.value != VpnPhase.CONNECTING && _phase.value != VpnPhase.RECONNECTING)
        ) {
            return@synchronized false
        }
        _phase.value = VpnPhase.FAILED
        currentRequestKey = null
        true
    }

    /** Begins disconnecting and invalidates any in-flight connection attempt. */
    fun beginDisconnect(): Boolean = synchronized(lock) {
        if (_phase.value == VpnPhase.DISCONNECTING) return@synchronized false

        currentAttemptId = ++nextAttemptId
        currentRequestKey = null
        _phase.value = VpnPhase.DISCONNECTING
        true
    }

    /** Completes disconnecting. Safe to call when already disconnected. */
    fun finishDisconnect() = synchronized(lock) {
        currentAttemptId = ++nextAttemptId
        currentRequestKey = null
        _phase.value = VpnPhase.DISCONNECTED
    }

    /** Clears a displayed failure without starting a connection. */
    fun clearFailure() = synchronized(lock) {
        if (_phase.value == VpnPhase.FAILED) {
            currentAttemptId = ++nextAttemptId
            currentRequestKey = null
            _phase.value = VpnPhase.DISCONNECTED
        }
    }

    /**
     * Reconciles the state with the service's observed running status.
     * Returns true when the state machine detected a lost active connection.
     */
    fun reconcile(running: Boolean): Boolean = synchronized(lock) {
        if (_phase.value == VpnPhase.CONNECTED && !running) {
            currentAttemptId = ++nextAttemptId
            currentRequestKey = null
            _phase.value = VpnPhase.FAILED
            true
        } else {
            false
        }
    }
}
