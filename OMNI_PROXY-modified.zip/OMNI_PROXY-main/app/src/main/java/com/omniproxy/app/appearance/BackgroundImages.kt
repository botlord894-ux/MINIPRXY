package com.omniproxy.app.appearance

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import java.io.File
import java.io.FileOutputStream

/**
 * Picked photos are copied (downscaled to at most 1600 px, JPEG) into the app's private storage,
 * so no storage permission or persistent URI grant is needed, and the image can't vanish from under us.
 */
object BackgroundImages {
    data class Imported(val file: String, val lum: Float, val accent: Int)

    private var cacheKey: String? = null
    private var cacheBmp: ImageBitmap? = null

    private fun sample(w: Int, h: Int, target: Int): Int {
        var s = 1
        while (maxOf(w, h) / (s * 2) >= target) s *= 2
        return s
    }

    fun exists(ctx: Context, file: String?) = file != null && File(ctx.filesDir, file).exists()

    /** Returns null if the image can't be read. Call off the main thread. */
    fun import(ctx: Context, uri: Uri): Imported? = try {
        val r = ctx.contentResolver
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        r.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        if (bounds.outWidth <= 0 || bounds.outHeight <= 0) null else {
            val o = BitmapFactory.Options().apply {
                inSampleSize = sample(bounds.outWidth, bounds.outHeight, 1600)
                inPreferredConfig = Bitmap.Config.RGB_565 // half the memory of ARGB_8888
            }
            var bmp = r.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
            if (bmp == null) null else {
                val rot = try {
                    r.openInputStream(uri)?.use {
                        when (ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)) {
                            ExifInterface.ORIENTATION_ROTATE_90 -> 90f
                            ExifInterface.ORIENTATION_ROTATE_180 -> 180f
                            ExifInterface.ORIENTATION_ROTATE_270 -> 270f
                            else -> 0f
                        }
                    } ?: 0f
                } catch (e: Exception) { 0f }
                if (rot != 0f) {
                    val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(rot) }, true)
                    if (rotated !== bmp) { bmp.recycle(); bmp = rotated }
                }
                val name = "bg_${System.currentTimeMillis()}.jpg"
                FileOutputStream(File(ctx.filesDir, name)).use { bmp!!.compress(Bitmap.CompressFormat.JPEG, 88, it) }
                val (lum, accent) = analyze(bmp!!)
                bmp.recycle()
                Imported(name, lum, accent)
            }
        }
    } catch (e: Exception) { null }

    /** Average luminance and a vivid dominant colour, measured on a 32x32 copy. */
    private fun analyze(src: Bitmap): Pair<Float, Int> {
        val small = Bitmap.createScaledBitmap(src, 32, 32, true)
        val px = IntArray(32 * 32)
        small.getPixels(px, 0, 32, 0, 0, 32, 32)
        if (small !== src) small.recycle()
        var lumSum = 0f
        var wr = 0f; var wg = 0f; var wb = 0f; var wt = 0f
        var ar = 0f; var ag = 0f; var ab = 0f
        val hsv = FloatArray(3)
        for (p in px) {
            lumSum += ColorUtils.lum(p)
            val r = (p shr 16) and 0xFF; val g = (p shr 8) and 0xFF; val b = p and 0xFF
            ar += r; ag += g; ab += b
            android.graphics.Color.RGBToHSV(r, g, b, hsv)
            val w = if (hsv[1] > 0.25f && hsv[2] > 0.35f) hsv[1] * hsv[2] else 0f
            wr += r * w; wg += g * w; wb += b * w; wt += w
        }
        val n = px.size.toFloat()
        val accent = if (wt > 1f) (0xFF shl 24) or ((wr / wt).toInt() shl 16) or ((wg / wt).toInt() shl 8) or (wb / wt).toInt()
        else (0xFF shl 24) or ((ar / n).toInt() shl 16) or ((ag / n).toInt() shl 8) or (ab / n).toInt()
        return (lumSum / n) to accent
    }

    /** Decode for display at roughly [targetMax] px (single-entry cache). Null if missing or unreadable. */
    @Synchronized
    fun load(ctx: Context, file: String, targetMax: Int): ImageBitmap? {
        val f = File(ctx.filesDir, file)
        if (!f.exists()) return null
        val key = "$file:${f.lastModified()}:$targetMax"
        if (key == cacheKey) return cacheBmp
        return try {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            if (bounds.outWidth <= 0) null else {
                val o = BitmapFactory.Options().apply {
                    inSampleSize = sample(bounds.outWidth, bounds.outHeight, targetMax)
                    inPreferredConfig = Bitmap.Config.RGB_565
                }
                BitmapFactory.decodeFile(f.path, o)?.asImageBitmap()?.also { cacheKey = key; cacheBmp = it }
            }
        } catch (e: Throwable) { null } // includes OutOfMemoryError: we simply fall back
    }

    /** Delete every imported image except [keep]. */
    fun cleanup(ctx: Context, keep: String?) {
        ctx.filesDir.listFiles()?.forEach { f ->
            if (f.name.startsWith("bg_") && f.name.endsWith(".jpg") && f.name != keep) f.delete()
        }
    }
}
