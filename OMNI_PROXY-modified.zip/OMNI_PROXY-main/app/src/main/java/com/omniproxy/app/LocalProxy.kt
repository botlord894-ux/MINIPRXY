package com.omniproxy.app

import java.net.InetAddress
import java.net.ServerSocket
import java.net.Socket
import java.net.URI
import kotlin.concurrent.thread

/**
 * Tiny local HTTP/CONNECT proxy on 127.0.0.1 used for HTTP-type servers.
 * The VPN tells apps to use it (VpnService.Builder.setHttpProxy) and it forwards
 * every connection to your upstream server. Only apps that honor the system
 * proxy (browsers) use it.
 */
class LocalProxy(private val server: ProxyServer, private val protect: (Socket) -> Unit) {

    private var listener: ServerSocket? = null
    val port: Int get() = listener?.localPort ?: 0

    fun start() {
        val ss = ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"))
        listener = ss
        thread(isDaemon = true) {
            while (!ss.isClosed) {
                val client = try { ss.accept() } catch (e: Exception) { break }
                thread(isDaemon = true) { try { handle(client) } catch (_: Exception) {} }
            }
        }
    }

    fun stop() { try { listener?.close() } catch (_: Exception) {} }

    private fun handle(client: Socket) {
        client.use {
            val head = Upstream.readHead(client.getInputStream()) ?: return
            val parts = head.substringBefore("\r\n").split(" ")
            if (parts.size < 3) return
            val isConnect = parts[0] == "CONNECT"
            val host: String
            val port: Int
            if (isConnect) {
                host = parts[1].substringBeforeLast(':')
                port = parts[1].substringAfterLast(':').toIntOrNull() ?: 443
            } else {
                val u = URI(parts[1])
                host = u.host ?: return
                port = if (u.port == -1) 80 else u.port
            }
            val up = try { Upstream.open(server, host, port, protect) } catch (e: Exception) {
                client.getOutputStream().write("HTTP/1.1 502 Bad Gateway\r\n\r\n".toByteArray()); return
            }
            up.use {
                if (isConnect) client.getOutputStream().write("HTTP/1.1 200 Connection Established\r\n\r\n".toByteArray())
                else up.getOutputStream().write(head.replace("\r\n\r\n", "\r\nConnection: close\r\n\r\n").toByteArray(Charsets.ISO_8859_1))
                val t = thread(isDaemon = true) { copy(client, up) }
                copy(up, client)
                client.close(); up.close(); t.join(500)
            }
        }
    }

    private fun copy(from: Socket, to: Socket) {
        try { from.getInputStream().copyTo(to.getOutputStream()) } catch (_: Exception) {}
    }
}
