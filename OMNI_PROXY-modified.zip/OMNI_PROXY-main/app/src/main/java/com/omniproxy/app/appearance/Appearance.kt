package com.omniproxy.app.appearance

private fun c(rgb: Int): Int = rgb or (0xFF shl 24)

/** The 15 colours a theme controls. ARGB ints. */
data class Palette(
    val bg: Int, val bg2: Int, val card: Int,
    val accent: Int, val accent2: Int,
    val connect: Int, val connectGlow: Int,
    val text: Int, val textSecondary: Int, val border: Int,
    val nav: Int, val navSelected: Int,
    val connected: Int, val warning: Int, val error: Int
)

data class ThemeEntry(val id: String, val name: String, val palette: Palette, val builtIn: Boolean)

enum class BgMode(val label: String) {
    DEFAULT("Original"), SOLID("Solid color"), GRADIENT("Gradient"), IMAGE("Full image"),
    IMAGE_DARK("Dark overlay"), IMAGE_COLOR("Color overlay"), IMAGE_BLUR("Blurred"), ANIMATED("Animated gradient")
}

enum class ImageFit(val label: String) {
    FILL("Fill screen"), FIT("Fit"), CROP("Center crop"), CENTER("Center"), SCALE("Custom scale")
}

data class BackgroundSpec(
    val mode: BgMode = BgMode.DEFAULT,
    val solid: Int = c(0x0A0A0A),
    val gradientPreset: String = "aurora",
    val gradA: Int = c(0x0B1F3A), val gradB: Int = c(0x1FB6A6), val gradC: Int = c(0x6D28D9),
    val imageFile: String? = null,          // file inside the app's private storage
    val bundledWallpaper: String? = null,  // built-in offline wallpaper resource key
    val imageLum: Float = 0.25f,            // measured average luminance of the image
    val imageAccent: Int = 0,               // dominant colour measured from the image (0 = none)
    val fit: ImageFit = ImageFit.CROP,
    val scale: Float = 1.2f,
    val overlayColor: Int = c(0x000000),
    val overlay: Float = 0.45f,
    val blur: Float = 0.20f,
    val brightness: Float = 0f,             // -0.5 .. 0.5
    val saturation: Float = 1f,             // 0 .. 2
    val autoContrast: Boolean = true
)

data class LiquidStyle(
    val preset: String = "omni_default",
    val color1: Int = c(0x6C2EFF), val color2: Int = c(0x2B7BFF),
    val highlight: Int = c(0xFFFFFF), val glow: Int = c(0x8A5CFF), val iconColor: Int = c(0xFFFFFF),
    val transparency: Float = 0.35f,
    val blur: Float = 0.5f,
    val glowIntensity: Float = 0.9f,
    val speed: Float = 0.8f,
    val movement: Float = 1f,
    val deformation: Float = 1f,
    val size: Float = 200f,                 // dp, when centered on Home
    val floatSize: Float = 96f,             // dp, when floating
    val floatHeight: Float = 10f,           // dp
    val highlightIntensity: Float = 0.8f,
    val outlineVisibility: Float = 0.6f,
    val outlineThickness: Float = 2f,       // dp
    val shadow: Float = 0.6f,
    val blend: Float = 0.2f,
    val iconSize: Float = 56f,              // dp
    val adaptive: Boolean = false,          // derive colours from the background/theme at draw time
    val autoHarmony: Boolean = true,        // theme changes may retune non-custom liquid colours
    val position: String = "center",        // center, bottom, top, bottom_left, bottom_right, custom
    val posX: Float = 0.5f, val posY: Float = 0.5f
)

data class ButtonStyle(
    val shape: String = "rounded",          // rounded, pill, square, custom (cut corners)
    val radius: Float = 16f,
    val variant: String = "filled",         // filled, outlined, transparent
    val height: Float = 52f,
    val spacing: Float = 8f,
    val iconSize: Float = 20f,
    val iconAtEnd: Boolean = false,
    val ripple: Boolean = true,
    val elevation: Float = 0f,
    val animation: Float = 0.6f
)

data class CardStyle(
    val alpha: Float = 1f, val radius: Float = 20f, val borderWidth: Float = 1f, val shadow: Float = 0f
)

data class NavStyle(
    val bgAlpha: Float = 1f, val showIndicator: Boolean = true, val alwaysLabels: Boolean = true, val height: Float = 80f
)

data class Appearance(
    val themeId: String = "omni_purple",
    val palette: Palette = Presets.OMNI,
    val customThemes: List<ThemeEntry> = emptyList(),
    val bg: BackgroundSpec = BackgroundSpec(),
    val liquid: LiquidStyle = LiquidStyle(),
    val button: ButtonStyle = ButtonStyle(),
    val card: CardStyle = CardStyle(),
    val nav: NavStyle = NavStyle(),
    val reduceMotion: Boolean = false,
    val highContrast: Boolean = false
) {
    val themeName: String
        get() = (Presets.themes + customThemes).firstOrNull { it.id == themeId }?.name ?: "Custom Theme"
}

data class LiquidPreset(
    val id: String, val name: String, val c1: Int, val c2: Int, val hi: Int, val glow: Int,
    val transparency: Float, val glowIntensity: Float, val deform: Float, val move: Float
)

private fun pal(
    bg: Int, bg2: Int, card: Int, accent: Int, accent2: Int, connect: Int, glow: Int,
    text: Int, sec: Int, border: Int, nav: Int, sel: Int, ok: Int, warn: Int, err: Int
) = Palette(c(bg), c(bg2), c(card), c(accent), c(accent2), c(connect), c(glow), c(text), c(sec), c(border), c(nav), c(sel), c(ok), c(warn), c(err))

object Presets {
    /** The original OmniProxy purple theme. */
    val OMNI = pal(0x0A0A0A, 0x14102B, 0x11111A, 0x6C2EFF, 0x9B7BFF, 0x6C2EFF, 0x8A5CFF,
        0xFFFFFF, 0xA7A7B5, 0x29223F, 0x11111A, 0x9B7BFF, 0x00FF88, 0xFFB020, 0xFF5C7A)

    val themes: List<ThemeEntry> = listOf(
        ThemeEntry("omni_purple", "Omni Purple", OMNI, true),
        ThemeEntry("midnight", "Midnight Black", pal(0x05070D, 0x0B1020, 0x0E1424, 0x4C6FFF, 0x8FA8FF, 0x4C6FFF, 0x6C8BFF,
            0xF2F5FF, 0x9AA3B8, 0x1F2A44, 0x0B1020, 0x8FA8FF, 0x2EE6A6, 0xFFC857, 0xFF6B81), true),
        ThemeEntry("ocean", "Ocean Blue", pal(0x031826, 0x062B44, 0x0A2438, 0x1EA7FF, 0x6FD3FF, 0x1EA7FF, 0x35C2FF,
            0xEAF7FF, 0x9CC3D9, 0x17506F, 0x08283F, 0x6FD3FF, 0x3DFFB0, 0xFFC857, 0xFF6B7A), true),
        ThemeEntry("emerald", "Emerald Green", pal(0x04130D, 0x08261A, 0x0A1F16, 0x12C97A, 0x6EF0B4, 0x12C97A, 0x2EF29A,
            0xECFFF6, 0x9CC4B3, 0x15513A, 0x08261A, 0x6EF0B4, 0x00FF88, 0xFFC857, 0xFF6B7A), true),
        ThemeEntry("cyber", "Cyber Neon", pal(0x0A0414, 0x1B0733, 0x12071F, 0xFF2BD6, 0x22E4FF, 0xFF2BD6, 0x22E4FF,
            0xFFFFFF, 0xC4A8D9, 0x4A1B6B, 0x12071F, 0x22E4FF, 0x39FF14, 0xFFE600, 0xFF3B5C), true),
        ThemeEntry("sunset", "Sunset", pal(0x1A0A12, 0x3A1220, 0x2A101A, 0xFF6A3D, 0xFFB56B, 0xFF6A3D, 0xFF8A4D,
            0xFFF4EC, 0xD9B4A4, 0x6B2A2A, 0x2A101A, 0xFFB56B, 0x7CFFB2, 0xFFD24D, 0xFF5C6C), true),
        ThemeEntry("rose", "Rose Gold", pal(0x160A0E, 0x2B141B, 0x22121A, 0xE8A2A0, 0xF7D1C4, 0xE8A2A0, 0xF2B8B0,
            0xFFF3F0, 0xCDA9A4, 0x5B3A3E, 0x22121A, 0xF7D1C4, 0x8CF2B8, 0xFFD08A, 0xFF7A86), true),
        ThemeEntry("arctic", "Arctic Ice", pal(0x06121A, 0x0E2433, 0x0C1E2B, 0x8FE3FF, 0xD4F4FF, 0x8FE3FF, 0xB4EEFF,
            0xF4FCFF, 0xA9C8D6, 0x275068, 0x0C1E2B, 0xD4F4FF, 0x5CFFD0, 0xFFD98A, 0xFF7A8A), true),
        ThemeEntry("amoled", "AMOLED Black", pal(0x000000, 0x000000, 0x0A0A0A, 0x7C4DFF, 0xB39DFF, 0x7C4DFF, 0x9575FF,
            0xFFFFFF, 0xA0A0A8, 0x222222, 0x000000, 0xB39DFF, 0x00E676, 0xFFB300, 0xFF5252), true),
        ThemeEntry("light", "Minimal Light", pal(0xF6F6FB, 0xECECF5, 0xFFFFFF, 0x5B2EE6, 0x7A56F0, 0x5B2EE6, 0x8C6BFF,
            0x15151F, 0x5A5A6B, 0xD9D9E6, 0xFFFFFF, 0x5B2EE6, 0x0B9E5B, 0xB26A00, 0xD32F4D), true)
    )

    /** Built-in "wallpapers" made of gradients (no bundled photos). id -> (name, three colours). */
    val gradients: LinkedHashMap<String, Pair<String, Triple<Int, Int, Int>>> = linkedMapOf(
        "aurora" to ("Aurora" to Triple(c(0x0B1F3A), c(0x1FB6A6), c(0x6D28D9))),
        "deepsea" to ("Deep Sea" to Triple(c(0x031C2E), c(0x0A5C8A), c(0x12A4C8))),
        "ember" to ("Ember" to Triple(c(0x2A0A06), c(0xB8321A), c(0xFF9A3D))),
        "dusk" to ("Dusk" to Triple(c(0x150A2E), c(0x5B2A86), c(0xE86AA5))),
        "forest" to ("Forest" to Triple(c(0x04150C), c(0x0E4A2B), c(0x4FB26B))),
        "mist" to ("Mist" to Triple(c(0x101826), c(0x3B5170), c(0xA9C0D6))),
        "nebula" to ("Nebula" to Triple(c(0x0A0420), c(0x3A1B7A), c(0xE04BD6))),
        "glacier" to ("Glacier" to Triple(c(0x06151F), c(0x1C5F7A), c(0xBDEBFF)))
    )

    val liquids: List<LiquidPreset> = listOf(
        LiquidPreset("transparent_water", "Transparent Water", c(0x4FB8FF), c(0x1B6FD6), c(0xFFFFFF), c(0x4FB8FF), 0.55f, 0.8f, 1f, 1f),
        LiquidPreset("liquid_glass", "Liquid Glass", c(0x9C7BFF), c(0x4B3AD1), c(0xFFFFFF), c(0x8C6BFF), 0.60f, 0.8f, 0.9f, 0.9f),
        LiquidPreset("plasma_orb", "Plasma Orb", c(0xFF5CE1), c(0x7B2CFF), c(0xFFD6FA), c(0xFF4FD8), 0.35f, 1.2f, 1.2f, 1.2f),
        LiquidPreset("aurora_fluid", "Aurora Fluid", c(0x3DFFC8), c(0x3A6BFF), c(0xD9FFF4), c(0x2EF0C0), 0.45f, 1.0f, 1.1f, 1f),
        LiquidPreset("neon_energy", "Neon Energy", c(0x22E4FF), c(0xFF2BD6), c(0xFFFFFF), c(0x22E4FF), 0.40f, 1.3f, 1.0f, 1.1f),
        LiquidPreset("frosted_crystal", "Frosted Crystal", c(0xCFE8FF), c(0x8FB3E8), c(0xFFFFFF), c(0xBFDDFF), 0.70f, 0.6f, 0.7f, 0.8f),
        LiquidPreset("deep_ocean", "Deep Ocean", c(0x1E78D6), c(0x062B5C), c(0x7FD0FF), c(0x1E78D6), 0.30f, 0.8f, 0.9f, 0.9f),
        LiquidPreset("soft_pearl", "Soft Pearl", c(0xF3EEFF), c(0xBFB5E8), c(0xFFFFFF), c(0xDCD0FF), 0.50f, 0.6f, 0.8f, 0.8f)
    )

    fun liquidDefault() = LiquidStyle()

    fun applyLiquid(base: LiquidStyle, p: LiquidPreset) = base.copy(
        preset = p.id, color1 = p.c1, color2 = p.c2, highlight = p.hi, glow = p.glow,
        transparency = p.transparency, glowIntensity = p.glowIntensity, deformation = p.deform, movement = p.move
    )
}
