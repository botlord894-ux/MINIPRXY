package com.omniproxy.app

import org.json.JSONObject
import java.net.Socket
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class ExitInfo(val ip: String, val country: String?, val org: String?, val city: String?)

/**
 * Asks ipinfo.io "what IP do you see?" THROUGH the proxy. The answer is the real
 * exit IP, which can differ from the proxy's own address. Blocking: call off the main thread.
 */
object ExitProbe {
    fun probe(server: ProxyServer, protect: (Socket) -> Unit = {}): ExitInfo? = try {
        val raw = Upstream.open(server, "ipinfo.io", 443, protect)
        raw.soTimeout = 12000
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
            .createSocket(raw, "ipinfo.io", 443, true) as SSLSocket
        ssl.startHandshake()
        ssl.getOutputStream().apply {
            write(("GET /json HTTP/1.1\r\nHost: ipinfo.io\r\nUser-Agent: OmniProxy\r\n" +
                "Accept: application/json\r\nConnection: close\r\n\r\n").toByteArray())
            flush()
        }
        val text = ssl.getInputStream().readBytes().toString(Charsets.UTF_8)
        try { ssl.close() } catch (_: Exception) {}
        val a = text.indexOf('{'); val b = text.lastIndexOf('}')
        if (a < 0 || b < a) null else {
            val j = JSONObject(text.substring(a, b + 1))
            ExitInfo(
                ip = j.getString("ip"),
                country = j.optString("country").ifEmpty { null },
                org = j.optString("org").ifEmpty { null },
                city = j.optString("city").ifEmpty { null }
            )
        }
    } catch (e: Exception) { null }
}
