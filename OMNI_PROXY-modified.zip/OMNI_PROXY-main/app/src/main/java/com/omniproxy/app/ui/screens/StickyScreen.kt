package com.omniproxy.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.background
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.VpnActions
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

@Composable
fun StickyScreen(
    actions: VpnActions,
    onEditApps: (String) -> Unit,
    onOpenServers: () -> Unit,
    onNavigate: (String) -> Unit
) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val router = remember { StickyRouter(ctx) }
    val ver by StickyRouter.version.collectAsState()
    val sver by ServerStore.version.collectAsState()
    val stickyActive by OmniVpnService.stickyIp.collectAsState()
    val connecting by OmniVpnService.connecting.collectAsState()

    // One group per server that has apps assigned
    val groups = remember(ver, sver) {
        SmartRouter.SERVERS
            .map { s -> s to StickyRouter.PICKABLE_APPS.filter { router.get(it)?.ip == s.host } }
            .filter { it.second.isNotEmpty() }
    }
    var showAdd by remember { mutableStateOf(false) }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { ScreenHeader("Sticky Sessions", "One IP per app group.") }
                OmniLogo(54.dp)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ShortcutCard("Route Rules", "Who goes where", Icons.Filled.AltRoute, Modifier.weight(1f)) { onNavigate("rules") }
                ShortcutCard("Simulator", "Preview routes", Icons.Filled.AccountTree, Modifier.weight(1f)) { onNavigate("simulator") }
            }
        }
        if (groups.isEmpty()) item {
            OmniCard(Modifier.fillMaxWidth()) {
                Text("No sticky groups yet. Add a server, then tap \"Add New Sticky IP\".",
                    color = TextSecondary, modifier = Modifier.padding(18.dp), fontSize = 14.sp)
            }
        }
        items(groups, key = { it.first.host + ":" + it.first.port }) { (server, apps) ->
            val active = stickyActive == server.host
            StickyCard(
                server = server, apps = apps, active = active, busy = connecting && !active,
                onToggle = { actions.toggleSticky(server.host) },
                onEdit = { onEditApps(server.host) }
            )
        }
        item { AddCard { showAdd = true } }
        item { InfoBanner("Android allows one VPN at a time. Apps on the same IP run together; different IPs need separate sessions.") }
        item {
            InfoBanner(
                "Use 1 IP per real account. Creating many fake accounts violates WhatsApp/TikTok Terms.",
                accent = Amber, icon = Icons.Filled.Warning
            )
        }
    }

    if (showAdd) {
        val used = groups.map { it.first.host }.toSet()
        val free = SmartRouter.SERVERS.filter { it.host !in used }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            containerColor = CardBg,
            title = { Text("Add New Sticky IP", color = Color.White) },
            text = {
                if (free.isEmpty()) Text(
                    "Every server already has a group (or you have no servers yet). Add a server first.",
                    color = TextSecondary)
                else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Pick a server, then choose its apps.", color = TextSecondary, fontSize = 13.sp)
                    free.forEach { s ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1830))
                                .clickable { showAdd = false; onEditApps(s.host) }.padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FlagBadge(s.country, 36.dp); Spacer(Modifier.width(12.dp))
                            Column {
                                Text(s.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("${s.host}:${s.port}", color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {
                if (free.isEmpty()) TextButton(onClick = { showAdd = false; onOpenServers() }) {
                    Text("Go to Servers", color = PurpleLight)
                }
            },
            dismissButton = { TextButton(onClick = { showAdd = false }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

@Composable
private fun StickyCard(
    server: ProxyServer, apps: List<String>, active: Boolean, busy: Boolean,
    onToggle: () -> Unit, onEdit: () -> Unit
) {
    OmniCard(Modifier.fillMaxWidth(), borderColor = if (active) Green else Border, onClick = onToggle) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                FlagBadge(server.country, 46.dp)
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("${server.country.uppercase()} IP", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text(server.host, color = TextSecondary, fontSize = 13.sp)
                }
                StatusDot(if (active) Green else TextSecondary)
                Spacer(Modifier.width(6.dp))
                Text(if (active) "Connected" else "Offline", color = if (active) Green else TextSecondary, fontSize = 12.sp)
            }
            Spacer(Modifier.height(14.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                apps.forEach { AppIcon(it, 32.dp); Spacer(Modifier.width(8.dp)) }
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onEdit) { Icon(Icons.Filled.ChevronRight, "Edit apps", tint = TextSecondary) }
            }
            Text(if (apps.size == 1) "1 app assigned" else "${apps.size} apps assigned", color = TextSecondary, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            Hairline()
            Spacer(Modifier.height(10.dp))
            Text(
                when {
                    active -> "Tap card to route exactly those apps"
                    busy -> "Switching sessions…"
                    else -> "Tap to start"
                },
                color = if (active) Green else TextSecondary, fontSize = 12.sp
            )
        }
    }
}

@Composable
private fun AddCard(onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp)).clickable(onClick = onClick)
            .drawBehind {
                drawRoundRect(
                    color = Purple, cornerRadius = CornerRadius(20.dp.toPx()),
                    style = Stroke(width = 2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(18f, 12f)))
                )
            }.padding(18.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(48.dp).clip(RoundedCornerShape(24.dp)).background(Purple.copy(alpha = 0.2f)),
            contentAlignment = Alignment.Center) { Icon(Icons.Filled.Add, null, tint = PurpleLight) }
        Spacer(Modifier.width(16.dp))
        Column {
            Text("Add New Sticky IP", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text("Create an IP and assign apps", color = TextSecondary, fontSize = 13.sp)
        }
    }
}

@Composable
private fun ShortcutCard(title: String, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    OmniCard(modifier, onClick = onClick) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            IconBadge(icon, Cyan, 38.dp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(sub, color = TextSecondary, fontSize = 11.sp)
            }
        }
    }
}
