package com.omniproxy.app.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.omniproxy.app.appearance.ColorUtils
import com.omniproxy.app.ui.components.OmniButton
import com.omniproxy.app.ui.components.OmniCard
import com.omniproxy.app.ui.components.OmniOutlinedButton
import com.omniproxy.app.ui.components.OmniTextField
import com.omniproxy.app.ui.theme.*

@Composable
fun SectionTitle(text: String) {
    Text(text.uppercase(), color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(top = 14.dp, bottom = 6.dp))
}

@Composable
fun LabeledSlider(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: (Float) -> String, onChange: (Float) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Row {
            Text(label, color = TextPrimary, fontSize = 13.sp, modifier = Modifier.weight(1f))
            Text(display(value), color = TextSecondary, fontSize = 12.sp)
        }
        Slider(
            value = value.coerceIn(range.start, range.endInclusive), onValueChange = onChange, valueRange = range,
            colors = SliderDefaults.colors(thumbColor = Purple, activeTrackColor = Purple, inactiveTrackColor = Border)
        )
    }
}

fun pct(v: Float) = "${(v * 100).toInt()}%"
fun dpText(v: Float) = "${v.toInt()} dp"

@Composable
fun SwitchLine(label: String, sub: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = TextPrimary, fontSize = 14.sp)
            if (sub != null) Text(sub, color = TextSecondary, fontSize = 11.sp)
        }
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Purple, checkedThumbColor = Color.White,
                uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
    }
}

@Composable
fun ColorRow(label: String, argb: Int, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(Color(argb)).border(1.dp, Border, CircleShape))
        Spacer(Modifier.width(12.dp))
        Text(label, color = TextPrimary, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Text(ColorUtils.hex(argb), color = TextSecondary, fontSize = 12.sp)
    }
}

/** A tappable pill for choices in a horizontally scrolling row. */
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.padding(end = 8.dp).heightIn(min = 40.dp).clip(RoundedCornerShape(20.dp))
            .background(if (selected) Purple else Surface2).clickable(onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (selected) Color.White else TextSecondary, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
}

/** HSV colour picker with a HEX field. Returns an opaque ARGB colour. */
@Composable
fun ColorPickerDialog(title: String, initial: Int, onDismiss: () -> Unit, onPick: (Int) -> Unit) {
    val hsv = remember { FloatArray(3).also { android.graphics.Color.colorToHSV(initial, it) } }
    var h by remember { mutableFloatStateOf(hsv[0]) }
    var s by remember { mutableFloatStateOf(hsv[1]) }
    var v by remember { mutableFloatStateOf(hsv[2]) }
    val color = android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)) or (0xFF shl 24)
    var hex by remember { mutableStateOf(ColorUtils.hex(initial)) }
    var hexBad by remember { mutableStateOf(false) }

    fun sync(c: Int) { hex = ColorUtils.hex(c); hexBad = false }
    Dialog(onDismissRequest = onDismiss) {
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, color = TextPrimary, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Box(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(14.dp)).background(Color(color)).border(1.dp, Border, RoundedCornerShape(14.dp)))
                LabeledSlider("Hue", h, 0f..360f, { "${it.toInt()}°" }) { h = it; sync(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))) }
                LabeledSlider("Saturation", s, 0f..1f, ::pct) { s = it; sync(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))) }
                LabeledSlider("Brightness", v, 0f..1f, ::pct) { v = it; sync(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v))) }
                OmniTextField(hex, { t ->
                    hex = t
                    val parsed = ColorUtils.parseHex(t)
                    hexBad = parsed == null
                    if (parsed != null) {
                        val a = FloatArray(3); android.graphics.Color.colorToHSV(parsed, a); h = a[0]; s = a[1]; v = a[2]
                    }
                }, "HEX color (#RRGGBB)", Modifier.fillMaxWidth())
                if (hexBad) Text("Enter 6 hex digits, like #6C2EFF.", color = Danger, fontSize = 12.sp)
                Spacer(Modifier.height(6.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OmniOutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f)) { Text("Cancel") }
                    OmniButton(onClick = { onPick(color) }, modifier = Modifier.weight(1f)) { Text("Use color") }
                }
            }
        }
    }
}

/** Ask for a name (create / rename). */
@Composable
fun NameDialog(title: String, initial: String, onDismiss: () -> Unit, onOk: (String) -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = CardBg,
        title = { Text(title, color = TextPrimary) },
        text = { OmniTextField(name, { name = it.take(30) }, "Name", Modifier.fillMaxWidth()) },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onOk(name.trim()) }) { Text("OK", color = PurpleLight) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = TextSecondary) } }
    )
}
