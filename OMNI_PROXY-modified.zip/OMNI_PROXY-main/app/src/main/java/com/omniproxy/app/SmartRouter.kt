package com.omniproxy.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import java.net.InetSocketAddress
import java.net.Socket

enum class ProxyType { HTTP, SOCKS5 }

/** One upstream proxy server. */
data class ProxyServer(
    val name: String,
    val host: String,
    val port: Int,
    val type: ProxyType,
    val country: String,            // "US", "GB", ...
    val user: String? = null,       // optional login
    val pass: String? = null,
    val compression: Boolean = false, // true = used by Data Saver mode
    val udp: Boolean = false          // true = server supports SOCKS5 UDP relay (games, QUIC, real DNS)
)

/** Holds the server list and picks the fastest one by pinging. */
object SmartRouter {

    /** Your servers: add/remove them in the Servers tab (saved on the device). */
    val SERVERS: List<ProxyServer> get() = ServerStore.list()

    /** Ping = time to open a TCP connection to the server. Returns -1 if unreachable. */
    fun pingMs(s: ProxyServer, protect: (Socket) -> Unit = {}): Int {
        val start = System.nanoTime()
        return try {
            Socket().use { sock ->
                protect(sock) // keeps the test outside the VPN tunnel
                sock.connect(InetSocketAddress(s.host, s.port), 2000)
            }
            ((System.nanoTime() - start) / 1_000_000).toInt()
        } catch (e: Exception) {
            -1
        }
    }

    /** Pings all candidates in parallel; returns (server, ms) of the fastest, or null if none respond. */
    suspend fun fastest(
        candidates: List<ProxyServer> = SERVERS,
        protect: (Socket) -> Unit = {}
    ): Pair<ProxyServer, Int>? = coroutineScope {
        candidates
            .map { s -> async(Dispatchers.IO) { s to pingMs(s, protect) } }
            .awaitAll()
            .filter { it.second >= 0 }
            .minByOrNull { it.second }
    }
}
