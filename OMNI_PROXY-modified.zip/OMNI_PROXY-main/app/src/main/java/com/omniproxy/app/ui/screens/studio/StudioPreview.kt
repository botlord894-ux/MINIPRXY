package com.omniproxy.app.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.Appearance
import com.omniproxy.app.appearance.ButtonStyle
import com.omniproxy.app.appearance.ColorUtils
import com.omniproxy.app.appearance.Palette
import com.omniproxy.app.appearance.Resolver
import com.omniproxy.app.ui.components.*

/**
 * Mini Home screen drawn from the DRAFT (not the applied theme), so changes show instantly and
 * Cancel can throw them away. Tap the orb to cycle through its states (demo only).
 */
@Composable
fun StudioPreview(draft: Appearance, modifier: Modifier = Modifier) {
    val r = remember(draft) { Resolver.resolve(draft) }
    val p = r.palette
    var demo by remember { mutableStateOf(LiquidState.DISCONNECTED) }
    val reduce = rememberReduceMotion() || draft.reduceMotion
    val shape = RoundedCornerShape(20.dp)
    Box(modifier.fillMaxWidth().height(236.dp).clip(shape).border(1.dp, Color(p.border), shape)) {
        OmniBackground(draft, Modifier.fillMaxSize(), reduce)
        Column(Modifier.fillMaxSize().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    LiquidConnectButton(
                        state = demo, style = draft.liquid, palette = p, imageAccent = draft.bg.imageAccent,
                        sizeDp = (draft.liquid.size * 0.36f).coerceIn(52f, 84f).dp, reduceMotion = reduce,
                        description = "Preview of the connect button. Tap to cycle states",
                        onClick = { demo = LiquidState.values()[(demo.ordinal + 1) % LiquidState.values().size] }
                    )
                    Text(liquidLabel(demo), color = Color(p.text), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                    Text("Preview: tap to cycle", color = Color(p.textSecondary), fontSize = 9.sp)
                }
                Spacer(Modifier.width(8.dp))
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    PreviewCard(draft, r.cardAlpha) {
                        Text("US · 104.21.45.12", color = Color(p.text), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("Connection status", color = Color(p.connected), fontSize = 10.sp)
                    }
                    PreviewCard(draft, r.cardAlpha) {
                        Text("Server · SOCKS5", color = Color(p.text), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        Text("45 ms", color = Color(p.textSecondary), fontSize = 10.sp)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        SampleButton("Primary", draft.button, p, filled = true)
                        SampleButton("Secondary", draft.button, p, filled = false)
                    }
                }
            }
            // mini navigation bar
            val n = draft.nav
            Row(
                Modifier.fillMaxWidth().height((n.height * 0.5f).dp).clip(RoundedCornerShape(14.dp))
                    .background(Color(p.nav).copy(alpha = n.bgAlpha)),
                horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
            ) {
                listOf(Icons.Filled.Home to "Home", Icons.Filled.Apps to "Sticky", Icons.Filled.Dns to "Servers", Icons.Filled.Settings to "Settings")
                    .forEachIndexed { i, (icon, label) ->
                        val sel = i == 0
                        Column(
                            Modifier.clip(RoundedCornerShape(12.dp))
                                .background(if (sel && n.showIndicator) Color(ColorUtils.blend(p.nav, p.navSelected, 0.22f)) else Color.Transparent)
                                .padding(horizontal = 10.dp, vertical = 2.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Icon(icon, null, tint = Color(if (sel) p.navSelected else p.textSecondary), modifier = Modifier.size(16.dp))
                            if (n.alwaysLabels || sel) Text(label, color = Color(if (sel) p.navSelected else p.textSecondary), fontSize = 8.sp)
                        }
                    }
            }
        }
    }
}

@Composable
private fun PreviewCard(draft: Appearance, alpha: Float, content: @Composable ColumnScope.() -> Unit) {
    val p = Resolver.resolve(draft).palette
    val c = draft.card
    val shape = RoundedCornerShape((c.radius * 0.6f).dp)
    Column(
        Modifier.fillMaxWidth().clip(shape).background(Color(p.card).copy(alpha = alpha))
            .then(if (c.borderWidth > 0f) Modifier.border(c.borderWidth.dp, Color(p.border), shape) else Modifier)
            .padding(8.dp),
        content = content
    )
}

/** A button drawn from explicit values (used for previews and style samples). */
@Composable
fun SampleButton(text: String, s: ButtonStyle, p: Palette, filled: Boolean, modifier: Modifier = Modifier, height: Dp = 30.dp) {
    val shape = buttonShapeOf(s)
    val variant = if (!filled && s.variant == "filled") "outlined" else s.variant
    val accent = Color(p.accent)
    val bg = when (variant) { "outlined" -> Color.Transparent; "transparent" -> accent.copy(alpha = 0.16f); else -> accent }
    val fg = if (variant == "filled") Color(ColorUtils.readable(0xFFFFFFFF.toInt(), p.accent)) else Color(p.accent2)
    Box(
        modifier.height(height).clip(shape).background(bg)
            .then(if (variant == "outlined") Modifier.border(1.5.dp, accent, shape) else Modifier)
            .padding(horizontal = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = fg, fontSize = 10.sp, fontWeight = FontWeight.SemiBold) }
}
