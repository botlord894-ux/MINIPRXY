package com.omniproxy.app

import kotlinx.coroutines.flow.MutableStateFlow
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** In-memory event log for Developer Mode. Never contains passwords or traffic contents. */
object DevLog {
    val lines = MutableStateFlow<List<String>>(emptyList())
    @Volatile var engine: String = "Not running"
    private val fmt = SimpleDateFormat("HH:mm:ss", Locale.US)

    @Synchronized
    fun log(msg: String) { lines.value = (lines.value + "${fmt.format(Date())}  $msg").takeLast(200) }

    fun clear() { lines.value = emptyList() }
}
