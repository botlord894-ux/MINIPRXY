package com.omniproxy.app.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Autorenew
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Sync
import androidx.compose.material3.Icon
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.onClick
import androidx.compose.ui.semantics.role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.stateDescription
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.omniproxy.app.appearance.ColorUtils
import com.omniproxy.app.appearance.LiquidStyle
import com.omniproxy.app.appearance.Palette
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin

/** What the button shows. It is derived from the real VPN service (never from animation progress). */
enum class LiquidState { DISCONNECTED, CONNECTING, CONNECTED, RECONNECTING, FAILED, DISCONNECTING }

fun liquidLabel(s: LiquidState) = when (s) {
    LiquidState.DISCONNECTED -> "Tap to Connect"
    LiquidState.CONNECTING -> "Connecting…"
    LiquidState.CONNECTED -> "Connected"
    LiquidState.RECONNECTING -> "Reconnecting…"
    LiquidState.FAILED -> "Connection failed"
    LiquidState.DISCONNECTING -> "Disconnecting…"
}

private const val POINTS = 10

/** Liquid palette used when Adaptive Color is on: derived from the image accent or the theme, never stored. */
private fun baseColors(style: LiquidStyle, palette: Palette, imageAccent: Int): IntArray =
    if (style.adaptive) {
        val b = if (imageAccent != 0) imageAccent else palette.connect
        intArrayOf(b, ColorUtils.hueShift(b, 35f), style.highlight, b)
    } else intArrayOf(style.color1, style.color2, style.highlight, style.glow)

/**
 * A translucent floating liquid orb. The outline is a smooth closed curve through 10 points whose radii
 * drift slowly, so the silhouette is organic rather than a circle. Everything is drawn with Canvas
 * (no shaders), so it works on every supported Android version. One Path and two FloatArrays are reused
 * every frame; only a ~30 fps clock changes, and it is read in the draw phase (no recomposition).
 */
@Composable
fun LiquidConnectButton(
    state: LiquidState,
    style: LiquidStyle,
    palette: Palette,
    imageAccent: Int,
    sizeDp: Dp,
    reduceMotion: Boolean,
    modifier: Modifier = Modifier,
    interactive: Boolean = true,
    description: String = "Connect",
    onClick: () -> Unit = {},
    onLongPress: () -> Unit = {}
) {
    val base = remember(style, palette, imageAccent) { baseColors(style, palette, imageAccent) }
    val targets = when (state) {
        LiquidState.CONNECTED -> Triple(palette.connected, ColorUtils.blend(palette.connected, palette.accent, 0.35f), palette.connected)
        LiquidState.RECONNECTING -> Triple(palette.warning, ColorUtils.blend(palette.warning, palette.error, 0.4f), palette.warning)
        LiquidState.FAILED -> Triple(palette.error, ColorUtils.blend(palette.error, 0xFF000000.toInt(), 0.35f), palette.error)
        LiquidState.DISCONNECTING -> Triple(ColorUtils.blend(base[0], palette.bg, 0.35f), ColorUtils.blend(base[1], palette.bg, 0.35f), base[3])
        else -> Triple(base[0], base[1], base[3])
    }
    val c1 by animateColorAsState(Color(targets.first), tween(450), label = "c1")
    val c2 by animateColorAsState(Color(targets.second), tween(450), label = "c2")
    val glowC by animateColorAsState(Color(targets.third), tween(450), label = "glow")
    val hi = Color(base[2])
    val iconColor = Color(style.iconColor)

    // ---- animation clock (paused in background, frozen on failure / reduced motion) ----
    var time by remember { mutableFloatStateOf(0f) }
    val started = rememberStarted()
    val animating = started && !reduceMotion && state != LiquidState.FAILED
    val stateSpeed = when (state) {
        LiquidState.DISCONNECTED -> 0.5f; LiquidState.CONNECTING -> 1.6f; LiquidState.CONNECTED -> 0.35f
        LiquidState.RECONNECTING -> 1.2f; LiquidState.DISCONNECTING -> 1.0f; LiquidState.FAILED -> 0f
    }
    val speed by rememberUpdatedState(style.speed * stateSpeed)
    LaunchedEffect(animating) {
        if (animating) {
            var last = withFrameNanosCompat()
            var acc = 0L
            while (true) {
                val now = withFrameNanosCompat()
                acc += now - last; last = now
                if (acc >= 33_000_000L) { time += acc / 1_000_000_000f * speed; acc = 0L } // ~30 fps
            }
        }
    }

    // ---- geometry and brushes (rebuilt only when inputs change, never per frame) ----
    val density = LocalDensity.current
    val outerDp = sizeDp * 1.7f
    val outerPx = with(density) { outerDp.toPx() }
    val rPx = with(density) { (sizeDp / 2).toPx() }
    val floatPx = with(density) { style.floatHeight.dp.toPx() }
    val strokePx = with(density) { style.outlineThickness.dp.toPx() }
    val arcPx = with(density) { 3.dp.toPx() }
    val cx = outerPx / 2; val cy = outerPx / 2
    val fillAlpha = ((1f - style.transparency * 0.65f).coerceIn(0.3f, 1f)) * (1f - style.blend * 0.3f)
    val gi = style.glowIntensity.coerceIn(0f, 2f)
    val hl = style.highlightIntensity.coerceIn(0f, 1.5f)

    val fillBrush = remember(c1, c2, fillAlpha, rPx) {
        Brush.radialGradient(
            listOf(c1.copy(alpha = fillAlpha), c1.copy(alpha = fillAlpha * 0.85f), c2.copy(alpha = fillAlpha * 0.92f)),
            center = Offset(cx - rPx * 0.25f, cy - rPx * 0.3f), radius = rPx * 1.45f
        )
    }
    val glowBrush = remember(glowC, gi, rPx) {
        Brush.radialGradient(
            listOf(glowC.copy(alpha = (0.55f * gi).coerceAtMost(0.9f)), glowC.copy(alpha = (0.18f * gi).coerceAtMost(0.5f)), Color.Transparent),
            center = Offset(cx, cy), radius = rPx * 1.6f
        )
    }
    val hiBrush = remember(hi, hl, rPx) {
        Brush.linearGradient(
            listOf(hi.copy(alpha = (0.7f * hl).coerceAtMost(0.95f)), Color.Transparent),
            start = Offset(cx - rPx * 0.7f, cy - rPx * 0.8f), end = Offset(cx + rPx * 0.1f, cy + rPx * 0.1f)
        )
    }
    val causticBrush = remember(hi, hl, rPx) {
        Brush.radialGradient(listOf(hi.copy(alpha = (0.35f * hl).coerceAtMost(0.8f)), Color.Transparent), center = Offset(cx, cy), radius = rPx * 0.45f)
    }
    val rimBrush = remember(hi, glowC, rPx) {
        Brush.linearGradient(
            listOf(hi.copy(alpha = 0.9f), glowC.copy(alpha = 0.5f), hi.copy(alpha = 0.15f)),
            start = Offset(cx - rPx, cy - rPx), end = Offset(cx + rPx, cy + rPx)
        )
    }
    val path = remember { Path() }
    val px = remember { FloatArray(POINTS) }
    val py = remember { FloatArray(POINTS) }

    val stateDeform = when (state) {
        LiquidState.DISCONNECTED -> 1f; LiquidState.CONNECTING -> 1.2f; LiquidState.CONNECTED -> 0.45f
        LiquidState.RECONNECTING -> 0.9f; LiquidState.DISCONNECTING -> 0.7f; LiquidState.FAILED -> 0.35f
    }
    val amp = 0.11f * style.deformation.coerceIn(0f, 2f) * stateDeform

    // ---- touch feedback ----
    var pressed by remember { mutableStateOf(false) }
    val pressScale by animateFloatAsState(if (pressed) 0.94f else 1f, spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = 400f), label = "press")
    val hit = if (sizeDp < 48.dp) 48.dp else sizeDp
    val a11yState = liquidLabel(state)

    Box(
        modifier.size(outerDp).graphicsLayer { scaleX = pressScale; scaleY = pressScale },
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.fillMaxSize()) {
            drawLiquid(
                t = time, state = state, cx = cx, cy = cy, r = rPx, amp = amp, floatPx = floatPx, move = style.movement,
                glowBrush = glowBrush, fillBrush = fillBrush, hiBrush = hiBrush, causticBrush = causticBrush, rimBrush = rimBrush,
                outline = style.outlineVisibility, strokePx = strokePx, arcPx = arcPx, shadow = style.shadow, blur = style.blur,
                arcColor = if (state == LiquidState.RECONNECTING) Color(palette.warning) else Color.White,
                path = path, px = px, py = py
            )
        }
        Box(
            Modifier.size(hit)
                .graphicsLayer { translationY = sin(time * 0.7f) * floatPx * 0.25f }
                .semantics {
                    contentDescription = description
                    stateDescription = a11yState
                    role = Role.Button
                    onClick(label = if (state == LiquidState.CONNECTED) "Disconnect" else "Connect") { if (interactive) onClick(); true }
                }
                .pointerInput(interactive) {
                    if (interactive) detectTapGestures(
                        onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                        onTap = { onClick() },
                        onLongPress = { onLongPress() }
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            val icon = when (state) {
                LiquidState.CONNECTING, LiquidState.DISCONNECTING -> Icons.Filled.Sync
                LiquidState.RECONNECTING -> Icons.Filled.Autorenew
                LiquidState.FAILED -> Icons.Filled.ErrorOutline
                else -> Icons.Filled.PowerSettingsNew
            }
            Icon(icon, null, tint = iconColor, modifier = Modifier.size((style.iconSize * sizeDp.value / 200f).coerceIn(18f, 96f).dp))
        }
    }
}

private fun buildBlob(path: Path, px: FloatArray, py: FloatArray, cx: Float, cy: Float, r: Float, amp: Float, t: Float) {
    val n = px.size
    val step = (2.0 * PI / n).toFloat()
    for (i in 0 until n) {
        val th = i * step
        val k = 1f + amp * (0.55f * sin(2 * th + t * 0.9f) + 0.30f * sin(3 * th - t * 1.3f + 1.7f) + 0.20f * sin(5 * th + t * 0.7f + 0.6f))
        px[i] = cx + cos(th) * r * k
        py[i] = cy + sin(th) * r * k
    }
    path.reset()
    path.moveTo(px[0], py[0])
    for (i in 0 until n) { // Catmull-Rom spline converted to cubic Beziers: smooth closed curve
        val p0 = (i - 1 + n) % n; val p1 = i; val p2 = (i + 1) % n; val p3 = (i + 2) % n
        path.cubicTo(
            px[p1] + (px[p2] - px[p0]) / 6f, py[p1] + (py[p2] - py[p0]) / 6f,
            px[p2] - (px[p3] - px[p1]) / 6f, py[p2] - (py[p3] - py[p1]) / 6f,
            px[p2], py[p2]
        )
    }
    path.close()
}

private fun DrawScope.drawLiquid(
    t: Float, state: LiquidState, cx: Float, cy: Float, r: Float, amp: Float, floatPx: Float, move: Float,
    glowBrush: Brush, fillBrush: Brush, hiBrush: Brush, causticBrush: Brush, rimBrush: Brush,
    outline: Float, strokePx: Float, arcPx: Float, shadow: Float, blur: Float, arcColor: Color,
    path: Path, px: FloatArray, py: FloatArray
) {
    val bob = sin(t * 0.7f) * floatPx * 0.25f
    val pulse = when (state) {
        LiquidState.CONNECTING -> 1f + 0.07f * sin(t * 2.2f)
        LiquidState.DISCONNECTING -> 1f - 0.05f * (0.5f + 0.5f * sin(t * 2f))
        LiquidState.RECONNECTING -> 1f + 0.04f * sin(t * 1.8f)
        LiquidState.FAILED -> 1f
        else -> 1f + 0.03f * sin(t * 1.1f) * move
    }
    // soft outer glow
    drawCircle(glowBrush, radius = r * 1.6f * (1f + blur * 0.25f), center = Offset(cx, cy + bob * 0.4f))
    // floating shadow
    val sh = (0.30f * shadow).coerceIn(0f, 0.6f)
    if (sh > 0f) drawOval(Color.Black.copy(alpha = sh), topLeft = Offset(cx - r * 0.75f, cy + r * 1.08f + floatPx * 0.6f), size = Size(r * 1.5f, r * 0.22f))

    translate(top = bob) {
        buildBlob(path, px, py, cx, cy, r * pulse, amp, t)
        drawPath(path, fillBrush)
        clipPath(path) {
            // light moving inside the liquid
            translate(left = r * 0.28f * cos(t * 0.8f) * move, top = r * 0.22f * sin(t * 0.6f) * move) {
                drawCircle(causticBrush, radius = r * 0.45f, center = Offset(cx, cy))
            }
            // top-left reflection
            withTransform({ translate(-r * 0.12f, -r * 0.16f); scale(0.62f, 0.62f, Offset(cx, cy)) }) { drawPath(path, hiBrush) }
        }
        if (outline > 0.01f) drawPath(path, rimBrush, alpha = outline.coerceIn(0f, 1f), style = Stroke(width = strokePx))
        // progress indicator while the service is working
        if (state == LiquidState.CONNECTING || state == LiquidState.RECONNECTING || state == LiquidState.DISCONNECTING) {
            val dir = if (state == LiquidState.DISCONNECTING) -1f else 1f
            drawArc(
                color = arcColor.copy(alpha = 0.85f), startAngle = (dir * t * 160f) % 360f, sweepAngle = 95f, useCenter = false,
                topLeft = Offset(cx - r * 1.12f, cy - r * 1.12f), size = Size(r * 2.24f, r * 2.24f),
                style = Stroke(width = arcPx, cap = StrokeCap.Round)
            )
        }
    }
}
