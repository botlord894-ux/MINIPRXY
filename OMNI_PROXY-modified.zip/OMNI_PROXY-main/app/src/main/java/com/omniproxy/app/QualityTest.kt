package com.omniproxy.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import javax.net.ssl.SSLSocket
import javax.net.ssl.SSLSocketFactory

data class Quality(
    val server: ProxyServer, val sent: Int, val ok: Int,
    val avgMs: Int?, val jitterMs: Int?, val lossPct: Int, val kbps: Int?
)

/** Measures each server: latency, jitter, loss (TCP connect tests) and optional download speed through the proxy. */
object QualityTest {

    suspend fun run(servers: List<ProxyServer>, speed: Boolean): List<Quality> = coroutineScope {
        servers.map { s -> async(Dispatchers.IO) { measure(s, speed) } }.awaitAll()
    }

    private fun measure(s: ProxyServer, speed: Boolean): Quality {
        val r = ArrayList<Int>()
        for (i in 1..10) {
            r.add(SmartRouter.pingMs(s))
            if (i == 3 && r.all { it < 0 }) break // clearly down: don't wait for 10 timeouts
            Thread.sleep(100)
        }
        val ok = r.filter { it >= 0 }
        return Quality(
            server = s, sent = r.size, ok = ok.size,
            avgMs = if (ok.isEmpty()) null else ok.average().toInt(),
            jitterMs = if (ok.size >= 2) ok.max() - ok.min() else null,
            lossPct = (100 * (r.size - ok.size)) / r.size,
            kbps = if (speed && ok.isNotEmpty()) speedKbps(s) else null
        )
    }

    /** Downloads ~2 MB through the proxy and reports kilobits per second (null if it failed). */
    private fun speedKbps(s: ProxyServer): Int? = try {
        val raw = Upstream.open(s, "speed.cloudflare.com", 443)
        raw.soTimeout = 20000
        val ssl = (SSLSocketFactory.getDefault() as SSLSocketFactory)
            .createSocket(raw, "speed.cloudflare.com", 443, true) as SSLSocket
        ssl.startHandshake()
        ssl.getOutputStream().apply {
            write("GET /__down?bytes=2000000 HTTP/1.1\r\nHost: speed.cloudflare.com\r\nConnection: close\r\n\r\n".toByteArray())
            flush()
        }
        val t0 = System.nanoTime()
        val input = ssl.getInputStream()
        val buf = ByteArray(16384)
        var total = 0L
        while (true) {
            val n = input.read(buf)
            if (n < 0) break
            total += n
        }
        try { ssl.close() } catch (_: Exception) {}
        val sec = (System.nanoTime() - t0) / 1e9
        if (total < 100_000 || sec <= 0.0) null else (total * 8 / 1000 / sec).toInt()
    } catch (e: Exception) { null }
}
