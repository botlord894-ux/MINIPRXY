package com.omniproxy.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.DevLog
import com.omniproxy.app.Diagnostics
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.TaskMode
import com.omniproxy.app.VpnPhase
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ui.VpnActions
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

@Composable
fun HomeScreen(actions: VpnActions, onOpenSettings: () -> Unit, onOpenTruth: (ProxyServer) -> Unit) {
    val ctx = LocalContext.current
    val activeMode by OmniVpnService.mode.collectAsState()
    val stickyActive by OmniVpnService.stickyIp.collectAsState()
    val currentIp by OmniVpnService.currentIp.collectAsState()
    val pingMs by OmniVpnService.pingMs.collectAsState()
    val savedMb by OmniVpnService.savedMb.collectAsState()
    val status by OmniVpnService.statusText.collectAsState()
    val phase by OmniVpnService.phase.collectAsState()
    val offer by OmniVpnService.failoverOffer.collectAsState()
    val backupFrom by OmniVpnService.usingBackupFrom.collectAsState()

    var selected by rememberSaveable {
        mutableStateOf(runCatching {
            TaskMode.valueOf(ctx.getSharedPreferences("omni_prefs", 0).getString("default_mode", "STREAMING") ?: "STREAMING")
        }.getOrDefault(TaskMode.STREAMING))
    }
    LaunchedEffect(activeMode) { activeMode?.let { if (it != TaskMode.BANKING) selected = it } }

    // The Connect button shows the REAL service phase. Nothing here is driven by animation progress.
    val blocked = currentIp == "BLOCKED"
    val ls = if (blocked) LiquidState.FAILED else when (phase) {
        VpnPhase.CONNECTING -> LiquidState.CONNECTING
        VpnPhase.RECONNECTING -> LiquidState.RECONNECTING
        VpnPhase.CONNECTED -> LiquidState.CONNECTED
        VpnPhase.DISCONNECTING -> LiquidState.DISCONNECTING
        VpnPhase.FAILED -> LiquidState.FAILED
        VpnPhase.DISCONNECTED -> LiquidState.DISCONNECTED
    }
    val server = currentIp?.let { ip -> SmartRouter.SERVERS.firstOrNull { it.host == ip } }
    val tunnelUp = ls == LiquidState.CONNECTED

    val pick: (TaskMode) -> Unit = { m ->
        selected = m
        if ((ls == LiquidState.CONNECTED || ls == LiquidState.RECONNECTING) && activeMode != m) actions.toggleMode(m)
    }
    val onLiquidClick: () -> Unit = {
        when (ls) {
            LiquidState.DISCONNECTED -> actions.toggleMode(selected)
            LiquidState.CONNECTED -> actions.disconnect()
            LiquidState.FAILED -> if (blocked) actions.disconnect() else actions.toggleMode(selected)
            else -> Unit // taps are ignored while the service is changing state: no repeated attempts
        }
    }
    val onLiquidLong: () -> Unit = { if (ls == LiquidState.CONNECTING || ls == LiquidState.RECONNECTING) actions.disconnect() }

    val ap = AppearanceStore.current
    val liquid = ap.liquid
    val reduce = rememberReduceMotion()
    val pal = AppearanceStore.palette
    val floating = liquid.position != "center"
    val desc = "Connect button. ${liquidLabel(ls)}"

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxW = maxWidth
        val maxH = maxHeight
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(Modifier.height(8.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                OmniLogo(38.dp)
                Spacer(Modifier.width(10.dp))
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(color = TextPrimary)) { append("Omni") }
                        withStyle(SpanStyle(color = PurpleLight)) { append("Proxy") }
                    },
                    fontSize = 24.sp, fontWeight = FontWeight.Bold
                )
                Spacer(Modifier.weight(1f))
                IconButton(onClick = onOpenSettings) { Icon(Icons.Filled.Settings, "Settings", tint = TextSecondary) }
            }

            if (liquid.position == "top") Spacer(Modifier.height((liquid.floatSize * 1.5f).dp))

            if (!floating) {
                Spacer(Modifier.height(8.dp))
                LiquidConnectButton(
                    state = ls, style = liquid, palette = pal, imageAccent = ap.bg.imageAccent,
                    sizeDp = liquid.size.dp, reduceMotion = reduce, description = desc,
                    onClick = onLiquidClick, onLongPress = onLiquidLong
                )
            }
            Text(
                liquidLabel(ls),
                color = when (ls) { LiquidState.CONNECTED -> Green; LiquidState.FAILED -> Danger; LiquidState.RECONNECTING -> Amber; else -> TextPrimary },
                fontSize = 18.sp, fontWeight = FontWeight.SemiBold
            )
            Text(
                when (ls) {
                    LiquidState.DISCONNECTED -> "Mode: ${selected.title}"
                    LiquidState.CONNECTING -> "Hold the button to cancel"
                    LiquidState.CONNECTED -> "Tap to disconnect"
                    LiquidState.RECONNECTING -> "Recovering the connection. Hold to cancel"
                    LiquidState.DISCONNECTING -> "Please wait"
                    LiquidState.FAILED -> if (blocked) "Kill switch is blocking your apps" else "Tap to try again"
                },
                color = TextSecondary, fontSize = 13.sp
            )

            if (ls == LiquidState.FAILED) {
                Spacer(Modifier.height(12.dp))
                OmniCard(Modifier.fillMaxWidth(), borderColor = Danger) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Connection failed", color = Danger, fontWeight = FontWeight.Bold)
                        Text(
                            if (blocked) "The proxy stopped answering and the kill switch is blocking your protected apps."
                            else status.removePrefix("OFF • ").ifBlank { "The VPN could not be started." },
                            color = TextSecondary, fontSize = 13.sp
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OmniButton(onClick = { if (blocked) actions.disconnect() else actions.toggleMode(selected) }) {
                                Text(if (blocked) "Disconnect" else "Try again")
                            }
                            OmniOutlinedButton(onClick = {
                                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                cm.setPrimaryClip(ClipData.newPlainText("OmniProxy report", Diagnostics.report(ctx)))
                            }) { Text("Copy diagnostics") }
                        }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            OmniCard(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    when {
                        blocked -> IconBadge(Icons.Filled.Block, Danger)
                        tunnelUp && server != null -> FlagBadge(server.country)
                        else -> IconBadge(Icons.Filled.Public, PurpleLight)
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            when {
                                blocked -> "Kill switch active"
                                tunnelUp && server != null -> "${server.country.uppercase()}  ${server.host}"
                                else -> "Direct connection"
                            }, color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            when {
                                blocked -> "Traffic blocked: proxy unreachable"
                                tunnelUp && server != null -> server.name
                                else -> "No proxy active"
                            }, color = TextSecondary, fontSize = 13.sp
                        )
                    }
                    if (tunnelUp && pingMs > 0 && !blocked) Text("$pingMs ms", color = Green, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                    else Icon(Icons.Filled.SignalCellularAlt, null, tint = TextSecondary)
                }
            }

            if (tunnelUp && server != null) {
                Spacer(Modifier.height(10.dp))
                // Real values only. Anything we haven't measured says so.
                val prof = ProfileStore.get(server)
                OmniCard(Modifier.fillMaxWidth(), onClick = { onOpenTruth(server) }) {
                    Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("Connection status", color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                            Text("Run full test", color = PurpleLight, fontSize = 12.sp)
                            Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary)
                        }
                        StatusLine("VPN interface", "Active", true)
                        StatusLine("Proxy", if (pingMs > 0) "Reachable, $pingMs ms" else "Not measured", pingMs > 0)
                        StatusLine("Exit IP", if (prof.lastExitIp != null) "Verified: ${prof.lastExitIp}" else "Not checked yet", prof.lastExitIp != null)
                        StatusLine("DNS", if (DevLog.engine.contains("mapdns")) "Resolved by the proxy" else "Using a DNS server", true)
                    }
                }
            }

            offer?.let { k ->
                val cand = SmartRouter.SERVERS.firstOrNull { "${it.host}:${it.port}" == k }
                Spacer(Modifier.height(10.dp))
                OmniCard(Modifier.fillMaxWidth(), borderColor = Amber) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Proxy down. Backup ready", color = Amber, fontWeight = FontWeight.Bold)
                        Text("${cand?.name ?: k} answered and its exit IP was verified. Switching may change your IP. " +
                            "Your protected apps stay blocked until you choose.", color = TextSecondary, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OmniButton(onClick = actions.approveFailover) { Text("Switch to backup") }
                            OmniOutlinedButton(onClick = actions.declineFailover) { Text("Stay blocked") }
                        }
                    }
                }
            }
            backupFrom?.let { k ->
                val orig = SmartRouter.SERVERS.firstOrNull { "${it.host}:${it.port}" == k }
                Spacer(Modifier.height(10.dp))
                OmniCard(Modifier.fillMaxWidth(), borderColor = Amber) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Using a backup server", color = Amber, fontWeight = FontWeight.Bold)
                        Text("Your exit IP may differ from ${orig?.name ?: k}.", color = TextSecondary, fontSize = 12.sp)
                        Spacer(Modifier.height(8.dp))
                        OmniButton(onClick = actions.returnToOriginal) { Text("Return to original") }
                    }
                }
            }

            Spacer(Modifier.height(22.dp))
            Text("Choose Mode", color = TextPrimary, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                ModeCard(Modifier.weight(1f), Icons.Filled.Movie, "Streaming", "AdGuard DNS", Purple, selected == TaskMode.STREAMING) { pick(TaskMode.STREAMING) }
                ModeCard(Modifier.weight(1f), Icons.Filled.VideogameAsset, "Gaming",
                    if (activeMode == TaskMode.GAMING && pingMs > 0) "$pingMs ms" else "UDP", Green, selected == TaskMode.GAMING) { pick(TaskMode.GAMING) }
                ModeCard(Modifier.weight(1f), Icons.Filled.Eco, "Data Saver",
                    if (activeMode == TaskMode.DATA_SAVER) "Saved %.1f MB".format(savedMb) else "Est. ~30%", Cyan, selected == TaskMode.DATA_SAVER) { pick(TaskMode.DATA_SAVER) }
            }

            Spacer(Modifier.height(12.dp))
            val banking = activeMode == TaskMode.BANKING
            OmniCard(Modifier.fillMaxWidth(), borderColor = if (banking) Amber else Border, onClick = { actions.toggleMode(TaskMode.BANKING) }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.Shield, Amber)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Banking Mode", color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                        Text(if (banking) "Your bank sees your real IP for safety" else "Direct connection, proxy bypassed",
                            color = if (banking) Amber else TextSecondary, fontSize = 12.sp)
                    }
                    Switch(checked = banking, onCheckedChange = { actions.toggleMode(TaskMode.BANKING) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Amber, checkedThumbColor = Color.White,
                            uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
                }
            }
            // keep content clear of a floating button at the bottom
            if (liquid.position == "bottom" || liquid.position == "bottom_left" || liquid.position == "bottom_right")
                Spacer(Modifier.height((liquid.floatSize * 1.7f).dp))
            Spacer(Modifier.height(24.dp))
        }

        if (floating) {
            val sizeDp = liquid.floatSize.dp
            val outer = sizeDp * 1.7f
            val mod = when (liquid.position) {
                "top" -> Modifier.align(Alignment.TopCenter).padding(top = 52.dp)
                "bottom" -> Modifier.align(Alignment.BottomCenter).padding(bottom = 4.dp)
                "bottom_left" -> Modifier.align(Alignment.BottomStart).padding(start = 4.dp, bottom = 4.dp)
                "bottom_right" -> Modifier.align(Alignment.BottomEnd).padding(end = 4.dp, bottom = 4.dp)
                else -> Modifier.align(Alignment.TopStart).offset(
                    x = ((maxW - outer) * liquid.posX.coerceIn(0f, 1f)).coerceAtLeast(0.dp),
                    y = ((maxH - outer) * liquid.posY.coerceIn(0f, 1f)).coerceAtLeast(0.dp)
                )
            }
            LiquidConnectButton(
                state = ls, style = liquid, palette = pal, imageAccent = ap.bg.imageAccent, sizeDp = sizeDp,
                reduceMotion = reduce, modifier = mod, description = desc, onClick = onLiquidClick, onLongPress = onLiquidLong
            )
        }
    }
}

@Composable
private fun StatusLine(label: String, value: String, ok: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        StatusDot(if (ok) Green else TextSecondary)
        Spacer(Modifier.width(10.dp))
        Text(label, color = TextSecondary, fontSize = 12.sp, modifier = Modifier.weight(1f))
        Text(value, color = TextPrimary, fontSize = 12.sp)
    }
}

@Composable
private fun ModeCard(
    modifier: Modifier, icon: ImageVector, title: String, sub: String,
    accent: Color, selected: Boolean, onClick: () -> Unit
) {
    OmniCard(modifier = modifier, borderColor = if (selected) accent else Border, onClick = onClick) {
        Column(Modifier.fillMaxWidth().padding(vertical = 14.dp, horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            IconBadge(icon, accent)
            Spacer(Modifier.height(10.dp))
            Text(title, color = TextPrimary, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(sub, color = TextSecondary, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Icon(if (selected) Icons.Filled.CheckCircle else Icons.Filled.ChevronRight, null,
                tint = if (selected) accent else TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}
