package com.omniproxy.app.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.FilterQuality
import androidx.compose.ui.graphics.ImageBitmap
import com.omniproxy.app.R
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import com.omniproxy.app.appearance.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * Draws the app background for [a]. Image backgrounds are decoded at a limited size (smaller for blur,
 * which is done by decoding small and scaling up, so it works on every Android version). If the image is
 * missing or can't be decoded, the original background is drawn instead.
 */
@Composable
fun OmniBackground(a: Appearance, modifier: Modifier = Modifier.fillMaxSize(), reduceMotion: Boolean = false) {
    val ctx = LocalContext.current
    val s = a.bg
    val imageMode = s.mode == BgMode.IMAGE || s.mode == BgMode.IMAGE_DARK || s.mode == BgMode.IMAGE_COLOR || s.mode == BgMode.IMAGE_BLUR
    val wantsImage = (s.imageFile != null || s.bundledWallpaper != null) && imageMode
    val bundled = remember(s.bundledWallpaper) {
        val id = when (s.bundledWallpaper) {
            "midnight" -> R.drawable.wallpaper_midnight
            "deep_ocean" -> R.drawable.wallpaper_deep_ocean
            "northern_lights" -> R.drawable.wallpaper_northern_lights
            "abstract_glass" -> R.drawable.wallpaper_abstract_glass
            "dark_technology" -> R.drawable.wallpaper_dark_technology
            else -> 0
        }
        if (id == 0) null else runCatching { ImageBitmap.imageResource(ctx.resources, id) }.getOrNull()
    }
    val target = if (s.mode == BgMode.IMAGE_BLUR) (1280 - s.blur * 1230).toInt().coerceAtLeast(48) else 1280
    val image by produceState<ImageBitmap?>(null, s.imageFile, target, wantsImage) {
        value = if (wantsImage && s.imageFile != null) withContext(Dispatchers.IO) { BackgroundImages.load(ctx, s.imageFile, target) } else null
        if (wantsImage && s.imageFile != null) AppearanceStore.imageMissing = value == null
    }
    val cf = remember(s.brightness, s.saturation) { imageFilter(s.brightness, s.saturation) }
    val scrims = remember(a) { Resolver.scrims(a) }
    val p = a.palette

    if (s.mode == BgMode.ANIMATED) {
        AnimatedGradient(s, p, reduceMotion, modifier)
        return
    }
    Canvas(modifier) {
        val img = image ?: bundled
        when {
            wantsImage && img != null -> {
                drawRect(Color(p.bg))
                drawFitted(img, s.fit, s.scale, cf)
                for ((c, al) in scrims) if (al > 0f) drawRect(Color(c).copy(alpha = al.coerceIn(0f, 1f)))
            }
            s.mode == BgMode.SOLID -> drawRect(Color(s.solid))
            s.mode == BgMode.GRADIENT ->
                drawRect(Brush.linearGradient(listOf(Color(s.gradA), Color(s.gradB), Color(s.gradC)), Offset.Zero, Offset(size.width, size.height)))
            else -> drawDefault(p)
        }
    }
}

private fun DrawScope.drawDefault(p: Palette) {
    drawRect(Brush.verticalGradient(listOf(Color(p.bg), Color(p.bg2))))
    drawRect(Brush.radialGradient(listOf(Color(p.accent).copy(alpha = 0.20f), Color.Transparent),
        center = Offset(size.width * 0.5f, size.height * 0.18f), radius = size.width * 0.95f))
    drawRect(Brush.radialGradient(listOf(Color(p.accent2).copy(alpha = 0.10f), Color.Transparent),
        center = Offset(size.width * 0.9f, size.height * 0.95f), radius = size.width * 0.9f))
}

@Composable
private fun AnimatedGradient(s: BackgroundSpec, p: Palette, reduceMotion: Boolean, modifier: Modifier) {
    var t by remember { mutableFloatStateOf(0f) }
    val started = rememberStarted()
    val animating = started && !reduceMotion
    LaunchedEffect(animating) {
        if (animating) {
            var last = withFrameNanosCompat()
            var acc = 0L
            while (true) {
                val now = withFrameNanosCompat()
                acc += now - last; last = now
                if (acc >= 50_000_000L) { t += acc / 1_000_000_000f; acc = 0L } // ~20 fps is plenty for a slow drift
            }
        }
    }
    val brush = remember(s.gradA, s.gradB, s.gradC) {
        Brush.linearGradient(listOf(Color(s.gradA), Color(s.gradB), Color(s.gradC), Color(s.gradA)))
    }
    Canvas(modifier) {
        val big = max(size.width, size.height) * 1.9f
        rotate(degrees = (t * 6f) % 360f, pivot = center) {
            translate(left = center.x - big / 2, top = center.y - big / 2) { drawRect(brush, size = Size(big, big)) }
        }
    }
}

private fun imageFilter(brightness: Float, saturation: Float): ColorFilter {
    val m = ColorMatrix().apply { setToSaturation(saturation.coerceIn(0f, 2f)) }
    val off = brightness.coerceIn(-0.5f, 0.5f) * 255f
    m.timesAssign(ColorMatrix(floatArrayOf(
        1f, 0f, 0f, 0f, off,
        0f, 1f, 0f, 0f, off,
        0f, 0f, 1f, 0f, off,
        0f, 0f, 0f, 1f, 0f
    )))
    return ColorFilter.colorMatrix(m)
}

private fun DrawScope.drawFitted(img: ImageBitmap, fit: ImageFit, userScale: Float, cf: ColorFilter) {
    val sw = size.width; val sh = size.height
    val iw = img.width.toFloat(); val ih = img.height.toFloat()
    val (dw, dh) = when (fit) {
        ImageFit.FILL -> sw to sh
        ImageFit.FIT -> { val k = min(sw / iw, sh / ih); iw * k to ih * k }
        ImageFit.CROP -> { val k = max(sw / iw, sh / ih); iw * k to ih * k }
        ImageFit.SCALE -> { val k = max(sw / iw, sh / ih) * userScale.coerceIn(0.5f, 3f); iw * k to ih * k }
        ImageFit.CENTER -> iw to ih
    }
    drawImage(
        image = img, srcOffset = IntOffset.Zero, srcSize = IntSize(img.width, img.height),
        dstOffset = IntOffset(((sw - dw) / 2).roundToInt(), ((sh - dh) / 2).roundToInt()),
        dstSize = IntSize(dw.roundToInt().coerceAtLeast(1), dh.roundToInt().coerceAtLeast(1)),
        colorFilter = cf, filterQuality = FilterQuality.Low
    )
}
