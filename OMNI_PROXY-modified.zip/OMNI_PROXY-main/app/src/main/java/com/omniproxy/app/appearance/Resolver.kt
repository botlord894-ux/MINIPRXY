package com.omniproxy.app.appearance

/** What the UI actually draws with after readability fixes. The stored palette is never overwritten. */
data class Resolved(val palette: Palette, val cardAlpha: Float, val light: Boolean, val bgLum: Float)

/** Pure function, no Android state: it makes sure text stays readable on every theme and background. */
object Resolver {
    private const val BLACK = 0xFF shl 24
    private const val WHITE = (0xFF shl 24) or 0xFFFFFF

    private fun isImage(a: Appearance): Boolean {
        val s = a.bg
        return (s.imageFile != null || s.bundledWallpaper != null) &&
            (s.mode == BgMode.IMAGE || s.mode == BgMode.IMAGE_DARK || s.mode == BgMode.IMAGE_COLOR || s.mode == BgMode.IMAGE_BLUR)
    }

    /**
     * Layers drawn over a photo, in order: (1) your own overlay, (2) if "Keep text readable" is on, an automatic
     * scrim that pushes the photo toward the theme's polarity (dark scrim for dark themes, white for light themes)
     * just far enough for text to be readable. Empty for non-photo backgrounds.
     */
    fun scrims(a: Appearance): List<Pair<Int, Float>> {
        if (!isImage(a)) return emptyList()
        val s = a.bg
        val userColor = if (s.mode == BgMode.IMAGE_COLOR || s.mode == BgMode.IMAGE_BLUR) s.overlayColor else BLACK
        val raw = if (s.mode == BgMode.IMAGE) 0f else s.overlay.coerceIn(0f, 0.95f)
        val out = ArrayList<Pair<Int, Float>>(2)
        if (raw > 0f) out.add(userColor to raw)
        if (s.autoContrast) {
            var l = (s.imageLum + s.brightness * 0.6f).coerceIn(0f, 1f)
            if (raw > 0f) l = l * (1 - raw) + ColorUtils.lum(userColor) * raw
            val darkTheme = ColorUtils.lum(a.palette.card) < 0.5f
            if (darkTheme && l > 0.15f) out.add(BLACK to ((l - 0.15f) / l).coerceIn(0f, 0.85f))
            else if (!darkTheme && l < 0.72f) out.add(WHITE to ((0.72f - l) / (1f - l)).coerceIn(0f, 0.85f))
        }
        return out
    }

    fun resolve(a: Appearance): Resolved {
        val p = a.palette
        val s = a.bg
        val bgEff: Int
        val cardAlpha: Float
        if (isImage(a)) {
            var l = (s.imageLum + s.brightness * 0.6f).coerceIn(0f, 1f)
            for ((c, al) in scrims(a)) l = l * (1 - al) + ColorUtils.lum(c) * al
            bgEff = ColorUtils.gray(l)
            cardAlpha = if (s.autoContrast) maxOf(a.card.alpha, 0.72f) else a.card.alpha
        } else {
            bgEff = when (s.mode) {
                BgMode.SOLID -> s.solid
                BgMode.GRADIENT, BgMode.ANIMATED -> ColorUtils.blend(ColorUtils.blend(s.gradA, s.gradB, 0.5f), s.gradC, 0.33f)
                else -> p.bg
            }
            cardAlpha = a.card.alpha
        }

        val cardComp = ColorUtils.composite(p.card, cardAlpha, bgEff)
        val text = if (a.highContrast)
            ColorUtils.readable(if (ColorUtils.lum(bgEff) > 0.5f) BLACK else WHITE, cardComp, bgEff)
        else ColorUtils.readable(p.text, cardComp, bgEff)
        var sec = p.textSecondary
        if (a.highContrast || minOf(ColorUtils.contrast(sec, cardComp), ColorUtils.contrast(sec, bgEff)) < 3.5f)
            sec = ColorUtils.blend(text, bgEff, if (a.highContrast) 0.15f else 0.30f)
        val border = if (a.highContrast) ColorUtils.blend(text, bgEff, 0.45f) else p.border
        val l = ColorUtils.lum(bgEff)
        return Resolved(p.copy(text = text, textSecondary = sec, border = border), cardAlpha, l > 0.5f, l)
    }
}
