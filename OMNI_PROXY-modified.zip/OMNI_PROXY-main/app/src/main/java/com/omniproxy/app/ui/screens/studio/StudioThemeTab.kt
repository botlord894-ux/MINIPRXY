package com.omniproxy.app.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.*
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

private val FIELDS = listOf(
    "Main background", "Secondary background", "Card surfaces", "Primary accent", "Secondary accent",
    "Connect button", "Connect button glow", "Text", "Secondary text", "Borders",
    "Navigation bar", "Selected navigation item", "Connected status", "Warning status", "Error status"
)

private fun getField(p: Palette, i: Int) = when (i) {
    0 -> p.bg; 1 -> p.bg2; 2 -> p.card; 3 -> p.accent; 4 -> p.accent2; 5 -> p.connect; 6 -> p.connectGlow
    7 -> p.text; 8 -> p.textSecondary; 9 -> p.border; 10 -> p.nav; 11 -> p.navSelected
    12 -> p.connected; 13 -> p.warning; else -> p.error
}

private fun setField(p: Palette, i: Int, c: Int) = when (i) {
    0 -> p.copy(bg = c); 1 -> p.copy(bg2 = c); 2 -> p.copy(card = c); 3 -> p.copy(accent = c); 4 -> p.copy(accent2 = c)
    5 -> p.copy(connect = c); 6 -> p.copy(connectGlow = c); 7 -> p.copy(text = c); 8 -> p.copy(textSecondary = c)
    9 -> p.copy(border = c); 10 -> p.copy(nav = c); 11 -> p.copy(navSelected = c)
    12 -> p.copy(connected = c); 13 -> p.copy(warning = c); else -> p.copy(error = c)
}

@Composable
fun ThemeTab(draft: Appearance, upd: ((Appearance) -> Appearance) -> Unit, onSavePreset: () -> Unit) {
    var editing by remember { mutableStateOf<Int?>(null) }
    var rename by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val all = AppearanceStore.allThemes(draft)
    val selected = all.firstOrNull { it.id == draft.themeId }
    val isUser = selected != null && !selected.builtIn

    Column(Modifier.fillMaxWidth()) {
        SectionTitle("Preset themes")
        all.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { e ->
                    ThemeTile(e, draft.themeId == e.id, Modifier.weight(1f),
                        onClick = { upd { a -> AppearanceStore.withTheme(a, e) } })
                }
                repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Box(
                Modifier.size(width = 78.dp, height = 78.dp).clip(RoundedCornerShape(16.dp)).background(Surface2)
                    .border(1.dp, if (draft.themeId == "custom") Purple else Border, RoundedCornerShape(16.dp))
                    .pointerInput(Unit) { detectTapGestures(onTap = { upd { a -> a.copy(themeId = "custom") } }) },
                contentAlignment = Alignment.Center
            ) { Text("Custom\nTheme", color = TextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center) }
        }
        OmniButton(onClick = onSavePreset, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Filled.Add, null, modifier = Modifier.size(18.dp)); Text("Create Custom Theme")
        }
        if (isUser) {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OmniOutlinedButton(onClick = { rename = true }, modifier = Modifier.weight(1f)) { Text("Rename") }
                OmniOutlinedButton(onClick = {
                    val copy = ThemeEntry("user_${System.currentTimeMillis()}", "${selected!!.name} copy", draft.palette, false)
                    val list = draft.customThemes + copy
                    upd { a -> a.copy(customThemes = list, themeId = copy.id) }
                }, modifier = Modifier.weight(1f)) { Text("Duplicate") }
                TextButton(onClick = { confirmDelete = true }, modifier = Modifier.weight(1f)) { Text("Delete", color = Danger) }
            }
        } else if (selected != null) {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Lock, null, tint = TextSecondary, modifier = Modifier.size(14.dp)); Spacer(Modifier.width(6.dp))
                Text("Built-in theme: it can't be deleted. Change a color to make your own copy.", color = TextSecondary, fontSize = 11.sp)
            }
        }

        SectionTitle("Colors")
        Text("Tap a color to change it. Text colors are checked for readability automatically.", color = TextSecondary, fontSize = 11.sp)
        FIELDS.forEachIndexed { i, label -> ColorRow(label, getField(draft.palette, i)) { editing = i } }
    }

    editing?.let { i ->
        ColorPickerDialog(FIELDS[i], getField(draft.palette, i), onDismiss = { editing = null }) { c ->
            editing = null
            upd { a ->
                val np = setField(a.palette, i, c)
                var out = a.copy(palette = np, themeId = if (a.themeId.startsWith("user_")) a.themeId else "custom")
                if ((i == 5 || i == 6) && a.liquid.autoHarmony && a.liquid.preset != "custom_liquid" && !a.liquid.adaptive)
                    out = out.copy(liquid = AppearanceStore.harmonized(out.liquid, np))
                out
            }
        }
    }
    if (rename && selected != null) NameDialog("Rename theme", selected.name, { rename = false }) { n ->
        rename = false
        val list = draft.customThemes.map { if (it.id == selected.id) it.copy(name = n) else it }
        upd { a -> a.copy(customThemes = list) }
    }
    if (confirmDelete && selected != null) AlertDialog(
        onDismissRequest = { confirmDelete = false }, containerColor = CardBg,
        title = { Text("Delete \"${selected.name}\"?", color = TextPrimary) },
        text = { Text("This only removes your saved theme.", color = TextSecondary) },
        confirmButton = {
            TextButton(onClick = {
                confirmDelete = false
                val list = draft.customThemes.filter { it.id != selected.id }
                        upd { a -> AppearanceStore.withTheme(a.copy(customThemes = list), Presets.themes.first()) }
            }) { Text("Delete", color = Danger) }
        },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = TextSecondary) } }
    )
}

@Composable
private fun ThemeTile(e: ThemeEntry, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val p = e.palette
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(
            Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(16.dp))
                .background(Brush.linearGradient(listOf(Color(p.bg), Color(p.bg2))))
                .border(if (selected) 2.dp else 1.dp, if (selected) Color(p.accent) else Border, RoundedCornerShape(16.dp))
                .pointerInput(e.id) { detectTapGestures(onTap = { onClick() }) },
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(26.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Color(p.connect), Color(p.accent2)))))
        }
        Text(e.name, color = if (selected) TextPrimary else TextSecondary, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(top = 4.dp))
    }
}
