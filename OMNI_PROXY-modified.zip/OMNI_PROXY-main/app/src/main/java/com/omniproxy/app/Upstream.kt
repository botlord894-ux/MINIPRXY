package com.omniproxy.app

import android.util.Base64
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/** Opens TCP connections THROUGH one of your proxy servers (HTTP CONNECT or SOCKS5). */
object Upstream {

    fun readHead(i: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 16384) {
            val b = i.read()
            if (b < 0) return null
            sb.append(b.toChar())
            if (sb.endsWith("\r\n\r\n")) return sb.toString()
        }
        return null
    }

    /** Returns a socket already connected to [host]:[port] via the proxy. The caller closes it. */
    fun open(server: ProxyServer, host: String, port: Int, protect: (Socket) -> Unit = {}): Socket {
        val s = Socket()
        protect(s) // keeps this socket outside our own VPN tunnel
        s.connect(InetSocketAddress(server.host, server.port), 8000)
        s.soTimeout = 10000 // handshake timeout only
        try {
            if (server.type == ProxyType.HTTP) httpConnect(server, s, host, port) else socks5(server, s, host, port)
        } catch (e: Exception) { try { s.close() } catch (_: Exception) {}; throw e }
        s.soTimeout = 0
        return s
    }

    private fun httpConnect(server: ProxyServer, s: Socket, host: String, port: Int) {
        val req = StringBuilder("CONNECT $host:$port HTTP/1.1\r\nHost: $host:$port\r\n")
        server.user?.let {
            val cred = Base64.encodeToString("$it:${server.pass ?: ""}".toByteArray(), Base64.NO_WRAP)
            req.append("Proxy-Authorization: Basic $cred\r\n")
        }
        req.append("\r\n")
        s.getOutputStream().write(req.toString().toByteArray()); s.getOutputStream().flush()
        val resp = readHead(s.getInputStream()) ?: throw IOException("no response")
        if (!resp.substringBefore("\r\n").contains(" 200")) throw IOException("upstream refused")
    }

    private fun socks5(server: ProxyServer, s: Socket, host: String, port: Int) {
        val o = DataOutputStream(s.getOutputStream()); val i = DataInputStream(s.getInputStream())
        val auth = server.user != null
        o.write(if (auth) byteArrayOf(5, 2, 0, 2) else byteArrayOf(5, 1, 0)); o.flush()
        val m = ByteArray(2).also { i.readFully(it) }
        if (m[1].toInt() == 2) { // username/password login
            val u = server.user!!.toByteArray(); val p = (server.pass ?: "").toByteArray()
            o.write(byteArrayOf(1, u.size.toByte())); o.write(u)
            o.write(byteArrayOf(p.size.toByte())); o.write(p); o.flush()
            val r = ByteArray(2).also { i.readFully(it) }
            if (r[1].toInt() != 0) throw IOException("socks auth failed")
        } else if (m[1].toInt() != 0) throw IOException("socks method")
        val h = host.toByteArray()
        o.write(byteArrayOf(5, 1, 0, 3, h.size.toByte())); o.write(h) // hostname is resolved BY the proxy
        o.write(byteArrayOf((port shr 8).toByte(), port.toByte())); o.flush()
        val rep = ByteArray(4).also { i.readFully(it) }
        if (rep[1].toInt() != 0) throw IOException("socks connect failed")
        val skip = when (rep[3].toInt()) { 1 -> 4; 4 -> 16; else -> i.readUnsignedByte() }
        i.readFully(ByteArray(skip + 2))
    }
}
