package com.omniproxy.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.Fmt
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ServerStore
import com.omniproxy.app.UsageStore
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.delay

/** Data & Usage: figures come from real counters through the tunnel, never from estimates. */
@Composable
fun DataScreen(onBack: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    val bps by OmniVpnService.throughputBps.collectAsState()
    val currentIp by OmniVpnService.currentIp.collectAsState()
    var budget by remember { mutableIntStateOf(UsageStore.budgetGb) }

    val todayBytes = remember(tick) { UsageStore.todayBytes() }
    val todaySecs = remember(tick) { UsageStore.todaySeconds() }
    val interruptions = remember(tick) { UsageStore.todayInterruptions() }
    val reconnects = remember(tick) { UsageStore.todayReconnects() }
    val monthBytes = remember(tick) { UsageStore.monthBytes() }
    val top = remember(tick) { UsageStore.topProfileMonth() }
    val pct = remember(tick, budget) { UsageStore.budgetPercent() }
    var confirmReset by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Data & Usage", "Real counters from your tunnel.")
        Spacer(Modifier.height(16.dp))

        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                Text("TODAY", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 10.dp, 16.dp, 2.dp))
                Row2("Routed traffic", Fmt.bytes(todayBytes))
                Row2("Active session time", Fmt.duration(todaySecs))
                Row2("Connection interruptions", "$interruptions")
                Row2("Reconnections", "$reconnects")
                Row2("Live throughput", if (currentIp != null && currentIp != "BLOCKED") Fmt.speed((bps * 8 / 1000).toInt()) else "Not connected")
            }
        }
        Spacer(Modifier.height(14.dp))
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                Text("THIS MONTH", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(16.dp, 10.dp, 16.dp, 2.dp))
                Row2("Routed traffic", Fmt.bytes(monthBytes))
                Row2("Most-used profile", top?.let { t ->
                    (ServerStore.list().firstOrNull { "${it.host}:${it.port}" == t.first }?.name ?: t.first) + " (${Fmt.bytes(t.second)})"
                } ?: "None yet")
            }
        }

        Spacer(Modifier.height(18.dp))
        Text("MONTHLY DATA BUDGET", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(0 to "Off", 1 to "1 GB", 2 to "2 GB", 5 to "5 GB", 10 to "10 GB").forEach { (gb, label) ->
                Segment(label, budget == gb, Modifier.weight(1f)) { budget = gb; UsageStore.budgetGb = gb }
            }
        }
        if (pct != null) {
            Spacer(Modifier.height(12.dp))
            LinearProgressIndicator(
                progress = { (pct / 100f).coerceIn(0f, 1f) },
                modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = if (pct >= 100) Danger else if (pct >= 80) Amber else Green, trackColor = Border
            )
            Text("$pct% of ${budget} GB used", color = TextSecondary, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            if (pct >= 80) {
                Spacer(Modifier.height(10.dp))
                InfoBanner(if (pct >= 100) "You have used your monthly budget." else "You are close to your monthly budget.",
                    accent = Amber, icon = Icons.Filled.Warning)
            }
        }

        Spacer(Modifier.height(18.dp))
        InfoBanner("Counters only include traffic through the tunnel with a SOCKS5 server. A proxy by itself does not reduce data use, and Data Saver mode only shows an estimate.")
        TextButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth()) { Text("Reset usage counters", color = Danger) }
        Spacer(Modifier.height(24.dp))
    }
    if (confirmReset) AlertDialog(
        onDismissRequest = { confirmReset = false }, containerColor = CardBg,
        title = { Text("Reset all counters?", color = Color.White) },
        text = { Text("Today's and this month's usage will be cleared.", color = TextSecondary) },
        confirmButton = { TextButton(onClick = { UsageStore.clear(); confirmReset = false; tick++ }) { Text("Reset", color = Danger) } },
        dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Cancel", color = TextSecondary) } }
    )
}

@Composable
private fun Row2(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(1f))
        Text(value, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}
