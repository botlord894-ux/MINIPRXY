package com.omniproxy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.ProxyType
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

/** Shows how your apps are INTENDED to connect. It is a picture of your settings, not proof that routing works. */
@Composable
fun SimulatorScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val router = remember { StickyRouter(ctx) }
    val ver by StickyRouter.version.collectAsState()
    val sver by ServerStore.version.collectAsState()
    val active by OmniVpnService.stickyIp.collectAsState()
    var tapped by remember { mutableStateOf<String?>(null) }

    val groups = remember(ver, sver) {
        SmartRouter.SERVERS.map { s -> s to StickyRouter.PICKABLE_APPS.filter { router.get(it)?.ip == s.host } }
            .filter { it.second.isNotEmpty() }
    }
    val direct = remember(ver, sver) { StickyRouter.PICKABLE_APPS.filter { router.get(it) == null } }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Route Simulator", "How your apps are meant to connect.")
        Spacer(Modifier.height(14.dp))

        OmniCard(Modifier.fillMaxWidth(), borderColor = PurpleLight) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OmniLogo(36.dp); Spacer(Modifier.width(12.dp))
                Column {
                    Text("OmniProxy", color = Color.White, fontWeight = FontWeight.Bold)
                    Text("VPN tunnel  >  routing engine", color = TextSecondary, fontSize = 12.sp)
                }
            }
        }

        groups.forEach { (server, apps) ->
            Spacer(Modifier.height(6.dp))
            Row(Modifier.padding(start = 28.dp)) { Box(Modifier.width(2.dp).height(18.dp).background(Border)) }
            val isActive = active == server.host
            OmniCard(Modifier.fillMaxWidth(), borderColor = if (isActive) Green else Border) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        FlagBadge(server.country, 34.dp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(server.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                            Text("${server.host}:${server.port} · ${server.type.name}", color = TextSecondary, fontSize = 12.sp)
                        }
                        if (isActive) Text("Running", color = Green, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                    Text(status(server), color = if (server.type != ProxyType.SOCKS5) Danger else TextSecondary, fontSize = 12.sp)
                    apps.forEach { pkg ->
                        Row(Modifier.fillMaxWidth().clickable { tapped = pkg }.padding(start = 14.dp, top = 4.dp, bottom = 4.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.width(2.dp).height(28.dp).background(Border)); Spacer(Modifier.width(10.dp))
                            AppIcon(pkg, 28.dp); Spacer(Modifier.width(10.dp))
                            Text(appName(ctx, pkg), color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Direct connection (not in the VPN)", color = Color.White, fontWeight = FontWeight.SemiBold)
                Text(if (direct.isEmpty()) "None of the listed apps" else direct.joinToString { appName(ctx, it) },
                    color = TextSecondary, fontSize = 12.sp)
                Text("All other apps on your phone also connect directly.", color = TextSecondary, fontSize = 12.sp)
            }
        }

        Spacer(Modifier.height(14.dp))
        if (groups.size > 1) {
            InfoBanner("These ${groups.size} routes cannot run at the same time. Android allows one VPN, and the current engine uses one upstream server per session. Starting one switches the others off.",
                accent = Amber, icon = Icons.Filled.Warning)
            Spacer(Modifier.height(10.dp))
        }
        InfoBanner("Simultaneous routes with different exit IPs: not supported by the current engine. This view shows your configuration, not proof that traffic is routed this way.")
        Spacer(Modifier.height(24.dp))
    }

    tapped?.let { pkg ->
        val s = router.serverFor(pkg)
        AlertDialog(
            onDismissRequest = { tapped = null }, containerColor = CardBg,
            title = { Text(appName(ctx, pkg), color = Color.White) },
            text = { Text(if (s != null) "Assigned profile: ${s.name} (${s.host})" else "Direct connection", color = TextSecondary) },
            confirmButton = { TextButton(onClick = { tapped = null }) { Text("OK", color = PurpleLight) } }
        )
    }
}

private fun status(s: ProxyServer): String {
    val p = ProfileStore.get(s)
    return when {
        s.type != ProxyType.SOCKS5 -> "Unavailable for apps: only SOCKS5 servers can carry app traffic."
        p.reach == -1 -> "Last test: no answer."
        p.reach >= 0 -> "Last test: answered in ${p.reach} ms."
        else -> "Not tested yet."
    }
}
