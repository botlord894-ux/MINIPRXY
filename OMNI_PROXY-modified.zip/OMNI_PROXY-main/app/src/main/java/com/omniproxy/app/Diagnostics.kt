package com.omniproxy.app

import android.content.Context
import android.os.Build
import java.util.Date

/** Copyable report for troubleshooting. Passwords and usernames are never included. */
object Diagnostics {
    fun report(ctx: Context): String {
        val sb = StringBuilder()
        sb.append("OmniProxy diagnostic report\nVersion 1.0.0\n")
        sb.append("Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})\nTime: ${Date()}\n\n")
        sb.append("State: mode=${OmniVpnService.mode.value} sticky=${OmniVpnService.stickyIp.value} ")
        sb.append("current=${OmniVpnService.currentIp.value} ping=${OmniVpnService.pingMs.value}ms\n")
        sb.append("Engine: ${DevLog.engine}\n\nServers (credentials omitted):\n")
        ServerStore.list().forEach { s ->
            val p = ProfileStore.get(s)
            sb.append("- ${s.name} ${s.host}:${s.port} ${s.type} country=${s.country} udp=${s.udp} ")
            sb.append("compression=${s.compression} login=${if (s.user != null) "set" else "none"} ")
            sb.append("lock=${p.lock} failover=${p.failover} lastExit=${p.lastExitIp ?: "-"}\n")
        }
        sb.append("\nRecent history:\n")
        HistoryStore.list().take(30).forEach { sb.append("${Fmt.ago(it.time)}  ${it.profile}: ${it.text}\n") }
        sb.append("\nDeveloper log:\n")
        DevLog.lines.value.takeLast(60).forEach { sb.append(it).append('\n') }
        return sb.toString()
    }
}
