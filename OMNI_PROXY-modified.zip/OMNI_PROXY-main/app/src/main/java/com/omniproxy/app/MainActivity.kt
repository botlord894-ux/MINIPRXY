package com.omniproxy.app

import android.graphics.Color
import android.net.VpnService
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ui.OmniApp
import com.omniproxy.app.ui.VpnActions
import com.omniproxy.app.ui.theme.OmniTheme

/** The task modes. Shared with OmniVpnService via the intent extra "mode". */
enum class TaskMode(val title: String, val desc: String) {
    STREAMING("Streaming", "Fastest US/UK server, DNS ad-block (dns.adguard.com), video optimized"),
    BANKING("Banking", "Direct connection, proxy bypassed for security"),
    DATA_SAVER("Data Saver", "Routes via compression proxy"),
    GAMING("Gaming", "Auto-picks lowest ping server")
}

class MainActivity : ComponentActivity() {

    private var pendingStart: (() -> Unit)? = null

    // Result of the system "Allow VPN connection?" dialog
    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK) pendingStart?.invoke()
        }

    override fun onResume() {
        super.onResume()
        OmniVpnService.reconcile() // never show a stale "connected" if the service is gone
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        ServerStore.init(applicationContext)
        AppearanceStore.init(applicationContext)
        ProfileStore.init(applicationContext)
        HistoryStore.init(applicationContext)
        UsageStore.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        val actions = VpnActions(
            toggleMode = ::onModeTap,
            toggleSticky = ::onStickyTap,
            disconnect = ::disconnect,
            returnToOriginal = ::returnToOriginal,
            approveFailover = ::approveFailover,
            declineFailover = { OmniVpnService.failoverOffer.value = null }
        )
        setContent { OmniTheme { OmniApp(actions) } }
    }

    /** Mode tap: stop if already active, banking = no tunnel, others start the VPN. */
    private fun onModeTap(mode: TaskMode) {
        val active = OmniVpnService.mode.value == mode
        when {
            active -> disconnect()
            // Banking = no tunnel at all, traffic goes direct with your real IP
            mode == TaskMode.BANKING -> {
                OmniVpnService.stop(this)
                OmniVpnService.statusText.value = ""
                OmniVpnService.mode.value = TaskMode.BANKING
            }
            else -> launchVpn { OmniVpnService.start(this, mode) }
        }
    }

    /** Sticky card tap: start that IP's session, or stop it if it is already running. */
    private fun onStickyTap(host: String) {
        if (OmniVpnService.stickyIp.value == host) disconnect()
        else launchVpn { OmniVpnService.startSticky(this, host) }
    }

    /** After a failover: go back to the original server (the VPN permission is already granted). */
    private fun returnToOriginal() {
        OmniVpnService.usingBackupFrom.value?.let { k -> launchVpn { OmniVpnService.startForced(this, k) } }
    }

    /** STRICT failover: you approved switching to the backup server. */
    private fun approveFailover() {
        OmniVpnService.failoverOffer.value?.let { k -> launchVpn { OmniVpnService.startForced(this, k) } }
    }

    private fun disconnect() {
        OmniVpnService.requestDisconnect(this)
        OmniVpnService.mode.value = null
        OmniVpnService.statusText.value = ""
        OmniVpnService.clearFailure()
    }

    /** Asks for VPN permission if needed, then runs [action]. */
    private fun launchVpn(action: () -> Unit) {
        pendingStart = action
        val intent = VpnService.prepare(this)
        if (intent != null) vpnPermission.launch(intent) else action()
    }
}
