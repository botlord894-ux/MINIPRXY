package com.omniproxy.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.Profile
import com.omniproxy.app.TrustScore
import androidx.compose.foundation.clickable
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** IP identity card: name, connection state and only measured facts. */
@Composable
fun ProfileScreen(server: ProxyServer?, onBack: () -> Unit, onHealthCheck: () -> Unit) {
    if (server == null) {
        Column(Modifier.padding(20.dp)) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
            Text("This server no longer exists.", color = TextSecondary)
        }
        return
    }
    val ctx = LocalContext.current
    val pver by ProfileStore.version.collectAsState()
    val currentIp by OmniVpnService.currentIp.collectAsState()
    val profile = remember(pver, server) { ProfileStore.get(server) }
    val reliability = remember(pver, server) { ProfileStore.reliability(server) }
    val router = remember { StickyRouter(ctx) }
    val apps = remember(pver) { StickyRouter.PICKABLE_APPS.filter { router.get(it)?.ip == server.host } }

    var name by remember(server) { mutableStateOf(server.name) }
    var latency by remember { mutableStateOf<Int?>(null) } // null = testing, -1 = offline
    LaunchedEffect(server) { latency = withContext(Dispatchers.IO) { SmartRouter.pingMs(server) } }
    var confirmDelete by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            FlagBadge(server.country, 56.dp); Spacer(Modifier.width(14.dp))
            Column {
                Text(server.name, color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Text("IP Profile", color = TextSecondary, fontSize = 14.sp)
            }
        }
        Spacer(Modifier.height(16.dp))

        // Pending IP Lock alert
        if (profile.alertNew != null) {
            OmniCard(Modifier.fillMaxWidth(), borderColor = Amber) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.Warning, null, tint = Amber); Spacer(Modifier.width(10.dp))
                        Text("IP Change Detected", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Previous IP: ${profile.alertOld}", color = TextSecondary, fontSize = 13.sp)
                    Text("Current IP: ${profile.alertNew}", color = Color.White, fontSize = 13.sp)
                    Text("Your connection may still be active, but the exit IP is different.", color = TextSecondary, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = { ProfileStore.acceptNewIp(server) }, colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
                            Text("Accept New IP")
                        }
                        OutlinedButton(onClick = { ProfileStore.dismissAlert(server) }) { Text("Keep Watching", color = PurpleLight) }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(vertical = 6.dp)) {
                InfoRow("Address", "${server.host}:${server.port}")
                InfoRow("Protocol", server.type.name)
                InfoRow("Connection", if (currentIp == server.host) "Connected" else "Not connected",
                    if (currentIp == server.host) Green else TextSecondary)
                InfoRow("Latency", when (val l = latency) { null -> "testing…"; -1 -> "offline"; else -> "$l ms" })
                InfoRow("Recent checks answered", reliability?.let { "${it.first} of ${it.second}" } ?: "Not enough data yet")
                InfoRow("Exit IP", profile.lastExitIp ?: "Not checked")
                InfoRow("Exit country", profile.lastExitCountry ?: "Not checked")
                InfoRow("Network owner", profile.lastExitOrg ?: "Not checked")
                InfoRow("Last IP change seen", if (profile.lastChangeAt > 0) timeAgo(profile.lastChangeAt) else "None recorded")
                InfoRow("Last checked", timeAgo(profile.lastCheckedAt))
                InfoRow("IP type", "Unknown (not determined)")
                InfoRow("Assigned apps", if (apps.isEmpty()) "None" else apps.joinToString { appName(ctx, it) })
            }
        }
        Spacer(Modifier.height(14.dp))
        PrimaryButton("Check IP Health", onClick = onHealthCheck)

        Spacer(Modifier.height(18.dp))
        TrustCard(server, pver)
        Spacer(Modifier.height(18.dp))
        // IP Lock
        OmniCard(Modifier.fillMaxWidth(), borderColor = if (profile.lock) Green else Border) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.Lock, if (profile.lock) Green else PurpleLight, 40.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("IP Lock", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text(if (profile.lock) "Expected exit IP: ${profile.expectedIp ?: "set on next check"}" else "Alert me if my exit IP changes",
                            color = TextSecondary, fontSize = 12.sp)
                    }
                    Switch(checked = profile.lock, onCheckedChange = { ProfileStore.setLock(server, it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Green, checkedThumbColor = Color.White,
                            uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
                }
                Spacer(Modifier.height(8.dp))
                Text("While this server is connected, OmniProxy re-checks the real exit IP about every 5 minutes. " +
                    "It warns you and never switches servers on its own. A stable IP does not guarantee an account avoids security checks.",
                    color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp)
            }
        }

        Spacer(Modifier.height(18.dp))
        FailoverCard(server, profile)
        Spacer(Modifier.height(18.dp))
        Text("PROFILE NAME", color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        OmniTextField(name, { name = it }, "e.g. My US Socials", Modifier.fillMaxWidth())
        TextButton(onClick = { ServerStore.rename(server, name) }) { Text("Save name", color = PurpleLight) }

        TextButton(onClick = { confirmDelete = true }, modifier = Modifier.fillMaxWidth()) {
            Text("Delete this server", color = Danger)
        }
        Spacer(Modifier.height(24.dp))
    }

    if (confirmDelete) AlertDialog(
        onDismissRequest = { confirmDelete = false }, containerColor = CardBg,
        title = { Text("Delete ${server.name}?", color = Color.White) },
        text = { Text("Apps assigned to this IP will be moved to another server if you have one.", color = TextSecondary) },
        confirmButton = { TextButton(onClick = { confirmDelete = false; ServerStore.remove(server); onBack() }) { Text("Delete", color = Danger) } },
        dismissButton = { TextButton(onClick = { confirmDelete = false }) { Text("Cancel", color = TextSecondary) } }
    )
}

@Composable
private fun InfoRow(label: String, value: String, valueColor: Color = Color.White) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 9.dp), verticalAlignment = Alignment.Top) {
        Text(label, color = TextSecondary, fontSize = 13.sp, modifier = Modifier.weight(0.9f))
        Text(value, color = valueColor, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1.1f))
    }
}

/** Trust & Health: disclosed criteria, measured data only. Untested items are left out, never assumed good. */
@Composable
private fun TrustCard(server: ProxyServer, pver: Int) {
    val report = remember(pver, server) { TrustScore.compute(server) }
    var open by remember { mutableStateOf<String?>(null) }
    OmniCard(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Text("Trust & Health", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            val sc = report.score
            Text(
                if (sc == null) "No score yet. Run Check IP Health." else "$sc/100 over the tested criteria (${report.tested.size} of ${report.items.size} tested)",
                color = when { sc == null -> TextSecondary; sc >= 80 -> Green; sc >= 50 -> Amber; else -> Danger }, fontSize = 13.sp
            )
            Spacer(Modifier.height(8.dp))
            report.items.forEach { item ->
                Row(Modifier.fillMaxWidth().clickable { open = if (open == item.name) null else item.name }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    val e = item.earned
                    StatusDot(when { e == null -> TextSecondary; e == item.possible -> Green; e == 0 -> Danger; else -> Amber })
                    Spacer(Modifier.width(10.dp))
                    Text(item.name, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
                    Text(if (e == null) "Not tested" else "$e/${item.possible}", color = TextSecondary, fontSize = 12.sp)
                }
                if (open == item.name) Column(Modifier.padding(start = 19.dp, bottom = 8.dp)) {
                    Text(item.detail, color = TextSecondary, fontSize = 12.sp)
                    Text("How it is scored: ${item.how}", color = TextSecondary, fontSize = 11.sp)
                }
            }
            Spacer(Modifier.height(6.dp))
            Text("Tap a row for what was tested, when, and what is unknown.", color = TextSecondary, fontSize = 11.sp)
        }
    }
}

/** Failover: choose backups and whether OmniProxy may switch on its own. */
@Composable
private fun FailoverCard(server: ProxyServer, profile: Profile) {
    val others = remember(server) { SmartRouter.SERVERS.filter { it.host != server.host || it.port != server.port } }
    val backups = profile.backups.split(",").filter { it.isNotBlank() }
    OmniCard(Modifier.fillMaxWidth(), borderColor = if (profile.failover != "OFF") PurpleLight else Border) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Failover", color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Segment("Off", profile.failover == "OFF", Modifier.weight(1f)) { ProfileStore.setFailover(server, "OFF") }
                Segment("Ask me", profile.failover == "STRICT", Modifier.weight(1f)) { ProfileStore.setFailover(server, "STRICT") }
                Segment("Automatic", profile.failover == "AUTO", Modifier.weight(1f)) { ProfileStore.setFailover(server, "AUTO") }
            }
            Text(
                when (profile.failover) {
                    "STRICT" -> "If this server stops answering, OmniProxy finds a verified backup but waits for your approval, because the exit IP may change."
                    "AUTO" -> "If this server stops answering, OmniProxy verifies a backup, switches, and tells you whether your exit IP changed."
                    else -> "Off: if the server fails, the kill switch blocks your apps (or they go direct if the kill switch is off)."
                },
                color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp
            )
            if (profile.failover != "OFF") {
                if (others.isEmpty()) Text("Add another server in the Servers tab to use as a backup.", color = Amber, fontSize = 12.sp)
                else {
                    Text("Backups, tried in order:", color = TextSecondary, fontSize = 12.sp)
                    others.forEach { o ->
                        val k = "${o.host}:${o.port}"
                        val on = k in backups
                        Row(Modifier.fillMaxWidth().clickable { ProfileStore.setBackups(server, if (on) backups - k else backups + k) },
                            verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked = on, onCheckedChange = { ProfileStore.setBackups(server, if (on) backups - k else backups + k) },
                                colors = CheckboxDefaults.colors(checkedColor = Purple, uncheckedColor = TextSecondary, checkmarkColor = Color.White))
                            FlagBadge(o.country, 28.dp); Spacer(Modifier.width(10.dp))
                            Text("${o.name}  ${o.host}", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
