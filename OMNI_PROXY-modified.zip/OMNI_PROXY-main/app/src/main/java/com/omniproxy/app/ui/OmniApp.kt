package com.omniproxy.app.ui

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Dns
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.sp
import androidx.compose.ui.unit.dp
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.screens.*
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ui.components.OmniBackground
import com.omniproxy.app.ui.components.rememberReduceMotion
import com.omniproxy.app.ui.screens.studio.ThemeStudioScreen
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

private data class Tab(val route: String, val label: String, val icon: ImageVector)

private val TABS = listOf(
    Tab("home", "Home", Icons.Filled.Home),
    Tab("sticky", "Sticky Apps", Icons.Filled.Apps),
    Tab("servers", "Servers", Icons.Filled.Dns),
    Tab("settings", "Settings", Icons.Filled.Settings)
)

@Composable
fun OmniApp(actions: VpnActions) {
    val ctx = LocalContext.current
    val nav = rememberNavController()
    val backStack by nav.currentBackStackEntryAsState()
    val route = backStack?.destination?.route
    val showBar = route in TABS.map { it.route }

    // Android 13+ needs notification permission for the ON/OFF notification
    val notifPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notifPerm.launch(Manifest.permission.POST_NOTIFICATIONS)
        // Give tracked apps their first sticky IP (network check -> background thread)
        withContext(Dispatchers.IO) {
            val r = StickyRouter(ctx)
            StickyRouter.TRACKED_APPS.forEach { r.ensureAssigned(it) }
        }
    }

    val ap = AppearanceStore.current
    val pal = AppearanceStore.palette
    val reduce = rememberReduceMotion()
    Box(Modifier.fillMaxSize()) {
    OmniBackground(ap, Modifier.fillMaxSize(), reduce)
    Scaffold(
        containerColor = Color.Transparent,
        bottomBar = {
            if (showBar) NavigationBar(
                containerColor = Color(pal.nav).copy(alpha = ap.nav.bgAlpha),
                modifier = Modifier.height(ap.nav.height.coerceIn(80f, 120f).dp)
            ) {
                TABS.forEach { tab ->
                    NavigationBarItem(
                        selected = route == tab.route,
                        onClick = {
                            nav.navigate(tab.route) {
                                popUpTo("home") { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, tab.label) },
                        alwaysShowLabel = ap.nav.alwaysLabels,
                        label = { Text(tab.label, fontSize = 11.sp) },
                        colors = NavigationBarItemDefaults.colors(
                            selectedIconColor = Color(pal.navSelected), selectedTextColor = Color(pal.navSelected),
                            indicatorColor = if (ap.nav.showIndicator) NavSelectedBg else Color.Transparent,
                            unselectedIconColor = TextSecondary, unselectedTextColor = TextSecondary
                        )
                    )
                }
            }
        }
    ) { pad ->
        NavHost(nav, startDestination = "home", modifier = Modifier.padding(pad)) {
            composable("home") {
                HomeScreen(
                    actions,
                    onOpenSettings = {
                        nav.navigate("settings") { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                    },
                    onOpenTruth = { s -> nav.navigate("truth/${s.host}/${s.port}") }
                )
            }
            composable("sticky") {
                StickyScreen(
                    actions = actions,
                    onEditApps = { host -> nav.navigate("picker/$host") },
                    onOpenServers = {
                        nav.navigate("servers") { popUpTo("home") { saveState = true }; launchSingleTop = true; restoreState = true }
                    },
                    onNavigate = { nav.navigate(it) }
                )
            }
            composable("servers") {
                ServersScreen(
                    onOpenProfile = { s -> nav.navigate("profile/${s.host}/${s.port}") },
                    onOpenQuality = { nav.navigate("quality") }
                )
            }
            composable("settings") { SettingsScreen(onNavigate = { nav.navigate(it) }) }
            composable("history") { HistoryScreen { nav.popBackStack() } }
            composable("data") { DataScreen { nav.popBackStack() } }
            composable("quality") { QualityScreen { nav.popBackStack() } }
            composable("rules") { RulesScreen { nav.popBackStack() } }
            composable("simulator") { SimulatorScreen { nav.popBackStack() } }
            composable("privacy") { PrivacyScreen { nav.popBackStack() } }
            composable("dev") { DevScreen { nav.popBackStack() } }
            composable("templates") { TemplatesScreen { nav.popBackStack() } }
            composable("studio") { ThemeStudioScreen { nav.popBackStack() } }
            composable("picker/{host}", arguments = listOf(navArgument("host") { type = NavType.StringType })) { entry ->
                AppPickerScreen(host = entry.arguments?.getString("host") ?: "") { nav.popBackStack() }
            }
            composable("profile/{host}/{port}", arguments = listOf(
                navArgument("host") { type = NavType.StringType }, navArgument("port") { type = NavType.StringType }
            )) { entry ->
                val server = findServer(entry.arguments?.getString("host"), entry.arguments?.getString("port"))
                ProfileScreen(server, onBack = { nav.popBackStack() },
                    onHealthCheck = { server?.let { nav.navigate("truth/${it.host}/${it.port}") } })
            }
            composable("truth/{host}/{port}", arguments = listOf(
                navArgument("host") { type = NavType.StringType }, navArgument("port") { type = NavType.StringType }
            )) { entry ->
                TruthScreen(findServer(entry.arguments?.getString("host"), entry.arguments?.getString("port"))) { nav.popBackStack() }
            }
        }
    }    }
}

private fun findServer(host: String?, port: String?): ProxyServer? =
    SmartRouter.SERVERS.firstOrNull { it.host == host && it.port.toString() == port }
