package com.omniproxy.app.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.CheckResult
import com.omniproxy.app.CheckStatus
import com.omniproxy.app.ConnectionTruth
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Connection Truth: real checks, with "Not tested" instead of a fake green. */
@Composable
fun TruthScreen(server: ProxyServer?, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var results by remember { mutableStateOf<List<CheckResult>?>(null) }
    var running by remember { mutableStateOf(false) }
    var ranAt by remember { mutableLongStateOf(0L) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Connection Truth", server?.let { "${it.name}  ${it.host}:${it.port}" } ?: "Server not found")
        Spacer(Modifier.height(16.dp))
        if (server != null) {
            PrimaryButton(if (running) "Testing…" else "Run Full Connection Test") {
                if (!running) {
                    running = true
                    scope.launch {
                        results = withContext(Dispatchers.IO) { ConnectionTruth.run(ctx, server) }
                        ranAt = System.currentTimeMillis(); running = false
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            val list = results
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                if (list == null) item {
                    InfoBanner("Nothing has been tested yet. Run the test to see what is verified and what is not. Checks that can't run show \"Not tested\" instead of green.")
                } else {
                    item { Text("Last test: ${timeAgo(ranAt)}", color = TextSecondary, fontSize = 12.sp) }
                    items(list) { r -> ResultRow(r) }
                    item {
                        InfoBanner("This report tests the proxy server and the IP it gives you. It cannot prove that every app is leak-free.",
                            accent = Amber)
                    }
                }
            }
        }
    }
}

@Composable
private fun ResultRow(r: CheckResult) {
    val color = when (r.status) {
        CheckStatus.PASS -> Green; CheckStatus.WARN -> Amber
        CheckStatus.FAIL -> Danger; CheckStatus.NOT_TESTED -> TextSecondary
    }
    val label = when (r.status) {
        CheckStatus.PASS -> "Passed"; CheckStatus.WARN -> "Check"
        CheckStatus.FAIL -> "Failed"; CheckStatus.NOT_TESTED -> "Not tested"
    }
    OmniCard(Modifier.fillMaxWidth(), borderColor = color.copy(alpha = 0.5f)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                StatusDot(color); Spacer(Modifier.width(10.dp))
                Text(r.title, color = Color.White, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                Text(label, color = color, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
            Text(r.detail, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
        }
    }
}
