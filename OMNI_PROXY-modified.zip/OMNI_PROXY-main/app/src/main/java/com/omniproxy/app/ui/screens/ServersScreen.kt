package com.omniproxy.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.omniproxy.app.Goal
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.Recommendation
import com.omniproxy.app.RouteAdvisor
import com.omniproxy.app.ProxyType
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun ServersScreen(onOpenProfile: (ProxyServer) -> Unit, onOpenQuality: () -> Unit) {
    val sver by ServerStore.version.collectAsState()
    val sctx = androidx.compose.ui.platform.LocalContext.current
    val favs = sctx.getSharedPreferences("omni_prefs", 0).getStringSet("favorites", emptySet()) ?: emptySet()
    val servers = remember(sver) { SmartRouter.SERVERS.sortedByDescending { "${it.host}:${it.port}" in favs } }
    var showForm by remember { mutableStateOf(false) }
    var showAdvisor by remember { mutableStateOf(false) }

    // Real latency test (TCP connect time). -1 = unreachable.
    var pings by remember { mutableStateOf<Map<String, Int>>(emptyMap()) }
    var testing by remember { mutableStateOf(true) }
    LaunchedEffect(servers) {
        testing = true
        pings = withContext(Dispatchers.IO) {
            coroutineScope {
                servers.map { s -> async { "${s.host}:${s.port}" to SmartRouter.pingMs(s) } }.awaitAll().toMap()
            }
        }
        withContext(Dispatchers.IO) {
            servers.forEach { s -> ProfileStore.recordPing(s, (pings["${s.host}:${s.port}"] ?: -1) >= 0) }
        }
        testing = false
    }

    LazyColumn(
        Modifier.fillMaxSize().padding(horizontal = 20.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 24.dp)
    ) {
        item { ScreenHeader("Proxy Servers", "Select a server or add your own.") }
        item {
            // Prominent "+ Add Server" button
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(20.dp))
                    .background(Brush.horizontalGradient(listOf(Color(0xFF3B1AA8), Purple)))
                    .clickable { showForm = true }.padding(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(Modifier.size(44.dp).clip(RoundedCornerShape(14.dp)).background(Color.White.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center) { Icon(Icons.Filled.Add, null, tint = Color.White) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text("+ Add Server", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    Text("Host, port, type, login", color = Color.White.copy(alpha = 0.75f), fontSize = 12.sp)
                }
                Icon(Icons.Filled.ChevronRight, null, tint = Color.White)
            }
        }
        item {
            OmniCard(Modifier.fillMaxWidth(), onClick = { showAdvisor = true }) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.AutoAwesome, Cyan)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Find My Best Route", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("Tests your servers, then recommends one", color = TextSecondary, fontSize = 12.sp)
                    }
                    Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary)
                }
            }
        }
        item {
            OmniCard(Modifier.fillMaxWidth(), onClick = onOpenQuality) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconBadge(Icons.Filled.Speed, Green)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Quality Test", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                        Text("Latency, loss, speed, stability per server", color = TextSecondary, fontSize = 12.sp)
                    }
                    Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary)
                }
            }
        }
        if (servers.isEmpty()) item {
            OmniCard(Modifier.fillMaxWidth()) {
                Text("No servers yet. Tap \"Add Server\" to add your proxy.", color = TextSecondary,
                    modifier = Modifier.padding(18.dp), fontSize = 14.sp)
            }
        }
        items(servers, key = { "${it.host}:${it.port}" }) { s ->
            ServerCard(s, pings["${s.host}:${s.port}"], testing) { onOpenProfile(s) }
        }
        item {
            InfoBanner("SOCKS5 works for sticky apps. HTTP only works for browsers. Latency is a live test from your phone; \"offline\" means the server didn't answer.")
        }
    }

    if (showForm) AddServerDialog(onDismiss = { showForm = false }) { ServerStore.add(it); showForm = false }

    if (showAdvisor) AdvisorDialog(servers, onDismiss = { showAdvisor = false }) { showAdvisor = false; onOpenProfile(it) }
}

@Composable
private fun ServerCard(s: ProxyServer, ping: Int?, testing: Boolean, onClick: () -> Unit) {
    OmniCard(Modifier.fillMaxWidth(), onClick = onClick) {
        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            FlagBadge(s.country, 44.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(s.name, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text("${s.host}:${s.port}", color = TextSecondary, fontSize = 13.sp)
                Spacer(Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    when {
                        ping == null && testing -> Text("testing…", color = TextSecondary, fontSize = 12.sp)
                        ping == null || ping < 0 -> Text("offline", color = Danger, fontSize = 12.sp)
                        else -> {
                            Icon(Icons.Filled.Bolt, null, tint = if (ping < 80) Green else if (ping < 150) Amber else Danger,
                                modifier = Modifier.size(14.dp))
                            Text(" $ping ms", color = if (ping < 80) Green else if (ping < 150) Amber else Danger,
                                fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
            Column(horizontalAlignment = Alignment.End) {
                ProtoBadge(if (s.type == ProxyType.SOCKS5) "SOCKS5" else "HTTP")
                Spacer(Modifier.height(10.dp))
                Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary)
            }
        }
    }
}

@Composable
fun Segment(text: String, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp))
            .background(if (selected) Purple else Color(0xFF1B1830)).clickable(onClick = onClick).padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (selected) Color.White else TextSecondary, fontWeight = FontWeight.SemiBold) }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 14.sp, modifier = Modifier.weight(1f))
        Switch(checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = Purple, checkedThumbColor = Color.White,
                uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
    }
}

@Composable
fun AddServerDialog(onDismiss: () -> Unit, onSave: (ProxyServer) -> Unit) {
    var name by remember { mutableStateOf("") }
    var host by remember { mutableStateOf("") }
    var port by remember { mutableStateOf("1080") }
    var socks by remember { mutableStateOf(true) }
    var country by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var udp by remember { mutableStateOf(false) }
    var compression by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Add Server", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                OmniTextField(name, { name = it }, "Server name", Modifier.fillMaxWidth())
                OmniTextField(host, { host = it.trim() }, "Host or IP", Modifier.fillMaxWidth(), KeyboardType.Uri)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OmniTextField(port, { port = it.filter(Char::isDigit) }, "Port", Modifier.weight(1f), KeyboardType.Number)
                    OmniTextField(country, { country = it.take(2) }, "Country (US)", Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Segment("SOCKS5", socks, Modifier.weight(1f)) { socks = true }
                    Segment("HTTP", !socks, Modifier.weight(1f)) { socks = false }
                }
                OmniTextField(user, { user = it }, "Username (optional)", Modifier.fillMaxWidth())
                OmniTextField(pass, { pass = it }, "Password (optional)", Modifier.fillMaxWidth(), password = true)
                SwitchRow("Server supports UDP relay", udp) { udp = it }
                SwitchRow("Compression proxy (Data Saver)", compression) { compression = it }
                error?.let { Text(it, color = Danger, fontSize = 13.sp) }
                Spacer(Modifier.height(4.dp))
                PrimaryButton("Save Server") {
                    val p = port.toIntOrNull()
                    when {
                        host.isBlank() -> error = "Enter a host or IP."
                        p == null || p !in 1..65535 -> error = "Port must be 1 to 65535."
                        else -> onSave(
                            ProxyServer(
                                name = name.ifBlank { host }, host = host, port = p,
                                type = if (socks) ProxyType.SOCKS5 else ProxyType.HTTP,
                                country = country.uppercase(),
                                user = user.ifBlank { null }, pass = pass.ifBlank { null },
                                compression = compression, udp = udp
                            )
                        )
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) {
                    Text("Cancel", color = PurpleLight)
                }
            }
        }
    }
}

@Composable
private fun AdvisorDialog(servers: List<ProxyServer>, onDismiss: () -> Unit, onOpen: (ProxyServer) -> Unit) {
    val scope = rememberCoroutineScope()
    var goal by remember { mutableStateOf(Goal.LATENCY) }
    val countries = remember(servers) { servers.map { it.country.uppercase() }.filter { it.length == 2 }.distinct() }
    var country by remember { mutableStateOf(countries.firstOrNull()) }
    var stabilityFirst by remember { mutableStateOf(false) }
    var running by remember { mutableStateOf(false) }
    var done by remember { mutableStateOf(false) }
    var rec by remember { mutableStateOf<Recommendation?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.verticalScroll(rememberScrollState()).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Find My Best Route", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                if (servers.isEmpty()) {
                    Text("Add a server first.", color = TextSecondary)
                } else if (!done) {
                    Text("What matters most?", color = TextSecondary, fontSize = 13.sp)
                    Goal.values().forEach { g -> Segment(g.label, goal == g, Modifier.fillMaxWidth()) { goal = g } }
                    if (goal == Goal.COUNTRY) {
                        if (countries.isEmpty()) Text("None of your servers has a country set.", color = Danger, fontSize = 13.sp)
                        else Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            countries.forEach { c -> Segment(c, country == c, Modifier.weight(1f)) { country = c } }
                        }
                    }
                    SwitchRow("Rank reliability above speed", stabilityFirst) { stabilityFirst = it }
                    PrimaryButton(if (running) "Testing servers…" else "Test and recommend") {
                        if (!running) {
                            running = true
                            scope.launch {
                                val ms = RouteAdvisor.measure(servers)
                                rec = RouteAdvisor.recommend(goal, country, ms, stabilityFirst)
                                running = false; done = true
                            }
                        }
                    }
                } else {
                    val r = rec
                    if (r == null) Text("No matching server answered. Nothing is recommended because nothing was verified.", color = TextSecondary)
                    else {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            FlagBadge(r.best.server.country, 40.dp); Spacer(Modifier.width(12.dp))
                            Column {
                                Text("Recommended: ${r.best.server.name}", color = Color.White, fontWeight = FontWeight.Bold)
                                Text("${r.best.server.host}:${r.best.server.port} · ${r.best.server.type.name}", color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                        Text(r.reason, color = Green, fontSize = 13.sp)
                        r.caveat?.let { Text(it, color = Amber, fontSize = 12.sp) }
                        Text("Tested just now (3 quick pings each):", color = TextSecondary, fontSize = 12.sp)
                        r.all.forEach { m ->
                            Text("${m.server.name}: " + (m.avgMs?.let { "$it ms, ${m.ok}/${m.total}" } ?: "no answer"),
                                color = TextSecondary, fontSize = 12.sp)
                        }
                        PrimaryButton("Open profile") { onOpen(r.best.server) }
                    }
                }
                TextButton(onClick = onDismiss, modifier = Modifier.fillMaxWidth()) { Text("Close", color = PurpleLight) }
            }
        }
    }
}
