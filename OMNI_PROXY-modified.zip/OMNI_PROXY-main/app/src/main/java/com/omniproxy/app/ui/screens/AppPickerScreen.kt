package com.omniproxy.app.ui.screens

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Choose which apps use the IP of the server with this [host]. */
@Composable
fun AppPickerScreen(host: String, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val router = remember { StickyRouter(ctx) }
    val initial = remember(host) { StickyRouter.PICKABLE_APPS.filter { router.get(it)?.ip == host } }
    val selected = remember(host) { mutableStateListOf<String>().apply { addAll(initial) } }
    var query by remember { mutableStateOf("") }
    var saving by remember { mutableStateOf(false) }

    val visible = StickyRouter.PICKABLE_APPS.filter {
        query.isBlank() || appName(ctx, it).contains(query, true) || it.contains(query, true)
    }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        IconButton(onClick = onDone) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Select Apps", "Choose which apps use this IP.")
        Spacer(Modifier.height(14.dp))
        OmniTextField(query, { query = it }, "Search apps…", Modifier.fillMaxWidth(), icon = Icons.Filled.Search)
        Spacer(Modifier.height(14.dp))

        Box(Modifier.weight(1f)) {
            if (visible.isEmpty()) Text("No apps match \"$query\".", color = TextSecondary,
                modifier = Modifier.padding(16.dp))
            else OmniCard(Modifier.fillMaxWidth()) {
                LazyColumn {
                    items(visible, key = { it }) { pkg ->
                        val checked = pkg in selected
                        val toggle = { if (checked) selected.remove(pkg) else selected.add(pkg); Unit }
                        Row(
                            Modifier.fillMaxWidth().clickable { toggle() }.padding(horizontal = 14.dp, vertical = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            AppIcon(pkg, 46.dp)
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(appName(ctx, pkg), color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                                Text(pkg, color = TextSecondary, fontSize = 12.sp)
                            }
                            Checkbox(
                                checked = checked, onCheckedChange = { toggle() },
                                colors = CheckboxDefaults.colors(checkedColor = Purple, uncheckedColor = TextSecondary,
                                    checkmarkColor = Color.White)
                            )
                        }
                        Hairline()
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))
        Text("${selected.size} selected", color = TextSecondary, fontSize = 13.sp,
            modifier = Modifier.align(Alignment.CenterHorizontally))
        Spacer(Modifier.height(8.dp))
        PrimaryButton(if (saving) "Saving…" else "Save Selection") {
            if (!saving) {
                saving = true
                scope.launch {
                    withContext(Dispatchers.IO) {
                        selected.forEach { router.assignTo(it, host) }
                        // Apps that were unchecked leave this IP (network check may run for tracked apps)
                        initial.filter { it !in selected }.forEach { router.moveAway(it, host) }
                    }
                    onDone()
                }
            }
        }
        TextButton(onClick = onDone, modifier = Modifier.fillMaxWidth()) { Text("Cancel", color = PurpleLight) }
        Spacer(Modifier.height(8.dp))
    }
}
