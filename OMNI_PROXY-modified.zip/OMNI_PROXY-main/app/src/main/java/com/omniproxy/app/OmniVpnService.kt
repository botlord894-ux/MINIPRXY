package com.omniproxy.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.ProxyInfo
import android.net.VpnService
import android.os.Build
import android.os.ParcelFileDescriptor
import androidx.core.content.ContextCompat
import hev.htproxy.TProxyService
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.io.FileInputStream
import java.net.InetAddress
import java.net.Socket
import kotlin.concurrent.thread

/**
 * Core VPN service with packet-level routing (tun2socks core).
 *
 *  Start options: a task mode, or a sticky session (apps that share one saved IP).
 *  Split tunneling: only the "allowed" apps enter the tunnel; OmniProxy itself stays direct.
 *  Kill switch: if the proxy dies, the tunnel stays up and blocks those apps.
 *  Failover: per-profile backup servers, STRICT (ask first) or AUTO (verify, switch, tell you).
 *  IP Lock: re-checks the real exit IP about every 5 minutes.
 *  Network changes: logged, verified, and the tunnel is re-established if "Reconnect automatically" is on.
 */
class OmniVpnService : VpnService() {

    companion object {
        // Live state read by the UI
        val mode = MutableStateFlow<TaskMode?>(null)
        val stickyIp = MutableStateFlow<String?>(null)
        val currentIp = MutableStateFlow<String?>(null)
        val pingMs = MutableStateFlow(0)
        val savedMb = MutableStateFlow(0.0)
        val connecting = MutableStateFlow(false)
        /** The one authority for the connection phase (rules are unit-tested in VpnStateMachineTest). */
        val machine = VpnStateMachine()
        val phase: StateFlow<VpnPhase> get() = machine.phase
        @Volatile var running = false
        private const val CONNECT_TIMEOUT_MS = 30_000L
        val statusText = MutableStateFlow("")
        /** "host:port" of a backup server waiting for your approval (STRICT failover). */
        val failoverOffer = MutableStateFlow<String?>(null)
        /** "host:port" of the original server while running on a backup, else null. */
        val usingBackupFrom = MutableStateFlow<String?>(null)
        val throughputBps = MutableStateFlow(0L)

        private const val ACTION_STOP = "com.omniproxy.STOP"
        private const val EXTRA_MODE = "mode"
        private const val EXTRA_STICKY = "sticky_host"
        private const val EXTRA_FORCE = "force_server"
        private const val CHANNEL = "omni_vpn"
        private val DEFAULT_PROXY_APPS = setOf("com.android.chrome", "org.mozilla.firefox")

        fun key(s: ProxyServer) = "${s.host}:${s.port}"

        fun start(ctx: Context, m: TaskMode) = ContextCompat.startForegroundService(
            ctx, Intent(ctx, OmniVpnService::class.java).putExtra(EXTRA_MODE, m.name))

        fun startSticky(ctx: Context, host: String) = ContextCompat.startForegroundService(
            ctx, Intent(ctx, OmniVpnService::class.java).putExtra(EXTRA_STICKY, host))

        /** Reconnect the current session through a specific server ("host:port"). */
        fun startForced(ctx: Context, serverKey: String) {
            val i = Intent(ctx, OmniVpnService::class.java).putExtra(EXTRA_FORCE, serverKey)
            mode.value?.let { if (it != TaskMode.BANKING) i.putExtra(EXTRA_MODE, it.name) }
            stickyIp.value?.let { i.putExtra(EXTRA_STICKY, it) }
            ContextCompat.startForegroundService(ctx, i)
        }

        /** The user dismissed a failure. */
        fun clearFailure() = machine.clearFailure()

        /**
         * Called when the app comes to the foreground: if the phase says "connected" but the service is not
         * actually running, show a failure instead of a stale connected state.
         */
        fun reconcile() {
            if (machine.reconcile(running)) {
                mode.value = if (mode.value == TaskMode.BANKING) mode.value else null
                stickyIp.value = null; currentIp.value = null; connecting.value = false; pingMs.value = 0
                statusText.value = "OFF • the VPN service stopped unexpectedly"
            }
        }

        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, OmniVpnService::class.java)) }

        /** Disconnect with the visible "Disconnecting" phase (falls back to stopService). */
        fun requestDisconnect(ctx: Context) {
            try { ctx.startService(Intent(ctx, OmniVpnService::class.java).setAction(ACTION_STOP)) }
            catch (e: Exception) { stop(ctx) }
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var tun: ParcelFileDescriptor? = null
    private var proxy: LocalProxy? = null
    private var coreRunning = false
    private var activeName: String? = null
    private var activeServer: ProxyServer? = null
    private var primaryKey: String? = null
    private var lastMode: TaskMode? = null
    private var lastSticky: String? = null
    private var lastForced: String? = null
    private var connectedAt = 0L
    private var failoverNote: String? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null

    override fun onCreate() {
        super.onCreate()
        running = true
        ServerStore.init(applicationContext)
        ProfileStore.init(applicationContext)
        HistoryStore.init(applicationContext)
        UsageStore.init(applicationContext)
        registerNetworkWatcher()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            if (tun == null && !connecting.value) { machine.finishDisconnect(); stopSelf() }
            else if (machine.beginDisconnect()) { // also cancels a connection attempt that is still in progress
                job?.cancel()
                scope.launch { delay(450); stopSelf() }
            } // else: already disconnecting, ignore the duplicate request
            return START_NOT_STICKY
        }
        val sticky = intent?.getStringExtra(EXTRA_STICKY)
        val forced = intent?.getStringExtra(EXTRA_FORCE)
        val m = runCatching { TaskMode.valueOf(intent?.getStringExtra(EXTRA_MODE) ?: "") }.getOrNull()
        if (sticky == null && m == null) { stopSelf(); return START_NOT_STICKY }
        goForeground("Connecting…")
        statusText.value = ""
        startConnect(m, sticky, forced)
        return START_NOT_STICKY
    }

    /**
     * Begin a connection attempt. Duplicates and requests made while disconnecting are ignored. A watchdog
     * fails the attempt if it is still in progress after 30 seconds.
     */
    private fun startConnect(m: TaskMode?, sticky: String?, forced: String?): Boolean {
        val attempt = machine.tryBeginConnect("$m|$sticky|$forced", tun != null)
        if (attempt < 0) { DevLog.log("Ignored a duplicate or too-early connect request"); return false }
        connecting.value = true
        failoverOffer.value = null
        job?.cancel()
        job = scope.launch { connect(attempt, m, sticky, forced) }
        scope.launch {
            delay(CONNECT_TIMEOUT_MS)
            if (machine.timedOut(attempt)) {
                job?.cancel()
                DevLog.log("ERR connection timed out")
                closeTunnel()
                notify("OFF • connection timed out")
                mode.value = null; stickyIp.value = null; connecting.value = false
                stopSelf()
            }
        }
        return true
    }

    /** Failure of [attempt]. Ignored if a newer attempt or a disconnect owns the state now. */
    private fun fail(attempt: Int, msg: String) {
        if (!machine.failed(attempt)) return
        DevLog.log("ERR $msg")
        notify("OFF • $msg")
        mode.value = null; stickyIp.value = null; connecting.value = false
        stopSelf()
    }

    private suspend fun connect(attempt: Int, m: TaskMode?, stickyHost: String?, forcedKey: String?) {
        connecting.value = true
        failoverOffer.value = null
        closeTunnel()
        mode.value = null; stickyIp.value = null
        lastMode = m; lastSticky = stickyHost; lastForced = forcedKey
        val prefs = getSharedPreferences("omni_prefs", MODE_PRIVATE)
        val killSwitch = prefs.getBoolean("kill_switch", true)
        val label = m?.title ?: "Sticky"
        val protectFn: (Socket) -> Unit = { protect(it) }
        val all = SmartRouter.SERVERS
        val forced = forcedKey?.let { k -> all.firstOrNull { key(it) == k } }
        val pref = if (stickyHost == null) prefs.getString("preferred_server", null)?.let { k -> all.firstOrNull { key(it) == k } } else null

        // 1) Pick the upstream server
        val pick: Pair<ProxyServer, Int>? = when {
            forced != null -> forced to SmartRouter.pingMs(forced, protectFn)
            pref != null && m != TaskMode.BANKING -> pref to SmartRouter.pingMs(pref, protectFn)
            stickyHost != null -> all.firstOrNull { it.host == stickyHost }?.let { it to SmartRouter.pingMs(it, protectFn) }
            else -> when (m!!) {
                TaskMode.STREAMING -> SmartRouter.fastest(all.filter { it.country in setOf("US", "GB") }.ifEmpty { all }, protectFn)
                TaskMode.GAMING -> SmartRouter.fastest(all, protectFn)
                TaskMode.DATA_SAVER -> all.firstOrNull { it.compression }?.let { it to SmartRouter.pingMs(it, protectFn) }
                    ?: SmartRouter.fastest(all, protectFn)
                TaskMode.BANKING -> null
            }
        }
        currentCoroutineContext().ensureActive()
        if (!machine.isCurrent(attempt)) return // cancelled or replaced while we were testing servers
        if (pick == null) { fail(attempt, "no reachable server (check the Servers tab)"); return }
        val (server, firstPing) = pick
        if (forced == null) primaryKey = key(server)
        usingBackupFrom.value = if (forced != null && key(server) != primaryKey) primaryKey else null

        val useCore = server.type == ProxyType.SOCKS5
        if (stickyHost != null && !useCore) { fail(attempt, "sticky sessions need a SOCKS5 server"); return }

        // 2) Which apps enter the tunnel
        val apps: Set<String> = if (stickyHost != null) {
            val r = StickyRouter(this)
            StickyRouter.PICKABLE_APPS.filter { r.get(it)?.ip == stickyHost }.toSet()
        } else prefs.getStringSet("proxy_apps", null) ?: DEFAULT_PROXY_APPS

        // 3) Resolve the server hostname (the core wants a literal IP)
        val serverIp = try { InetAddress.getByName(server.host).hostAddress ?: server.host }
        catch (e: Exception) { fail(attempt, "cannot resolve ${server.host}"); return }

        currentCoroutineContext().ensureActive()
        if (!machine.isCurrent(attempt)) return

        // 4) Build the VPN interface
        val mapDns = useCore && !server.udp
        val b = Builder().setSession("OmniProxy").setBlocking(true)
        if (useCore) b.setMtu(8500).addAddress("198.18.0.1", 32).addAddress("fc00::1", 128)
        else b.setMtu(1500).addAddress("10.8.0.2", 32).addAddress("fd00::2", 128)
        b.addRoute("0.0.0.0", 0).addRoute("::", 0)
        val dnsDesc = when {
            mapDns -> { b.addDnsServer("198.18.0.2"); "remote via proxy (mapdns)" }
            m == TaskMode.STREAMING -> { b.addDnsServer("94.140.14.14"); b.addDnsServer("94.140.15.15"); "AdGuard 94.140.14.14" }
            else -> { b.addDnsServer("1.1.1.1"); b.addDnsServer("1.0.0.1"); "Cloudflare 1.1.1.1" }
        }
        var added = 0
        for (p in apps) try { b.addAllowedApplication(p); added++ } catch (_: PackageManager.NameNotFoundException) {}
        if (added == 0) { fail(attempt, "none of the apps for this session are installed"); return }

        if (!useCore) {
            val lp = LocalProxy(server, protectFn).also { it.start() }
            proxy = lp
            if (Build.VERSION.SDK_INT >= 29) b.setHttpProxy(ProxyInfo.buildDirectProxy("127.0.0.1", lp.port))
        }

        if (!machine.isCurrent(attempt)) return // a disconnect or a newer request arrived: never create the tunnel
        val fd = b.establish()
        if (fd == null) { fail(attempt, "VPN permission missing"); return }
        tun = fd

        // 5) Start the packet engine
        if (useCore) {
            try {
                val cfg = writeConfig(serverIp, server, mapDns)
                coreRunning = TProxyService.TProxyStartService(cfg.absolutePath, fd.fd)
            } catch (t: Throwable) { coreRunning = false; DevLog.log("ERR core: ${t.javaClass.simpleName}") }
            if (!coreRunning) { closeTunnel(); fail(attempt, "tun2socks core failed to start"); return }
        } else {
            thread(isDaemon = true) {
                val input = FileInputStream(fd.fileDescriptor); val buf = ByteArray(32767)
                try { while (input.read(buf) >= 0) { /* drop */ } } catch (_: Exception) {}
            }
        }

        if (!machine.connected(attempt)) { closeTunnel(); return } // stale: a newer request or a disconnect took over
        mode.value = m; stickyIp.value = stickyHost
        currentIp.value = server.host; pingMs.value = firstPing; savedMb.value = 0.0; connecting.value = false
        notify("ON • $label • IP ${server.host}")
        activeName = server.name; activeServer = server; connectedAt = System.currentTimeMillis()
        HistoryStore.add(server.name, "Connected ($label)")
        DevLog.engine = "${if (useCore) "tun2socks core" else "local HTTP proxy (browsers only)"}; ${server.type} ${server.host}:${server.port}; " +
            "UDP relay=${server.udp}; DNS=$dnsDesc; apps=${apps.joinToString()}"
        DevLog.log("Connected via ${server.type} ${server.host}:${server.port}, handshake ping ${firstPing}ms")
        if (forced != null) {
            val note = failoverNote ?: "Switched to ${server.name}"
            failoverNote = null
            HistoryStore.add(server.name, note); notify("ON • $label • $note")
        }

        // 6) Monitor loop
        var fails = 0
        var tick = 0
        var lastTotal = 0L
        var lastAt = System.currentTimeMillis()
        var warned = 0
        while (currentCoroutineContext().isActive) {
            delay(if (m == TaskMode.GAMING) 2000 else 8000)
            val now = System.currentTimeMillis(); val dtMs = (now - lastAt).coerceAtLeast(1); lastAt = now
            UsageStore.addSeconds(dtMs / 1000)
            val p = SmartRouter.pingMs(server, protectFn)
            pingMs.value = p
            ProfileStore.recordPing(server, p >= 0)
            tick++

            // IP Lock: re-check the real exit IP about every 5 minutes (only when the lock is on)
            if (tick % (if (m == TaskMode.GAMING) 150 else 38) == 1 && p >= 0 && ProfileStore.get(server).lock) {
                val info = ExitProbe.probe(server, protectFn)
                if (info != null && ProfileStore.recordExit(server, info)) {
                    HistoryStore.add(server.name, "IP change detected: now ${info.ip}")
                    notify("IP CHANGED • exit IP is now ${info.ip}")
                }
            }

            if (p < 0) {
                fails++
                if (fails == 3) {
                    HistoryStore.add(server.name, "Proxy unreachable"); UsageStore.addInterruption()
                    DevLog.log("Proxy unreachable (3 failed checks)")
                    if (tryFailover(m, stickyHost, server, protectFn)) return // switched: new job took over
                }
                if (fails >= 3) {
                    if (killSwitch) {
                        currentIp.value = "BLOCKED"
                        notify(if (failoverOffer.value != null) "KILL SWITCH • backup server ready, open the app to approve"
                        else "KILL SWITCH • proxy down, traffic blocked")
                    } else if (failoverOffer.value == null) { notify("OFF • proxy lost"); stopSelf(); return }
                }
            } else {
                if (fails >= 3) {
                    HistoryStore.add(server.name, "Proxy reachable again"); failoverOffer.value = null
                    currentIp.value = server.host; notify("ON • $label • IP ${server.host}")
                }
                fails = 0
            }

            // Real counters from the tunnel (SOCKS5 path only)
            if (coreRunning) {
                val st = try { TProxyService.TProxyGetStats() } catch (_: Throwable) { null }
                if (st != null && st.size >= 4) {
                    val total = st[1] + st[3]
                    val delta = (total - lastTotal).coerceAtLeast(0); lastTotal = total
                    UsageStore.addBytes(key(server), delta)
                    throughputBps.value = delta * 1000 / dtMs
                    if (m == TaskMode.DATA_SAVER) savedMb.value = total * 0.3 / 1_048_576.0 // estimate
                    val pct = UsageStore.budgetPercent()
                    if (pct != null) {
                        val level = if (pct >= 100) 100 else if (pct >= 80) 80 else 0
                        if (level > warned) {
                            warned = level
                            HistoryStore.add(server.name, "Data budget: $pct% of the monthly limit used")
                            notify("DATA • you have used $pct% of your monthly budget")
                        }
                    }
                }
            }
        }
    }

    /**
     * The primary server stopped answering. Look for a working backup (reachable AND able to
     * read the exit IP). STRICT: offer it and wait for approval. AUTO: switch and report the IP change.
     * Returns true if a new connection job took over.
     */
    private suspend fun tryFailover(m: TaskMode?, stickyHost: String?, current: ProxyServer, protectFn: (Socket) -> Unit): Boolean {
        val all = SmartRouter.SERVERS
        val primary = primaryKey?.let { k -> all.firstOrNull { key(it) == k } } ?: current
        val cfg = ProfileStore.get(primary)
        if (cfg.failover == "OFF") return false
        val backups = cfg.backups.split(",").filter { it.isNotBlank() }.mapNotNull { k -> all.firstOrNull { key(it) == k } }
        val order = (listOf(primary) + backups).filter { key(it) != key(current) }.distinctBy { key(it) }
        for (cand in order) {
            if (SmartRouter.pingMs(cand, protectFn) < 0) continue
            val info = ExitProbe.probe(cand, protectFn) ?: continue // must really work, not just answer
            val prevIp = ProfileStore.get(current).lastExitIp
            ProfileStore.recordExit(cand, info)
            val note = if (prevIp != null && prevIp != info.ip) "Failover to ${cand.name}: exit IP changed from $prevIp to ${info.ip}"
            else "Failover to ${cand.name}: exit IP is ${info.ip}"
            if (cfg.failover == "AUTO") {
                failoverNote = note
                UsageStore.addReconnect()
                HistoryStore.add(current.name, "Failover: switching to ${cand.name}")
                DevLog.log("Failover to ${cand.name}")
                return startConnect(m, stickyHost, key(cand))
            } else {
                failoverOffer.value = key(cand)
                HistoryStore.add(current.name, "Backup ${cand.name} is ready; waiting for your approval")
                DevLog.log("Backup ${cand.name} ready, waiting for approval")
                return false
            }
        }
        HistoryStore.add(current.name, "No working backup found")
        return false
    }

    /** Best effort: watch real (non-VPN) networks so a Wi-Fi <-> mobile switch is noticed. */
    private fun registerNetworkWatcher() {
        val req = NetworkRequest.Builder()
            .addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
            .addCapability(NetworkCapabilities.NET_CAPABILITY_NOT_VPN).build()
        val cb = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) {
                val name = activeName ?: return
                if (System.currentTimeMillis() - connectedAt < 8000) return // ignore our own start-up
                HistoryStore.add(name, "Network changed"); DevLog.log("Network changed")
                scope.launch { afterNetworkChange() }
            }
        }
        netCb = cb
        try { getSystemService(ConnectivityManager::class.java).registerNetworkCallback(req, cb) } catch (_: Exception) {}
    }

    private suspend fun afterNetworkChange() {
        delay(1500)
        val s = activeServer ?: return
        val protectFn: (Socket) -> Unit = { protect(it) }
        if (SmartRouter.pingMs(s, protectFn) < 0) { HistoryStore.add(s.name, "Network changed: proxy unreachable"); return }
        val info = ExitProbe.probe(s, protectFn)
        if (info != null) { ProfileStore.recordExit(s, info); HistoryStore.add(s.name, "Network changed: verified, exit IP ${info.ip}") }
        else HistoryStore.add(s.name, "Network changed: proxy reachable, exit IP not verified")
        if (getSharedPreferences("omni_prefs", MODE_PRIVATE).getBoolean("auto_reconnect", true)) {
            UsageStore.addReconnect(); HistoryStore.add(s.name, "Reconnecting tunnel")
            val m = lastMode; val st = lastSticky; val f = lastForced
            startConnect(m, st, f)
        }
    }

    private fun writeConfig(ip: String, s: ProxyServer, mapDns: Boolean): File {
        fun q(v: String) = "'" + v.replace("'", "''") + "'"
        val sb = StringBuilder()
        sb.append("tunnel:\n  mtu: 8500\n  ipv4: 198.18.0.1\n  ipv6: 'fc00::1'\n")
        sb.append("socks5:\n  port: ${s.port}\n  address: ${q(ip)}\n  udp: 'udp'\n")
        if (s.user != null) sb.append("  username: ${q(s.user)}\n  password: ${q(s.pass ?: "")}\n")
        if (mapDns) sb.append("mapdns:\n  address: 198.18.0.2\n  port: 53\n  network: 100.64.0.0\n  netmask: 255.192.0.0\n  cache-size: 10000\n")
        sb.append("misc:\n  task-stack-size: 81920\n  log-level: warn\n")
        return File(cacheDir, "tunnel.yml").also { it.writeText(sb.toString()) }
    }

    private fun closeTunnel() {
        if (coreRunning) { try { TProxyService.TProxyStopService() } catch (_: Throwable) {}; coreRunning = false }
        proxy?.stop(); proxy = null
        try { tun?.close() } catch (_: Exception) {}; tun = null
    }

    override fun onRevoke() { stopSelf() }

    override fun onDestroy() {
        job?.cancel(); scope.cancel(); closeTunnel()
        activeName?.let { HistoryStore.add(it, "Disconnected") }; activeName = null; activeServer = null
        DevLog.engine = "Not running"; DevLog.log("Disconnected")
        netCb?.let { try { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } catch (_: Exception) {} }
        if (mode.value != TaskMode.BANKING) mode.value = null
        stickyIp.value = null; currentIp.value = null; pingMs.value = 0; connecting.value = false
        machine.finishDisconnect()
        running = false
        usingBackupFrom.value = null; failoverOffer.value = null; throughputBps.value = 0
        super.onDestroy()
    }

    // ---------- Notification (ON/OFF + IP) ----------
    private fun buildNotification(text: String): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "VPN status", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val stop = PendingIntent.getService(this, 1,
            Intent(this, OmniVpnService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val nb = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return nb.setContentTitle("OmniProxy").setContentText(text)
            .setSmallIcon(android.R.drawable.ic_lock_lock).setContentIntent(open).setOngoing(true)
            .addAction(Notification.Action.Builder(null, "Turn OFF", stop).build()).build()
    }

    private fun goForeground(text: String) {
        val n = buildNotification(text)
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        else startForeground(1, n)
    }

    private fun notify(text: String) {
        statusText.value = text
        getSystemService(NotificationManager::class.java).notify(1, buildNotification(text))
    }
}
