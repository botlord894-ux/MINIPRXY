package com.omniproxy.app.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.*
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

@Composable
fun LiquidTab(draft: Appearance, upd: ((Appearance) -> Appearance) -> Unit) {
    var sub by remember { mutableStateOf("Presets") }
    var colorEdit by remember { mutableStateOf<String?>(null) }
    val l = draft.liquid
    val r = remember(draft) { Resolver.resolve(draft) }
    val reduce = rememberReduceMotion() || draft.reduceMotion
    // any manual change marks the liquid as custom, so automatic harmony never overwrites it
    fun edit(f: (LiquidStyle) -> LiquidStyle) = upd { a -> a.copy(liquid = f(a.liquid).copy(preset = "custom_liquid")) }

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp)) {
            listOf("Presets", "Colors", "Animation", "Position").forEach { t -> Chip(t, sub == t) { sub = t } }
        }
        when (sub) {
            "Presets" -> {
                SectionTitle("Liquid presets")
                val tiles = Presets.liquids.map { it.id to it.name } + ("custom_liquid" to "Custom Liquid")
                tiles.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (id, name) ->
                            val preset = Presets.liquids.firstOrNull { it.id == id }
                            val style = if (preset != null) Presets.applyLiquid(l, preset) else l.copy(preset = "custom_liquid")
                            val sel = l.preset == id
                            Column(
                                Modifier.weight(1f).clip(RoundedCornerShape(16.dp)).background(Surface2)
                                    .border(if (sel) 2.dp else 1.dp, if (sel) Purple else Border, RoundedCornerShape(16.dp))
                                    .clickable { upd { a -> a.copy(liquid = if (preset != null) Presets.applyLiquid(a.liquid, preset) else a.liquid.copy(preset = "custom_liquid")) } }
                                    .padding(vertical = 4.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                LiquidConnectButton(LiquidState.DISCONNECTED, style, r.palette, draft.bg.imageAccent, 40.dp, true, interactive = false)
                                Text(name, color = if (sel) TextPrimary else TextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, maxLines = 2)
                            }
                        }
                        repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                SwitchLine("Adaptive color", "Match the background or theme, without changing your saved colors", l.adaptive) { v -> upd { a -> a.copy(liquid = a.liquid.copy(adaptive = v)) } }
                SwitchLine("Automatic color harmony", "Theme changes may retune the button, unless you picked custom colors", l.autoHarmony) { v -> upd { a -> a.copy(liquid = a.liquid.copy(autoHarmony = v)) } }
                Spacer(Modifier.height(6.dp))
                OmniOutlinedButton(onClick = { upd { a -> a.copy(liquid = LiquidStyle()) } }, modifier = Modifier.fillMaxWidth()) { Text("Back to the default Omni Purple button") }
            }
            "Colors" -> {
                SectionTitle("Liquid colors")
                ColorRow("Liquid color", l.color1) { colorEdit = "c1" }
                ColorRow("Secondary liquid color", l.color2) { colorEdit = "c2" }
                ColorRow("Highlight color", l.highlight) { colorEdit = "hi" }
                ColorRow("Glow color", l.glow) { colorEdit = "glow" }
                ColorRow("Icon color", l.iconColor) { colorEdit = "icon" }
                SectionTitle("Material")
                LabeledSlider("Transparency", l.transparency, 0f..1f, ::pct) { v -> edit { it.copy(transparency = v) } }
                LabeledSlider("Blur amount", l.blur, 0f..1f, ::pct) { v -> edit { it.copy(blur = v) } }
                LabeledSlider("Glow intensity", l.glowIntensity, 0f..2f, ::pct) { v -> edit { it.copy(glowIntensity = v) } }
                LabeledSlider("Highlight intensity", l.highlightIntensity, 0f..1.5f, ::pct) { v -> edit { it.copy(highlightIntensity = v) } }
                LabeledSlider("Outline visibility", l.outlineVisibility, 0f..1f, ::pct) { v -> edit { it.copy(outlineVisibility = v) } }
                LabeledSlider("Outline thickness", l.outlineThickness, 0f..6f, ::dpText) { v -> edit { it.copy(outlineThickness = v) } }
                LabeledSlider("Shadow intensity", l.shadow, 0f..1f, ::pct) { v -> edit { it.copy(shadow = v) } }
                LabeledSlider("Background blending", l.blend, 0f..1f, ::pct) { v -> edit { it.copy(blend = v) } }
            }
            "Animation" -> {
                SectionTitle("Motion")
                LabeledSlider("Animation speed", l.speed, 0.1f..2f, ::pct) { v -> upd { a -> a.copy(liquid = a.liquid.copy(speed = v)) } }
                LabeledSlider("Liquid movement", l.movement, 0f..2f, ::pct) { v -> upd { a -> a.copy(liquid = a.liquid.copy(movement = v)) } }
                LabeledSlider("Shape deformation", l.deformation, 0f..2f, ::pct) { v -> upd { a -> a.copy(liquid = a.liquid.copy(deformation = v)) } }
                LabeledSlider("Floating height", l.floatHeight, 0f..24f, ::dpText) { v -> upd { a -> a.copy(liquid = a.liquid.copy(floatHeight = v)) } }
                SwitchLine("Reduce motion", "A calm, almost still liquid. Also follows Android's remove-animations setting", draft.reduceMotion) { v -> upd { a -> a.copy(reduceMotion = v) } }
                SectionTitle("How each state looks")
                Text("These are previews only. The real button always shows the real VPN state.", color = TextSecondary, fontSize = 11.sp)
                LiquidState.values().toList().chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        row.forEach { st ->
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                LiquidConnectButton(st, l, r.palette, draft.bg.imageAccent, 44.dp, reduce, interactive = false)
                                Text(st.name.lowercase().replaceFirstChar { it.uppercase() }, color = TextSecondary, fontSize = 10.sp)
                            }
                        }
                    }
                }
            }
            else -> {
                SectionTitle("Size")
                LabeledSlider("Button size (centered)", l.size, 120f..260f, ::dpText) { v -> upd { a -> a.copy(liquid = a.liquid.copy(size = v)) } }
                LabeledSlider("Button size (floating)", l.floatSize, 64f..140f, ::dpText) { v -> upd { a -> a.copy(liquid = a.liquid.copy(floatSize = v)) } }
                LabeledSlider("Icon size", l.iconSize, 28f..80f, ::dpText) { v -> upd { a -> a.copy(liquid = a.liquid.copy(iconSize = v)) } }
                SectionTitle("Position")
                val spots = listOf("center" to "Center", "bottom" to "Bottom", "top" to "Top", "bottom_left" to "Bottom left", "bottom_right" to "Bottom right", "custom" to "Custom (drag)")
                spots.chunked(3).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { (id, name) -> PositionTile(id, name, l, r.palette, Modifier.weight(1f)) { upd { a -> a.copy(liquid = a.liquid.copy(position = id)) } } }
                    }
                }
                if (l.position == "custom") {
                    Text("Drag inside the box to place the button. It stays on screen, and tapping it still connects.", color = TextSecondary, fontSize = 11.sp)
                    Spacer(Modifier.height(6.dp))
                    DragPad(l, r.palette, draft.bg.imageAccent) { x, y -> upd { a -> a.copy(liquid = a.liquid.copy(posX = x, posY = y)) } }
                }
                Text("A floating button sits over the Home screen. Home leaves space for it so it doesn't cover controls.", color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }

    colorEdit?.let { which ->
        val initial = when (which) { "c1" -> l.color1; "c2" -> l.color2; "hi" -> l.highlight; "glow" -> l.glow; else -> l.iconColor }
        ColorPickerDialog("Choose color", initial, onDismiss = { colorEdit = null }) { c ->
            colorEdit = null
            edit { when (which) { "c1" -> it.copy(color1 = c); "c2" -> it.copy(color2 = c); "hi" -> it.copy(highlight = c); "glow" -> it.copy(glow = c); else -> it.copy(iconColor = c) }.copy(preset = "custom_liquid") }
        }
    }
}

@Composable
private fun PositionTile(id: String, name: String, l: LiquidStyle, p: Palette, modifier: Modifier, onClick: () -> Unit) {
    val sel = l.position == id
    Column(modifier.clip(RoundedCornerShape(14.dp)).background(Surface2)
        .border(if (sel) 2.dp else 1.dp, if (sel) Purple else Border, RoundedCornerShape(14.dp)).clickable(onClick = onClick).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(width = 44.dp, height = 70.dp).clip(RoundedCornerShape(8.dp)).background(Color(p.bg2)).border(1.dp, Border, RoundedCornerShape(8.dp))) {
            val al = when (id) {
                "top" -> Alignment.TopCenter; "bottom" -> Alignment.BottomCenter; "bottom_left" -> Alignment.BottomStart
                "bottom_right" -> Alignment.BottomEnd; "custom" -> Alignment.CenterEnd; else -> Alignment.Center
            }
            Box(Modifier.align(al).padding(4.dp).size(14.dp).clip(CircleShape).background(Color(p.accent)))
        }
        Text(name, color = if (sel) TextPrimary else TextSecondary, fontSize = 10.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 4.dp))
    }
}

/** A phone-shaped box you drag the orb inside. The position is stored as fractions, so it fits any screen. */
@Composable
private fun DragPad(l: LiquidStyle, p: Palette, accent: Int, onMove: (Float, Float) -> Unit) {
    var size by remember { mutableStateOf(IntSize(1, 1)) }
    val padW = 160.dp; val padH = 270.dp
    val orb = 40.dp * 1.7f
    Box(
        Modifier.size(padW, padH).clip(RoundedCornerShape(20.dp)).background(Color(p.bg2)).border(1.dp, Border, RoundedCornerShape(20.dp))
            .onSizeChanged { size = it }
            .pointerInput(Unit) {
                fun at(o: Offset) {
                    // map the touch point to the orb's top-left fraction so the orb centres under the finger and never leaves the box
                    val w = size.width.toFloat(); val h = size.height.toFloat()
                    val orbPx = orb.toPx()
                    val fx = ((o.x - orbPx / 2) / (w - orbPx)).coerceIn(0f, 1f)
                    val fy = ((o.y - orbPx / 2) / (h - orbPx)).coerceIn(0f, 1f)
                    onMove(fx, fy)
                }
                detectDragGestures(onDragStart = { at(it) }, onDrag = { c, _ -> c.consume(); at(c.position) })
            }
    ) {
        LiquidConnectButton(
            LiquidState.DISCONNECTED, l, p, accent, 40.dp, true, interactive = false,
            modifier = Modifier.offset(x = (padW - orb) * l.posX.coerceIn(0f, 1f), y = (padH - orb) * l.posY.coerceIn(0f, 1f))
        )
    }
}
