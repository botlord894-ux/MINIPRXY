package com.omniproxy.app.appearance

import android.graphics.Color as AColor
import kotlin.math.pow

/** Pure colour maths (ARGB ints). Used for contrast checks, blending and HEX input. */
object ColorUtils {
    fun lum(argb: Int): Float {
        fun ch(v: Int): Double { val c = v / 255.0; return if (c <= 0.03928) c / 12.92 else ((c + 0.055) / 1.055).pow(2.4) }
        val r = ch((argb shr 16) and 0xFF); val g = ch((argb shr 8) and 0xFF); val b = ch(argb and 0xFF)
        return (0.2126 * r + 0.7152 * g + 0.0722 * b).toFloat()
    }

    /** WCAG contrast ratio, 1..21. */
    fun contrast(a: Int, b: Int): Float {
        val l1 = lum(a); val l2 = lum(b)
        return (maxOf(l1, l2) + 0.05f) / (minOf(l1, l2) + 0.05f)
    }

    fun blend(a: Int, b: Int, t: Float): Int {
        fun ch(sh: Int) = (((a shr sh) and 0xFF) * (1 - t) + ((b shr sh) and 0xFF) * t).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (ch(16) shl 16) or (ch(8) shl 8) or ch(0)
    }

    /** [fg] drawn with [alpha] over [bg]. */
    fun composite(fg: Int, alpha: Float, bg: Int): Int = blend(bg, fg, alpha.coerceIn(0f, 1f))

    /** A grey whose relative luminance is about [l]. */
    fun gray(l: Float): Int {
        val v = (255.0 * l.coerceIn(0f, 1f).toDouble().pow(1.0 / 2.2)).toInt().coerceIn(0, 255)
        return (0xFF shl 24) or (v shl 16) or (v shl 8) or v
    }

    fun hueShift(argb: Int, deg: Float): Int {
        val hsv = FloatArray(3)
        AColor.colorToHSV(argb, hsv)
        hsv[0] = (hsv[0] + deg + 360f) % 360f
        return AColor.HSVToColor(hsv)
    }

    fun hex(argb: Int): String = "#%06X".format(argb and 0xFFFFFF)

    /** "#RRGGBB" or "RRGGBB" -> opaque ARGB, or null if invalid. */
    fun parseHex(s: String): Int? {
        val t = s.trim().removePrefix("#")
        if (t.length != 6 || !t.all { it.isDigit() || it.lowercaseChar() in 'a'..'f' }) return null
        return (0xFF shl 24) or t.toInt(16)
    }

    /** [preferred] if it reads well (4.5:1) on every background, otherwise white or black, whichever is better. */
    fun readable(preferred: Int, vararg bgs: Int): Int {
        fun score(c: Int) = bgs.minOf { contrast(c, it) }
        if (score(preferred) >= 4.5f) return preferred
        val white = (0xFF shl 24) or 0xFFFFFF
        val black = 0xFF shl 24
        return if (score(white) >= score(black)) white else black
    }
}
