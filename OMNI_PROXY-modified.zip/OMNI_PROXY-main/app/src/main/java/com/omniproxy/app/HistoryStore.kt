package com.omniproxy.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

data class HistoryEvent(val time: Long, val profile: String, val text: String)

/** Minimal connection log: events only (no websites, no traffic). Stays on this device. */
object HistoryStore {
    val version = MutableStateFlow(0)
    private const val MAX = 200
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("history", Context.MODE_PRIVATE)
    }

    fun enabled(): Boolean = prefs?.getBoolean("on", true) ?: true
    fun setEnabled(on: Boolean) { prefs?.edit()?.putBoolean("on", on)?.apply(); version.value = version.value + 1 }

    /** How many days to keep events. 0 = keep until deleted (max 200 events). */
    fun retainDays(): Int = prefs?.getInt("retain_days", 0) ?: 0
    fun setRetainDays(d: Int) { prefs?.edit()?.putInt("retain_days", d)?.apply(); version.value = version.value + 1 }

    @Synchronized
    fun add(profile: String, text: String) {
        val p = prefs ?: return
        if (!enabled()) return
        val arr = try { JSONArray(p.getString("events", "[]")) } catch (e: Exception) { JSONArray() }
        arr.put(JSONObject().put("t", System.currentTimeMillis()).put("p", profile).put("e", text))
        val cutoff = if (retainDays() > 0) System.currentTimeMillis() - retainDays() * 86_400_000L else 0L
        val kept = JSONArray()
        for (i in maxOf(0, arr.length() - MAX) until arr.length()) {
            val o = arr.getJSONObject(i)
            if (o.getLong("t") >= cutoff) kept.put(o)
        }
        p.edit().putString("events", kept.toString()).apply()
        version.value = version.value + 1
    }

    /** Newest first, honoring the retention period. */
    @Synchronized
    fun list(): List<HistoryEvent> {
        val raw = prefs?.getString("events", "[]") ?: return emptyList()
        val cutoff = if (retainDays() > 0) System.currentTimeMillis() - retainDays() * 86_400_000L else 0L
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i); HistoryEvent(o.getLong("t"), o.getString("p"), o.getString("e"))
            }.filter { it.time >= cutoff }.reversed()
        } catch (e: Exception) { emptyList() }
    }

    fun clear() { prefs?.edit()?.putString("events", "[]")?.apply(); version.value = version.value + 1 }
}
