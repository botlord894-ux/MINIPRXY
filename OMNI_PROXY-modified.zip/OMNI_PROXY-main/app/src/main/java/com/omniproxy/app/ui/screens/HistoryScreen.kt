package com.omniproxy.app.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.Diagnostics
import com.omniproxy.app.HistoryStore
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Connection history: events only, never websites or traffic. */
@Composable
fun HistoryScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val ver by HistoryStore.version.collectAsState()
    val events = remember(ver) { HistoryStore.list() }
    val enabled = remember(ver) { HistoryStore.enabled() }
    val days = remember(ver) { HistoryStore.retainDays() }
    val fmt = remember { SimpleDateFormat("MMM d, HH:mm", Locale.getDefault()) }
    var confirm by remember { mutableStateOf(false) }
    var copied by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Connection History", "Stored only on this device.")
        Spacer(Modifier.height(14.dp))
        OmniCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Keep connection history", color = Color.White, fontWeight = FontWeight.SemiBold)
                        Text("Connect, disconnect, tests and IP changes. No websites.", color = TextSecondary, fontSize = 12.sp)
                    }
                    Switch(checked = enabled, onCheckedChange = { HistoryStore.setEnabled(it) },
                        colors = SwitchDefaults.colors(checkedTrackColor = Purple, checkedThumbColor = Color.White,
                            uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
                }
                Text("Keep events for", color = TextSecondary, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Segment("Until deleted", days == 0, Modifier.weight(1.4f)) { HistoryStore.setRetainDays(0) }
                    Segment("7 days", days == 7, Modifier.weight(1f)) { HistoryStore.setRetainDays(7) }
                    Segment("30 days", days == 30, Modifier.weight(1f)) { HistoryStore.setRetainDays(30) }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (events.isEmpty()) item { Text("No events yet.", color = TextSecondary, modifier = Modifier.padding(8.dp)) }
            items(events) { e ->
                OmniCard(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(e.text, color = Color.White, fontSize = 14.sp)
                            Text(e.profile, color = TextSecondary, fontSize = 12.sp)
                        }
                        Text(fmt.format(Date(e.time)), color = TextSecondary, fontSize = 11.sp)
                    }
                }
            }
        }
        TextButton(onClick = {
            val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("OmniProxy report", Diagnostics.report(ctx))); copied = true
        }, modifier = Modifier.fillMaxWidth()) {
            Text(if (copied) "Report copied (no passwords included)" else "Copy diagnostic report", color = PurpleLight)
        }
        TextButton(onClick = { confirm = true }, modifier = Modifier.fillMaxWidth()) { Text("Delete history", color = Danger) }
        Spacer(Modifier.height(8.dp))
    }
    if (confirm) AlertDialog(
        onDismissRequest = { confirm = false }, containerColor = CardBg,
        title = { Text("Delete all history?", color = Color.White) },
        text = { Text("This cannot be undone.", color = TextSecondary) },
        confirmButton = { TextButton(onClick = { HistoryStore.clear(); confirm = false }) { Text("Delete", color = Danger) } },
        dismissButton = { TextButton(onClick = { confirm = false }) { Text("Cancel", color = TextSecondary) } }
    )
}
