package com.omniproxy.app.ui.screens.studio

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.*
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

@Composable
fun ButtonsTab(draft: Appearance, upd: ((Appearance) -> Appearance) -> Unit) {
    val b = draft.button
    val p = remember(draft) { Resolver.resolve(draft).palette }
    fun edit(f: (ButtonStyle) -> ButtonStyle) = upd { a -> a.copy(button = f(a.button)) }

    Column(Modifier.fillMaxWidth()) {
        SectionTitle("Shape")
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("rounded" to "Rounded", "pill" to "Pill", "square" to "Square", "custom" to "Cut corners").forEach { (id, name) ->
                val sel = b.shape == id
                Column(Modifier.weight(1f).clip(RoundedCornerShape(14.dp)).background(Surface2)
                    .border(if (sel) 2.dp else 1.dp, if (sel) Purple else Border, RoundedCornerShape(14.dp))
                    .clickable { edit { it.copy(shape = id) } }.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    SampleButton("Aa", b.copy(shape = id), p, true, Modifier.fillMaxWidth(), 32.dp)
                    Text(name, color = if (sel) TextPrimary else TextSecondary, fontSize = 10.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        SectionTitle("Style")
        Row(Modifier.horizontalScroll(rememberScrollState())) {
            listOf("filled" to "Filled", "outlined" to "Outlined", "transparent" to "Transparent").forEach { (id, name) ->
                Chip(name, b.variant == id) { edit { it.copy(variant = id) } }
            }
        }
        SectionTitle("Size and spacing")
        LabeledSlider("Corner radius", b.radius, 0f..32f, ::dpText) { v -> edit { it.copy(radius = v) } }
        LabeledSlider("Button height", b.height, 44f..64f, ::dpText) { v -> edit { it.copy(height = v) } }
        LabeledSlider("Spacing between icon and text", b.spacing, 4f..20f, ::dpText) { v -> edit { it.copy(spacing = v) } }
        LabeledSlider("Icon size", b.iconSize, 14f..28f, ::dpText) { v -> edit { it.copy(iconSize = v) } }
        SectionTitle("Feel")
        LabeledSlider("Shadow and elevation", b.elevation, 0f..12f, ::dpText) { v -> edit { it.copy(elevation = v) } }
        LabeledSlider("Press animation", b.animation, 0f..1f, ::pct) { v -> edit { it.copy(animation = v) } }
        SwitchLine("Ripple effect", "Touch ripple on buttons", b.ripple) { v -> edit { it.copy(ripple = v) } }
        SwitchLine("Icon after the text", "Place button icons at the end", b.iconAtEnd) { v -> edit { it.copy(iconAtEnd = v) } }
        Text("Buttons never shrink below the 48 dp touch size, and destructive actions (Delete, Reset) keep their red color.",
            color = TextSecondary, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
fun LayoutTab(draft: Appearance, upd: ((Appearance) -> Appearance) -> Unit) {
    val c = draft.card
    val n = draft.nav
    Column(Modifier.fillMaxWidth()) {
        SectionTitle("Cards")
        LabeledSlider("Card opacity", c.alpha, 0.3f..1f, ::pct) { v -> upd { a -> a.copy(card = a.card.copy(alpha = v)) } }
        LabeledSlider("Corner radius", c.radius, 0f..32f, ::dpText) { v -> upd { a -> a.copy(card = a.card.copy(radius = v)) } }
        LabeledSlider("Border thickness", c.borderWidth, 0f..4f, ::dpText) { v -> upd { a -> a.copy(card = a.card.copy(borderWidth = v)) } }
        LabeledSlider("Shadow", c.shadow, 0f..12f, ::dpText) { v -> upd { a -> a.copy(card = a.card.copy(shadow = v)) } }
        Text("Card, border and navigation colors are in the Theme tab.", color = TextSecondary, fontSize = 11.sp)
        SectionTitle("Navigation bar")
        LabeledSlider("Background opacity", n.bgAlpha, 0.3f..1f, ::pct) { v -> upd { a -> a.copy(nav = a.nav.copy(bgAlpha = v)) } }
        LabeledSlider("Height and density", n.height, 56f..96f, ::dpText) { v -> upd { a -> a.copy(nav = a.nav.copy(height = v)) } }
        SwitchLine("Selected item highlight", "Show a pill behind the selected item", n.showIndicator) { v -> upd { a -> a.copy(nav = a.nav.copy(showIndicator = v)) } }
        SwitchLine("Always show labels", "Off shows a label only for the selected item", n.alwaysLabels) { v -> upd { a -> a.copy(nav = a.nav.copy(alwaysLabels = v)) } }
        SectionTitle("Accessibility")
        SwitchLine("High contrast", "Pure black or white text and stronger borders", draft.highContrast) { v -> upd { a -> a.copy(highContrast = v) } }
        SwitchLine("Reduce motion", "A calm, almost still liquid and background", draft.reduceMotion) { v -> upd { a -> a.copy(reduceMotion = v) } }
    }
}
