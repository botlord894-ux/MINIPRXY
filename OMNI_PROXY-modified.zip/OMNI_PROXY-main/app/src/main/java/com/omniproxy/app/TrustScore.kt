package com.omniproxy.app

/** One criterion. earned == null means "not tested yet" (never counted as a pass). */
data class TrustItem(val name: String, val possible: Int, val earned: Int?, val detail: String, val how: String)

data class TrustReport(val items: List<TrustItem>) {
    val tested get() = items.filter { it.earned != null }
    val earned get() = tested.sumOf { it.earned ?: 0 }
    val possibleTested get() = tested.sumOf { it.possible }
    /** Score out of 100 over the tested criteria only, or null if nothing was tested. */
    val score: Int? get() = if (possibleTested == 0) null else earned * 100 / possibleTested
}

/** Disclosed criteria worth 100 points in total. Untested criteria are excluded, not assumed good. */
object TrustScore {
    fun compute(s: ProxyServer): TrustReport {
        val p = ProfileStore.get(s)
        val when_ = if (p.testedAt > 0) " (${Fmt.ago(p.testedAt)})" else ""
        val rel = ProfileStore.reliability(s)
        val items = listOf(
            TrustItem("Reachability", 20,
                when { p.reach == -2 -> null; p.reach == -1 -> 0; else -> 20 },
                when { p.reach == -2 -> "Not tested yet."; p.reach == -1 -> "No answer at the last test$when_."; else -> "Answered in ${p.reach} ms$when_." },
                "Full points if the server answered a TCP connection at the last Check IP Health."),
            TrustItem("Exit IP verified", 20,
                if (p.lastCheckedAt > 0) 20 else null,
                if (p.lastExitIp != null) "Exit IP ${p.lastExitIp} was read through the proxy (${Fmt.ago(p.lastCheckedAt)})." else "Not tested yet.",
                "Full points if we could ask ipinfo.io for the exit IP through this proxy."),
            TrustItem("Exit country", 15,
                when (p.countryOk) { 1 -> 15; 0 -> 0; else -> null },
                when (p.countryOk) { 1 -> "Matches the country you set$when_."; 0 -> "Does not match the country you set$when_."; else -> "Not tested, or no country is set." },
                "Full points if the exit IP's country equals the country saved for this server."),
            TrustItem("DNS", 10,
                when (p.dns) { 1 -> 10; 0 -> 0; else -> null },
                when (p.dns) { 1 -> "The proxy resolved a test hostname$when_."; 0 -> "The proxy failed to resolve a test hostname."; else -> "Not tested yet." },
                "One test lookup through the proxy. It does not prove every app is leak-free."),
            TrustItem("Stability", 20,
                rel?.let { 20 * it.first / it.second },
                rel?.let { "${it.first} of the last ${it.second} checks answered." } ?: "Needs at least 5 checks. Keep the Servers tab open or stay connected to collect more.",
                "20 points x (checks answered / recent checks). Only the last 30 checks count, so this is not a long-term uptime figure."),
            TrustItem("IP reputation", 10,
                when (p.rep) { "CLEAN" -> 10; "BANNED" -> 0; else -> null },
                when (p.rep) { "CLEAN" -> "Not flagged as Tor by ipinfo.io$when_."; "BANNED" -> "Flagged by ipinfo.io$when_."; else -> "Not checked (free check, or Local-Only Mode is on)." },
                "Limited: the free ipinfo.io check only flags Tor exits. It is not a full blacklist lookup."),
            TrustItem("IP consistency", 5,
                if (p.exitChecks >= 3) maxOf(0, 5 - 2 * p.exitChanges) else null,
                if (p.exitChecks >= 3) "The exit IP changed ${p.exitChanges} time(s) in ${p.exitChecks} measurements." else "Needs at least 3 exit-IP measurements.",
                "5 points, minus 2 for every time the exit IP differed from the previous measurement.")
        )
        return TrustReport(items)
    }
}
