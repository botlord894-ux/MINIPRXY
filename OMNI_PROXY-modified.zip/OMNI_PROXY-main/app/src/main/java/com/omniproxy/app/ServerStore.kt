package com.omniproxy.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Saves the user's proxy servers on the device (SharedPreferences, JSON). */
object ServerStore {

    /** Bumped on every change so screens can refresh. */
    val version = MutableStateFlow(0)

    /** Placeholders shown until you add your own (203.0.113.x is a reserved test range). */
    val DEFAULTS = listOf(
        ProxyServer(name = "Demo US", host = "203.0.113.10", port = 1080, type = ProxyType.SOCKS5, country = "US"),
        ProxyServer(name = "Demo UK", host = "203.0.113.20", port = 1080, type = ProxyType.SOCKS5, country = "GB"),
        ProxyServer(name = "Demo DE (compression)", host = "203.0.113.30", port = 8080, type = ProxyType.HTTP, country = "DE", compression = true)
    )

    private var prefs: SharedPreferences? = null
    private var cache: List<ProxyServer>? = null

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("servers", Context.MODE_PRIVATE)
    }

    @Synchronized
    fun list(): List<ProxyServer> {
        cache?.let { return it }
        val p = prefs ?: return DEFAULTS
        val raw = p.getString("list", null)
        val l = if (raw == null) DEFAULTS else parse(raw)
        cache = l
        return l
    }

    fun add(s: ProxyServer) = save(list() + s)

    fun rename(s: ProxyServer, newName: String) = save(list().map { x ->
        if (x.host == s.host && x.port == s.port) x.copy(name = newName.ifBlank { x.host }) else x
    })

    fun remove(s: ProxyServer) = save(list().filterNot { it.host == s.host && it.port == s.port })

    @Synchronized
    private fun save(l: List<ProxyServer>) {
        cache = l
        prefs?.edit()?.putString("list", toJson(l))?.apply()
        version.value = version.value + 1
    }

    private fun toJson(l: List<ProxyServer>): String {
        val arr = JSONArray()
        for (s in l) arr.put(JSONObject().apply {
            put("name", s.name); put("host", s.host); put("port", s.port)
            put("type", s.type.name); put("country", s.country)
            if (s.user != null) put("user", s.user)
            if (s.pass != null) put("pass", s.pass)
            put("compression", s.compression); put("udp", s.udp)
        })
        return arr.toString()
    }

    private fun parse(raw: String): List<ProxyServer> = try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ProxyServer(
                name = o.getString("name"), host = o.getString("host"), port = o.getInt("port"),
                type = ProxyType.valueOf(o.getString("type")), country = o.getString("country"),
                user = if (o.has("user")) o.getString("user") else null,
                pass = if (o.has("pass")) o.getString("pass") else null,
                compression = o.optBoolean("compression", false), udp = o.optBoolean("udp", false)
            )
        }
    } catch (e: Exception) { DEFAULTS }
}
