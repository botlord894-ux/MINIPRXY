package com.omniproxy.app

import java.util.Locale

/** Small text formatters shared by the data layer and screens. */
object Fmt {
    fun ago(t: Long): String {
        if (t <= 0) return "never"
        val d = (System.currentTimeMillis() - t) / 1000
        return when {
            d < 60 -> "just now"
            d < 3600 -> "${d / 60} min ago"
            d < 86400 -> "${d / 3600} h ago"
            else -> "${d / 86400} days ago"
        }
    }

    fun bytes(b: Long): String = when {
        b < 1024 -> "$b B"
        b < 1024L * 1024 -> String.format(Locale.US, "%.1f KB", b / 1024.0)
        b < 1024L * 1024 * 1024 -> String.format(Locale.US, "%.1f MB", b / 1048576.0)
        else -> String.format(Locale.US, "%.2f GB", b / 1073741824.0)
    }

    fun duration(sec: Long): String {
        val h = sec / 3600; val m = (sec % 3600) / 60
        return if (h > 0) "$h h $m min" else "$m min"
    }

    fun speed(kbps: Int): String =
        if (kbps >= 1000) String.format(Locale.US, "%.1f Mbps", kbps / 1000.0) else "$kbps kbps"
}
