package com.omniproxy.app

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

/** Everything we have actually measured or the user chose for one server. Stored only on this device. */
data class Profile(
    val lock: Boolean = false,          // IP Lock on/off
    val expectedIp: String? = null,     // the exit IP the lock expects
    val lastExitIp: String? = null,
    val lastExitCountry: String? = null,
    val lastExitOrg: String? = null,
    val lastCheckedAt: Long = 0,
    val lastChangeAt: Long = 0,         // when we last SAW the exit IP change
    val alertOld: String? = null,       // pending IP-change alert (old -> new)
    val alertNew: String? = null,
    val samples: String = "",           // recent reachability checks: '1' answered, '0' didn't (max 30)
    val failover: String = "OFF",       // OFF, STRICT (ask first) or AUTO
    val backups: String = "",           // comma-separated "host:port" backup servers, in order
    val reach: Int = -2,                // last truth test: -2 untested, -1 no answer, else ms
    val countryOk: Int = -1,            // -1 untested, 0 mismatch, 1 match
    val dns: Int = -1,                  // -1 untested, 0 failed, 1 ok
    val rep: String = "",               // "", CLEAN, BANNED, UNKNOWN
    val testedAt: Long = 0,
    val exitChecks: Int = 0,            // how many times the exit IP was measured
    val exitChanges: Int = 0            // how many times it differed from the previous measurement
)

object ProfileStore {
    val version = MutableStateFlow(0)
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("profiles", Context.MODE_PRIVATE)
    }

    private fun key(s: ProxyServer) = "p:${s.host}:${s.port}"

    @Synchronized
    fun get(s: ProxyServer): Profile {
        val raw = prefs?.getString(key(s), null) ?: return Profile()
        return try {
            val o = JSONObject(raw)
            Profile(
                lock = o.optBoolean("lock"),
                expectedIp = o.optString("expectedIp").ifEmpty { null },
                lastExitIp = o.optString("lastExitIp").ifEmpty { null },
                lastExitCountry = o.optString("lastExitCountry").ifEmpty { null },
                lastExitOrg = o.optString("lastExitOrg").ifEmpty { null },
                lastCheckedAt = o.optLong("lastCheckedAt"),
                lastChangeAt = o.optLong("lastChangeAt"),
                alertOld = o.optString("alertOld").ifEmpty { null },
                alertNew = o.optString("alertNew").ifEmpty { null },
                samples = o.optString("samples"),
                failover = o.optString("failover").ifEmpty { "OFF" },
                backups = o.optString("backups"),
                reach = o.optInt("reach", -2),
                countryOk = o.optInt("countryOk", -1),
                dns = o.optInt("dns", -1),
                rep = o.optString("rep"),
                testedAt = o.optLong("testedAt"),
                exitChecks = o.optInt("exitChecks"),
                exitChanges = o.optInt("exitChanges")
            )
        } catch (e: Exception) { Profile() }
    }

    @Synchronized
    private fun save(s: ProxyServer, p: Profile, bump: Boolean = true) {
        val o = JSONObject()
        o.put("lock", p.lock); o.put("expectedIp", p.expectedIp ?: "")
        o.put("lastExitIp", p.lastExitIp ?: ""); o.put("lastExitCountry", p.lastExitCountry ?: "")
        o.put("lastExitOrg", p.lastExitOrg ?: ""); o.put("lastCheckedAt", p.lastCheckedAt)
        o.put("lastChangeAt", p.lastChangeAt); o.put("alertOld", p.alertOld ?: "")
        o.put("alertNew", p.alertNew ?: ""); o.put("samples", p.samples)
        o.put("failover", p.failover); o.put("backups", p.backups)
        o.put("reach", p.reach); o.put("countryOk", p.countryOk); o.put("dns", p.dns)
        o.put("rep", p.rep); o.put("testedAt", p.testedAt)
        o.put("exitChecks", p.exitChecks); o.put("exitChanges", p.exitChanges)
        prefs?.edit()?.putString(key(s), o.toString())?.apply()
        if (bump) version.value = version.value + 1
    }

    /** Remember whether the server answered (rolling window of 30). No UI refresh. */
    fun recordPing(s: ProxyServer, ok: Boolean) {
        val p = get(s)
        save(s, p.copy(samples = (p.samples + if (ok) "1" else "0").takeLast(30)), bump = false)
    }

    /** (answered, total) over recent checks, or null until there are at least 5 samples. */
    fun reliability(s: ProxyServer): Pair<Int, Int>? {
        val sm = get(s).samples
        return if (sm.length >= 5) sm.count { it == '1' } to sm.length else null
    }

    /** Store a measured exit IP. Returns true if it differs from the previous measurement. */
    fun recordExit(s: ProxyServer, info: ExitInfo): Boolean {
        val p = get(s)
        val now = System.currentTimeMillis()
        val changed = p.lastExitIp != null && p.lastExitIp != info.ip
        var n = p.copy(
            lastExitIp = info.ip, lastExitCountry = info.country, lastExitOrg = info.org, lastCheckedAt = now,
            exitChecks = p.exitChecks + 1, exitChanges = p.exitChanges + if (changed) 1 else 0
        )
        if (changed) n = n.copy(lastChangeAt = now)
        if (p.lock) {
            n = when {
                p.expectedIp == null -> n.copy(expectedIp = info.ip)
                p.expectedIp != info.ip -> n.copy(alertOld = p.expectedIp, alertNew = info.ip)
                else -> n.copy(alertOld = null, alertNew = null) // back on the expected IP
            }
        }
        save(s, n)
        return changed
    }

    /** Results of the last Connection Truth run, used by the Trust & Health panel. */
    fun recordTruth(s: ProxyServer, reach: Int, countryOk: Int, dns: Int, rep: String) {
        save(s, get(s).copy(reach = reach, countryOk = countryOk, dns = dns, rep = rep, testedAt = System.currentTimeMillis()))
    }

    fun setLock(s: ProxyServer, on: Boolean) {
        val p = get(s)
        save(s, if (on) p.copy(lock = true, expectedIp = p.lastExitIp)
        else p.copy(lock = false, expectedIp = null, alertOld = null, alertNew = null))
    }

    fun acceptNewIp(s: ProxyServer) {
        val p = get(s)
        save(s, p.copy(expectedIp = p.alertNew ?: p.lastExitIp, alertOld = null, alertNew = null))
    }

    fun dismissAlert(s: ProxyServer) { save(s, get(s).copy(alertOld = null, alertNew = null)) }

    fun setFailover(s: ProxyServer, mode: String) { save(s, get(s).copy(failover = mode)) }

    fun setBackups(s: ProxyServer, keys: List<String>) { save(s, get(s).copy(backups = keys.joinToString(","))) }
}
