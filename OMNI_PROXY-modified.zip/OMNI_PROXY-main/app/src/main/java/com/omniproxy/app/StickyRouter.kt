package com.omniproxy.app

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.util.concurrent.TimeUnit

data class StickyEntry(val ip: String, val banned: Boolean)
enum class Reputation { CLEAN, BANNED, UNKNOWN }

/**
 * Sticky Session Manager: every app gets ONE proxy IP, saved in SharedPreferences.
 * It only changes when the user resets it or edits the group in the app picker.
 * NOTE: assign/reset do network calls -> call them off the main thread.
 */
class StickyRouter(ctx: Context) {

    companion object {
        /** Apps that get an IP automatically on first launch. */
        val TRACKED_APPS = listOf(
            "com.whatsapp", "com.whatsapp.w4b", "com.zhiliaoapp.musically",
            "com.instagram.android", "org.telegram.messenger"
        )
        /** Apps shown in the app picker. */
        val PICKABLE_APPS = TRACKED_APPS + listOf("com.android.chrome", "org.mozilla.firefox")

        /** Optional free ipinfo.io token (https://ipinfo.io/signup). Empty = anonymous, rate-limited. */
        const val IPINFO_TOKEN = ""

        /** Bumped on every change so screens can refresh. */
        val version = MutableStateFlow(0)

        private val http = OkHttpClient.Builder().callTimeout(6, TimeUnit.SECONDS).build()
    }

    private val prefs = ctx.getSharedPreferences("sticky_ips", Context.MODE_PRIVATE)
    private val appPrefs = ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE)

    fun get(pkg: String): StickyEntry? =
        prefs.getString("ip_$pkg", null)?.let { StickyEntry(it, prefs.getBoolean("banned_$pkg", false)) }

    fun serverFor(pkg: String): ProxyServer? =
        get(pkg)?.let { e -> SmartRouter.SERVERS.firstOrNull { it.host == e.ip } }

    /** Gives a tracked app an IP if it has none (or its server was deleted). */
    fun ensureAssigned(pkg: String) {
        if (isDirect(pkg)) return // user chose "Direct connection" for this app
        val e = get(pkg)
        if (e == null || SmartRouter.SERVERS.none { it.host == e.ip }) assign(pkg, exclude = null)
    }

    fun resetIp(pkg: String) { assign(pkg, exclude = get(pkg)?.ip) }

    fun markBanned(pkg: String) { prefs.edit().putBoolean("banned_$pkg", true).apply(); bump() }

    /** Picker: put this app on a specific IP. */
    fun assignTo(pkg: String, ip: String) = save(pkg, ip, false)

    /** Route Rules: this app stays outside the VPN (direct connection). */
    fun setDirect(pkg: String) {
        prefs.edit().remove("ip_$pkg").remove("banned_$pkg").putBoolean("direct_$pkg", true).apply(); bump()
    }

    fun isDirect(pkg: String): Boolean = prefs.getBoolean("direct_$pkg", false)

    fun unassign(pkg: String) {
        prefs.edit().remove("ip_$pkg").remove("banned_$pkg").apply(); bump()
    }

    /** Picker: app was unchecked -> move it to another IP if one exists, else remove it. */
    fun moveAway(pkg: String, fromIp: String) {
        if (pkg in TRACKED_APPS && SmartRouter.SERVERS.any { it.host != fromIp }) assign(pkg, exclude = fromIp)
        else unassign(pkg)
    }

    private fun assign(pkg: String, exclude: String?) {
        if (SmartRouter.SERVERS.isEmpty()) return
        // Prefer the least-used server so apps get different IPs where possible
        val usage = PICKABLE_APPS.mapNotNull { get(it)?.ip }.groupingBy { it }.eachCount()
        val candidates = SmartRouter.SERVERS.filter { it.host != exclude }
            .ifEmpty { SmartRouter.SERVERS }
            .sortedBy { usage[it.host] ?: 0 }
        for (s in candidates) {
            // Health check BEFORE assigning; auto-skip banned IPs
            if (checkIpReputation(s.host) != Reputation.BANNED) { save(pkg, s.host, false); return }
        }
        save(pkg, candidates.first().host, true) // everything flagged: keep one, show "Banned"
    }

    private fun save(pkg: String, ip: String, banned: Boolean) {
        prefs.edit().putString("ip_$pkg", ip).putBoolean("banned_$pkg", banned).remove("direct_$pkg").apply(); bump()
    }

    private fun bump() { version.value = version.value + 1 }

    /**
     * IP Health Check via ipinfo.io.
     * Honest limit: the FREE ipinfo API has no blacklist data. We flag an IP only when
     * ipinfo reports it as a Tor exit (needs a token/paid plan for the privacy block).
     * Private/test ranges and network errors return UNKNOWN (treated as usable).
     */
    fun checkIpReputation(ip: String): Reputation = if (appPrefs.getBoolean("local_only", false)) Reputation.UNKNOWN else try {
        val url = "https://ipinfo.io/$ip/json" + if (IPINFO_TOKEN.isNotEmpty()) "?token=$IPINFO_TOKEN" else ""
        http.newCall(Request.Builder().url(url).build()).execute().use { resp ->
            if (!resp.isSuccessful) Reputation.UNKNOWN
            else {
                val json = JSONObject(resp.body?.string() ?: "{}")
                when {
                    json.optBoolean("bogon", false) -> Reputation.UNKNOWN
                    json.optJSONObject("privacy")?.optBoolean("tor", false) == true -> Reputation.BANNED
                    else -> Reputation.CLEAN
                }
            }
        }
    } catch (e: Exception) {
        Reputation.UNKNOWN
    }
}
