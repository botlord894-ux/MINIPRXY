package com.omniproxy.app

/** Transport encryption is reported only when the active upstream can authoritatively prove it. */
enum class TransportSecurityStatus {
    VERIFIED_TLS_13,
    VERIFIED_TLS_OTHER,
    ENCRYPTION_UNKNOWN,
    ENCRYPTION_NOT_VERIFIED,
    NOT_APPLICABLE
}

data class TransportSecurityInfo(
    val status: TransportSecurityStatus,
    val protocol: String? = null,
    val detail: String
) {
    val title: String get() = when (status) {
        TransportSecurityStatus.VERIFIED_TLS_13 -> "TLS 1.3 verified"
        TransportSecurityStatus.VERIFIED_TLS_OTHER -> "TLS verified"
        TransportSecurityStatus.ENCRYPTION_UNKNOWN -> "Encryption status unknown"
        TransportSecurityStatus.ENCRYPTION_NOT_VERIFIED -> "Encryption not verified"
        TransportSecurityStatus.NOT_APPLICABLE -> "Not applicable"
    }

    companion object {
        /** Current SOCKS5/HTTP upstreams do not expose a negotiated encrypted transport to this app. */
        fun forCurrentProxy(): TransportSecurityInfo = TransportSecurityInfo(
            status = TransportSecurityStatus.ENCRYPTION_UNKNOWN,
            protocol = null,
            detail = "The current proxy transport exposes no verified TLS handshake metadata. HTTPS to websites is separate from phone-to-proxy transport encryption."
        )
    }
}
