package com.omniproxy.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class ImportPlan(
    val servers: List<ProxyServer>,            // all valid servers in the file
    val newServers: List<ProxyServer>,         // the ones you don't have yet
    val settings: Map<String, Triple<Boolean, String, String>>,  // key -> (lock, failover, backups)
    val assignments: Map<String, String>       // package -> "host:port"
)

/** Backup and restore. Passwords and usernames are never exported. */
object ConfigIO {

    fun export(ctx: Context): String {
        val router = StickyRouter(ctx)
        val servers = ServerStore.list()
        val root = JSONObject().put("app", "OmniProxy").put("format", 1)
        val sArr = JSONArray()
        val prof = JSONObject()
        servers.forEach { s ->
            sArr.put(JSONObject().put("name", s.name).put("host", s.host).put("port", s.port)
                .put("type", s.type.name).put("country", s.country).put("udp", s.udp).put("compression", s.compression))
            val p = ProfileStore.get(s)
            prof.put("${s.host}:${s.port}", JSONObject().put("lock", p.lock).put("failover", p.failover).put("backups", p.backups))
        }
        val assign = JSONObject()
        StickyRouter.PICKABLE_APPS.forEach { pkg ->
            val ip = router.get(pkg)?.ip ?: return@forEach
            servers.firstOrNull { it.host == ip }?.let { assign.put(pkg, "${it.host}:${it.port}") }
        }
        return root.put("servers", sArr).put("profiles", prof).put("assignments", assign).toString(2)
    }

    /** Validates a file. Throws IllegalArgumentException with a readable message when it is not usable. */
    fun parse(text: String): ImportPlan {
        if (text.length > 1_000_000) throw IllegalArgumentException("File is too large.")
        val root = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("This is not a valid backup file.") }
        if (root.optString("app") != "OmniProxy") throw IllegalArgumentException("This file was not made by OmniProxy.")
        val arr = root.optJSONArray("servers") ?: throw IllegalArgumentException("No servers found in the file.")
        if (arr.length() > 100) throw IllegalArgumentException("Too many servers (max 100).")
        val list = ArrayList<ProxyServer>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val host = o.optString("host").trim()
            val port = o.optInt("port", -1)
            val type = try { ProxyType.valueOf(o.optString("type")) } catch (e: Exception) { throw IllegalArgumentException("Server ${i + 1}: unknown protocol.") }
            if (host.isEmpty() || host.length > 253 || host.any { it.isWhitespace() }) throw IllegalArgumentException("Server ${i + 1}: invalid host.")
            if (port !in 1..65535) throw IllegalArgumentException("Server ${i + 1}: invalid port.")
            val cc = o.optString("country").trim().uppercase()
            if (cc.isNotEmpty() && !(cc.length == 2 && cc.all { it.isLetter() })) throw IllegalArgumentException("Server ${i + 1}: invalid country.")
            list.add(ProxyServer(name = o.optString("name").take(60).ifBlank { host }, host = host, port = port, type = type,
                country = cc, compression = o.optBoolean("compression"), udp = o.optBoolean("udp")))
        }
        val have = ServerStore.list().map { "${it.host}:${it.port}" }.toSet()
        val settings = HashMap<String, Triple<Boolean, String, String>>()
        root.optJSONObject("profiles")?.let { p ->
            p.keys().forEach { k ->
                val o = p.getJSONObject(k)
                val fo = o.optString("failover", "OFF").let { if (it in listOf("OFF", "STRICT", "AUTO")) it else "OFF" }
                settings[k] = Triple(o.optBoolean("lock"), fo, o.optString("backups"))
            }
        }
        val assignments = HashMap<String, String>()
        root.optJSONObject("assignments")?.let { a ->
            a.keys().forEach { pkg -> if (pkg in StickyRouter.PICKABLE_APPS) assignments[pkg] = a.getString(pkg) }
        }
        return ImportPlan(list, list.filter { "${it.host}:${it.port}" !in have }, settings, assignments)
    }

    /** Applies the plan. It adds servers and settings only; it never connects. */
    fun apply(ctx: Context, plan: ImportPlan) {
        plan.newServers.forEach { ServerStore.add(it) }
        val all = ServerStore.list()
        plan.settings.forEach { (k, v) ->
            val s = all.firstOrNull { "${it.host}:${it.port}" == k } ?: return@forEach
            ProfileStore.setFailover(s, v.second); ProfileStore.setBackups(s, v.third.split(",").filter { it.isNotBlank() })
            if (v.first) ProfileStore.setLock(s, true)
        }
        val router = StickyRouter(ctx)
        plan.assignments.forEach { (pkg, k) ->
            all.firstOrNull { "${it.host}:${it.port}" == k }?.let { router.assignTo(pkg, it.host) }
        }
    }
}
