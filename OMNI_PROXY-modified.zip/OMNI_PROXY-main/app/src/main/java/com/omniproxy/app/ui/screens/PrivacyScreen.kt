package com.omniproxy.app.ui.screens

import android.content.Context
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.DevLog
import com.omniproxy.app.HistoryStore
import com.omniproxy.app.OmniVpnService
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyType
import com.omniproxy.app.TransportSecurityInfo
import com.omniproxy.app.TransportSecurityStatus
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

private enum class L { YES, NO, UNKNOWN }

/** Privacy status: separates what is enabled, what was tested, and what nobody has verified. */
@Composable
fun PrivacyScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE) }
    val currentIp by OmniVpnService.currentIp.collectAsState()
    val server = SmartRouter.SERVERS.firstOrNull { it.host == currentIp }
    val profile = server?.let { ProfileStore.get(it) }
    val localOnly = prefs.getBoolean("local_only", false)
    val engine = DevLog.engine

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Privacy Status", "What is verified, and what is not.")
        Spacer(Modifier.height(16.dp))
        OmniCard(Modifier.fillMaxWidth()) {
            Column {
                val transport = TransportSecurityInfo.forCurrentProxy()
                Row3("Transport Security · ${transport.title}",
                    if (transport.status == TransportSecurityStatus.VERIFIED_TLS_13 || transport.status == TransportSecurityStatus.VERIFIED_TLS_OTHER) L.YES else L.UNKNOWN,
                    transport.detail)
                Hairline()
                Row3("Traffic encrypted to the proxy", L.NO,
                    "The current SOCKS5 and HTTP upstream configurations do not establish an encrypted phone-to-proxy transport. HTTPS traffic inside them remains separately encrypted end to end.")
                Hairline()
                Row3("Exit IP checked", if (profile != null && profile.lastCheckedAt > 0) L.YES else L.NO,
                    if (profile != null && profile.lastCheckedAt > 0) "Read through ${server?.name} as ${profile.lastExitIp}." else "Not checked for the active server. Run Connection Truth.")
                Hairline()
                Row3("DNS configuration", if (currentIp == null) L.UNKNOWN else L.YES,
                    if (currentIp == null) "Not connected." else if (engine.contains("mapdns")) "Names are resolved by the proxy." else "Using the DNS servers listed in the Developer panel.")
                Hairline()
                Row3("App routing verified", L.NO, "Android places the chosen apps in the tunnel. OmniProxy does not test each app.")
                Hairline()
                Row3("Connection history stored locally", if (HistoryStore.enabled()) L.YES else L.NO,
                    if (HistoryStore.enabled()) "Events only, on this device. You can delete or turn it off." else "History is off.")
                Hairline()
                Row3("Data uploaded by OmniProxy", L.NO, "None. There is no account, analytics or cloud sync.")
                Hairline()
                Row3("Third parties contacted", if (localOnly) L.NO else L.YES,
                    if (localOnly) "ipinfo.io is still asked for your exit IP through the proxy. Reputation lookups are off (Local-Only Mode)."
                    else "ipinfo.io (exit IP check and a reputation lookup) and speed.cloudflare.com (only if you run the speed test).")
                Hairline()
                Row3("Proxy provider can see metadata", L.YES, "Your proxy server sees which hosts you connect to. Local storage does not change that.")
            }
        }
        Spacer(Modifier.height(14.dp))
        InfoBanner("OmniProxy makes no claims of anonymity. A stable IP does not guarantee an account avoids security checks.", accent = Amber)
        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun Row3(title: String, level: L, detail: String) {
    Column(Modifier.fillMaxWidth().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            StatusDot(when (level) { L.YES -> Green; L.NO -> Amber; L.UNKNOWN -> TextSecondary })
            Spacer(Modifier.width(10.dp))
            Text(title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Text(when (level) { L.YES -> "Yes"; L.NO -> "No / not verified"; L.UNKNOWN -> "Unknown" }, color = TextSecondary, fontSize = 12.sp)
        }
        Spacer(Modifier.height(4.dp))
        Text(detail, color = TextSecondary, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(start = 19.dp))
    }
}
