package com.omniproxy.app

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope

enum class Goal(val label: String) {
    LATENCY("Lowest latency"), STABILITY("Most stable"), BROWSING("General browsing"),
    GAMING("Best for gaming"), DATA("Lowest data usage"), COUNTRY("Specific country")
}

data class Measurement(val server: ProxyServer, val ok: Int, val total: Int, val avgMs: Int?, val jitterMs: Int?)
data class Recommendation(val best: Measurement, val reason: String, val caveat: String?, val all: List<Measurement>)

/** Recommends a server, but only from servers it just tested. */
object RouteAdvisor {

    /** Pings each server [samples] times (all servers in parallel). */
    suspend fun measure(servers: List<ProxyServer>, samples: Int = 3): List<Measurement> = coroutineScope {
        servers.map { s ->
            async(Dispatchers.IO) {
                val r = (1..samples).map { SmartRouter.pingMs(s) }.filter { it >= 0 }
                Measurement(
                    server = s, ok = r.size, total = samples,
                    avgMs = if (r.isEmpty()) null else r.average().toInt(),
                    jitterMs = if (r.size >= 2) r.max() - r.min() else null
                )
            }
        }.awaitAll()
    }

    /** [stabilityFirst] puts reliability ahead of speed when choosing between servers. */
    fun recommend(goal: Goal, country: String?, all: List<Measurement>, stabilityFirst: Boolean = false): Recommendation? {
        val up = all.filter { it.ok > 0 && it.avgMs != null }
        if (up.isEmpty()) return null
        val stable = compareByDescending<Measurement> { it.ok }
            .thenBy { it.jitterMs ?: Int.MAX_VALUE }.thenBy { it.avgMs ?: Int.MAX_VALUE }
        val fast = compareBy<Measurement> { it.avgMs ?: Int.MAX_VALUE }
        val order = if (stabilityFirst) stable else fast
        fun best(l: List<Measurement>) = l.sortedWith(order).firstOrNull()
        fun ms(m: Measurement) = "${m.avgMs} ms average, ${m.ok}/${m.total} tests answered"
        val prefNote = if (stabilityFirst) "Reliability was ranked above speed." else null
        return when (goal) {
            Goal.LATENCY -> best(up)!!.let { Recommendation(it, "Best by ${if (stabilityFirst) "reliability, then latency" else "lowest latency"}: ${ms(it)}.", prefNote, all) }
            Goal.STABILITY -> up.sortedWith(stable).first().let {
                Recommendation(it, "Answered ${it.ok}/${it.total} tests with ${it.jitterMs ?: 0} ms jitter.",
                    "Based on a few quick tests only. Real stability needs days of history.", all)
            }
            Goal.BROWSING -> up.minByOrNull { (it.avgMs ?: 0) + 2 * (it.jitterMs ?: 0) + 300 * (it.total - it.ok) }!!.let {
                Recommendation(it, "Best balance of speed and reliability: ${ms(it)}, ${it.jitterMs ?: 0} ms jitter.", prefNote, all)
            }
            Goal.GAMING -> {
                val udp = up.filter { it.server.udp }
                val pick = best(udp.ifEmpty { up })!!
                Recommendation(pick, "Best among ${if (udp.isNotEmpty()) "UDP-capable servers" else "reachable servers"}: ${ms(pick)}.",
                    if (udp.isEmpty()) "None of your servers is marked UDP-capable, and many games need UDP." else null, all)
            }
            Goal.DATA -> {
                val comp = up.filter { it.server.compression }
                val pick = best(comp.ifEmpty { up })!!
                Recommendation(pick, if (comp.isNotEmpty()) "Compression proxy, best result: ${ms(pick)}." else "Best reachable server: ${ms(pick)}.",
                    if (comp.isEmpty()) "No compression proxy is set up. A plain proxy does not reduce data use." else
                        "Savings depend on what the server really compresses. HTTPS traffic usually can't be.", all)
            }
            Goal.COUNTRY -> {
                val c = up.filter { it.server.country.equals(country, true) }
                if (c.isEmpty()) null
                else best(c)!!.let { Recommendation(it, "Best reachable server in ${country?.uppercase()}: ${ms(it)}.", prefNote, all) }
            }
        }
    }
}
