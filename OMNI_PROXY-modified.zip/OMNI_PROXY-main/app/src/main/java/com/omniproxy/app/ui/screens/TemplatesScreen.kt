package com.omniproxy.app.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.StarBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.Goal
import com.omniproxy.app.HistoryStore
import com.omniproxy.app.ProfileStore
import com.omniproxy.app.ProxyServer
import com.omniproxy.app.RouteAdvisor
import com.omniproxy.app.ServerStore
import com.omniproxy.app.SmartRouter
import com.omniproxy.app.StickyRouter
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*
import kotlinx.coroutines.launch

/** Templates only set preferences. They don't promise a service will work or that an account appears in a place. */
@Composable
fun TemplatesScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE) }
    val scope = rememberCoroutineScope()
    val router = remember { StickyRouter(ctx) }
    val sver by ServerStore.version.collectAsState()
    val servers = remember(sver) { SmartRouter.SERVERS }
    var picker by remember { mutableStateOf<String?>(null) }
    var travel by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var favs by remember { mutableStateOf(prefs.getStringSet("favorites", emptySet())?.toSet() ?: emptySet()) }
    var pings by remember { mutableStateOf<Map<String, Int?>>(emptyMap()) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = Color.White) }
        ScreenHeader("Profile Templates", "Quick setups. You can change everything later.")
        message?.let { Spacer(Modifier.height(12.dp)); InfoBanner(it) }
        Spacer(Modifier.height(14.dp))

        Template("Social Media", "Puts WhatsApp, Instagram, TikTok, Telegram (and Business) on one profile, turns IP Lock on and keeps history on.",
            "Choose a profile") { picker = "social" }
        Template("Gaming", "Home opens on Gaming mode and OmniProxy tests which server suits games best right now.",
            if (busy) "Testing…" else "Apply") {
            if (!busy) {
                busy = true
                prefs.edit().putString("default_mode", "GAMING").apply()
                scope.launch {
                    val rec = RouteAdvisor.recommend(Goal.GAMING, null, RouteAdvisor.measure(servers))
                    message = "Gaming applied. " + (rec?.let { "Best measured now: ${it.best.server.name}. ${it.reason} ${it.caveat ?: ""}" }
                        ?: "No server answered, so nothing is recommended.")
                    busy = false
                }
            }
        }
        Template("Private Browsing", "Routes Chrome and Firefox through the profile you choose, and turns the kill switch on. Connect from Home. Streaming, Gaming and Data Saver will use that server.",
            "Choose a profile") { picker = "private" }
        if (prefs.getString("preferred_server", null) != null) {
            TextButton(onClick = { prefs.edit().remove("preferred_server").apply(); message = "Preferred server removed. Modes pick servers automatically again." }) {
                Text("Remove preferred server", color = PurpleLight)
            }
        }
        Template("Travel", "Star the locations you use most. Starred servers are listed first, and you can test them all.",
            "Choose locations") { travel = true }
        Spacer(Modifier.height(16.dp))
        InfoBanner("Templates set preferences. They do not promise that a service will work or that an account will appear to be in a particular location.", accent = Amber)
        Spacer(Modifier.height(24.dp))
    }

    picker?.let { which ->
        AlertDialog(
            onDismissRequest = { picker = null }, containerColor = CardBg,
            title = { Text("Choose a profile", color = Color.White) },
            text = {
                if (servers.isEmpty()) Text("Add a server first.", color = TextSecondary)
                else Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    servers.forEach { s ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1830))
                            .clickable { applyTemplate(which, s, prefs, router); picker = null
                                message = if (which == "social") "Social Media applied to ${s.name}. IP Lock is on and your chat apps now share this IP. Start it from Sticky Apps."
                                else "Private Browsing applied. Chrome and Firefox use ${s.name}. Connect from Home." }
                            .padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            FlagBadge(s.country, 34.dp); Spacer(Modifier.width(10.dp))
                            Column {
                                Text(s.name, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text("${s.host}:${s.port} · ${s.type.name}" + if (which == "social" && s.type.name != "SOCKS5") " (needs SOCKS5)" else "",
                                    color = TextSecondary, fontSize = 12.sp)
                            }
                        }
                    }
                }
            },
            confirmButton = {}, dismissButton = { TextButton(onClick = { picker = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }

    if (travel) AlertDialog(
        onDismissRequest = { travel = false }, containerColor = CardBg,
        title = { Text("Preferred locations", color = Color.White) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (servers.isEmpty()) Text("Add a server first.", color = TextSecondary)
                servers.sortedBy { it.country }.forEach { s ->
                    val k = "${s.host}:${s.port}"
                    val on = k in favs
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        FlagBadge(s.country, 30.dp); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.name, color = Color.White, fontSize = 14.sp)
                            Text(if (pings.containsKey(k)) (pings[k]?.takeIf { it >= 0 }?.let { "$it ms" } ?: "offline") else s.country.uppercase(),
                                color = TextSecondary, fontSize = 11.sp)
                        }
                        IconButton(onClick = {
                            favs = if (on) favs - k else favs + k
                            prefs.edit().putStringSet("favorites", favs).apply()
                        }) { Icon(if (on) Icons.Filled.Star else Icons.Filled.StarBorder, null, tint = if (on) Amber else TextSecondary) }
                    }
                }
                TextButton(onClick = {
                    scope.launch { pings = RouteAdvisor.measure(servers, 1).associate { "${it.server.host}:${it.server.port}" to (it.avgMs ?: -1) } }
                }) { Text("Test all", color = PurpleLight) }
            }
        },
        confirmButton = { TextButton(onClick = { travel = false; message = "Travel locations saved. Starred servers are listed first." }) { Text("Done", color = PurpleLight) } }
    )
}

private fun applyTemplate(which: String, s: ProxyServer, prefs: android.content.SharedPreferences, router: StickyRouter) {
    if (which == "social") {
        StickyRouter.TRACKED_APPS.forEach { router.assignTo(it, s.host) }
        ProfileStore.setLock(s, true)
        HistoryStore.setEnabled(true)
    } else {
        prefs.edit()
            .putStringSet("proxy_apps", setOf("com.android.chrome", "org.mozilla.firefox"))
            .putBoolean("kill_switch", true)
            .putString("preferred_server", "${s.host}:${s.port}").apply()
    }
}

@Composable
private fun Template(title: String, desc: String, button: String, onClick: () -> Unit) {
    OmniCard(Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
            Text(desc, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
            Button(onClick = onClick, colors = ButtonDefaults.buttonColors(containerColor = Purple)) { Text(button) }
        }
    }
}
