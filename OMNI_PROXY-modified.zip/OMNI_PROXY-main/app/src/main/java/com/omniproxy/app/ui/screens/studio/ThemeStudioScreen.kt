package com.omniproxy.app.ui.screens.studio

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.appearance.*
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

/**
 * Theme Studio. Everything is edited on a DRAFT shown in the live preview. Apply makes it the active look
 * and saves it; Cancel (or Back) throws the draft away. Saved custom themes are the one thing stored immediately.
 */
@Composable
fun ThemeStudioScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    var draft by remember { mutableStateOf(AppearanceStore.current) }
    var tab by rememberSaveable { mutableStateOf(0) }
    var savePreset by remember { mutableStateOf(false) }
    var applied by remember { mutableStateOf(false) }
    val applied0 = AppearanceStore.current
    val dirty = draft != applied0
    val upd: ((Appearance) -> Appearance) -> Unit = { f -> draft = f(draft); applied = false }

    fun cancel() {
        BackgroundImages.cleanup(ctx, applied0.bg.imageFile) // drop photos imported but never applied
        onBack()
    }
    BackHandler { cancel() }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { cancel() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back", tint = TextPrimary) }
            Column(Modifier.weight(1f)) {
                Text("Theme Studio", color = TextPrimary, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text(if (applied) "Applied and saved" else if (dirty) "Unsaved changes: preview only" else "Make it yours", color = if (dirty && !applied) Amber else TextSecondary, fontSize = 12.sp)
            }
        }
        Column(Modifier.padding(horizontal = 16.dp)) { StudioPreview(draft) }
        Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 10.dp)) {
            listOf("Theme", "Background", "Liquid Button", "Buttons", "Cards & Nav").forEachIndexed { i, t -> Chip(t, tab == i) { tab = i } }
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)) {
            when (tab) {
                0 -> ThemeTab(draft, upd) { savePreset = true }
                1 -> BackgroundTab(draft, upd)
                2 -> LiquidTab(draft, upd)
                3 -> ButtonsTab(draft, upd)
                else -> LayoutTab(draft, upd)
            }
            Spacer(Modifier.height(16.dp))
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
            OmniOutlinedButton(onClick = { cancel() }, modifier = Modifier.weight(1f)) { Text("Cancel") }
            OmniOutlinedButton(onClick = {
                // Reset only the section you are looking at
                upd { a ->
                    when (tab) {
                        0 -> { val e = AppearanceStore.allThemes(a).firstOrNull { it.id == a.themeId }; if (e != null) a.copy(palette = e.palette) else AppearanceStore.withTheme(a, Presets.themes.first()) }
                        1 -> a.copy(bg = BackgroundSpec())
                        2 -> a.copy(liquid = LiquidStyle())
                        3 -> a.copy(button = ButtonStyle())
                        else -> a.copy(card = CardStyle(), nav = NavStyle(), highContrast = false, reduceMotion = false)
                    }
                }
            }, modifier = Modifier.weight(1f)) { Text("Reset") }
            OmniOutlinedButton(onClick = { savePreset = true }, modifier = Modifier.weight(1.2f)) { Text("Save preset") }
            OmniButton(onClick = {
                val keepThemes = draft.customThemes
                // editing one of your own themes updates it; built-in themes are never changed
                val themes = keepThemes.map { if (it.id == draft.themeId) it.copy(palette = draft.palette) else it }
                val finalA = AppearanceStore.sanitize(draft.copy(customThemes = themes))
                runCatching { AppearanceStore.apply(finalA) }.onSuccess {
                BackgroundImages.cleanup(ctx, finalA.bg.imageFile)
                draft = AppearanceStore.current; applied = true
                }.onFailure { /* Keep the editor open; the saved appearance is unchanged on validation failure. */ }
            }, modifier = Modifier.weight(1f)) { Text("Apply") }
        }
    }

    if (savePreset) NameDialog("Name your theme", "My theme", { savePreset = false }) { name ->
        savePreset = false
        val entry = ThemeEntry("user_${System.currentTimeMillis()}", name, draft.palette, false)
        val list = draft.customThemes + entry
        upd { a -> a.copy(customThemes = list, themeId = entry.id) }
    }
}
