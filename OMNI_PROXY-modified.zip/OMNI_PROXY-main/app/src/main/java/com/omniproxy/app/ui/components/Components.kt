package com.omniproxy.app.ui.components

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.graphics.drawable.toBitmap
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ui.theme.*

// ---------- Helpers ----------

private val FALLBACK_NAMES = mapOf(
    "com.whatsapp" to "WhatsApp", "com.whatsapp.w4b" to "WhatsApp Business",
    "com.zhiliaoapp.musically" to "TikTok", "com.instagram.android" to "Instagram",
    "org.telegram.messenger" to "Telegram", "com.android.chrome" to "Chrome",
    "org.mozilla.firefox" to "Firefox"
)

/** Installed app name, or a friendly fallback if the app isn't installed. */
fun appName(ctx: Context, pkg: String): String = try {
    val pm = ctx.packageManager
    pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString()
} catch (e: Exception) { FALLBACK_NAMES[pkg] ?: pkg.substringAfterLast('.') }

private fun brandColor(pkg: String): Color = when (pkg) {
    "com.whatsapp", "com.whatsapp.w4b" -> Color(0xFF25D366)
    "com.zhiliaoapp.musically" -> Color(0xFF111111)
    "com.instagram.android" -> Color(0xFFE1306C)
    "org.telegram.messenger" -> Color(0xFF2AABEE)
    "com.android.chrome" -> Color(0xFF4285F4)
    "org.mozilla.firefox" -> Color(0xFFFF7139)
    else -> Purple
}

/** "US" -> flag emoji. Returns a globe for anything that isn't 2 letters. */
fun flagEmoji(cc: String): String {
    if (cc.length != 2 || !cc.all { it.isLetter() }) return "\uD83C\uDF10"
    val base = 0x1F1E6
    fun one(c: Char) = String(Character.toChars(base + (c.uppercaseChar() - 'A')))
    return one(cc[0]) + one(cc[1])
}

// ---------- Cards and badges ----------

/** Rounded 20dp dark card with a subtle border. Pass onClick to make it tappable. */
@Composable
fun OmniCard(
    modifier: Modifier = Modifier,
    borderColor: Color = Border,
    onClick: (() -> Unit)? = null,
    content: @Composable ColumnScope.() -> Unit
) {
    val cs = AppearanceStore.current.card
    val shape = RoundedCornerShape(cs.radius.dp)
    val colors = CardDefaults.cardColors(containerColor = CardBg.copy(alpha = AppearanceStore.resolved.cardAlpha))
    val border = if (cs.borderWidth > 0f) BorderStroke(cs.borderWidth.dp, borderColor) else null
    val elevation = CardDefaults.cardElevation(defaultElevation = cs.shadow.dp)
    if (onClick != null) Card(onClick = onClick, modifier = modifier, shape = shape, colors = colors, border = border, elevation = elevation, content = content)
    else Card(modifier = modifier, shape = shape, colors = colors, border = border, elevation = elevation, content = content)
}

@Composable
fun Hairline() {
    androidx.compose.foundation.layout.Box(Modifier.fillMaxWidth().height(1.dp).background(Border))
}

/** Circle with a country flag. */
@Composable
fun FlagBadge(country: String, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(CircleShape).background(Surface2).border(1.dp, Border, CircleShape),
        contentAlignment = Alignment.Center) {
        Text(flagEmoji(country), fontSize = (size.value * 0.5f).sp)
    }
}

/** Rounded square with a vector icon. */
@Composable
fun IconBadge(icon: ImageVector, color: Color = PurpleLight, size: Dp = 44.dp) {
    Box(Modifier.size(size).clip(RoundedCornerShape(12.dp)).background(color.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center) {
        Icon(icon, null, tint = color, modifier = Modifier.size(size * 0.5f))
    }
}

/** Real app icon if installed, otherwise a coloured tile with the first letter. */
@Composable
fun AppIcon(pkg: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        try { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() } catch (e: Exception) { null }
    }
    val shape = RoundedCornerShape(size * 0.22f)
    if (bmp != null) Image(bmp, null, Modifier.size(size).clip(shape))
    else Box(Modifier.size(size).clip(shape).background(brandColor(pkg)), contentAlignment = Alignment.Center) {
        Text(appName(ctx, pkg).take(1).uppercase(), color = TextPrimary, fontWeight = FontWeight.Bold,
            fontSize = (size.value * 0.45f).sp)
    }
}

@Composable
fun ProtoBadge(text: String) {
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Purple.copy(alpha = 0.18f))
        .border(1.dp, Purple.copy(alpha = 0.7f), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 3.dp)) {
        Text(text, color = PurpleLight, fontSize = 11.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
fun StatusDot(color: Color) {
    Box(Modifier.size(9.dp).clip(CircleShape).background(color))
}

// ---------- Banners, buttons, inputs ----------

@Composable
fun InfoBanner(text: String, accent: Color = Cyan, icon: ImageVector = Icons.Filled.Info) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(accent.copy(alpha = 0.08f))
            .border(1.dp, accent.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = accent, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(12.dp))
        Text(text, color = TextSecondary, fontSize = 13.sp, lineHeight = 18.sp)
    }
}

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    OmniButton(onClick = onClick, modifier = modifier.fillMaxWidth()) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
    }
}

@Composable
fun OmniTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    keyboardType: KeyboardType = KeyboardType.Text,
    password: Boolean = false,
    icon: ImageVector? = null
) {
    val leading: (@Composable () -> Unit)? = if (icon != null) { { Icon(icon, null, tint = TextSecondary) } } else null
    OutlinedTextField(
        value = value, onValueChange = onValueChange, label = { Text(label) },
        singleLine = true, modifier = modifier, shape = RoundedCornerShape(14.dp),
        leadingIcon = leading,
        keyboardOptions = KeyboardOptions(keyboardType = keyboardType),
        visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Purple, unfocusedBorderColor = Border,
            focusedLabelColor = PurpleLight, unfocusedLabelColor = TextSecondary,
            cursorColor = Purple, focusedTextColor = TextPrimary, unfocusedTextColor = TextPrimary
        )
    )
}

@Composable
fun ScreenHeader(title: String, subtitle: String) {
    Column {
        Text(title, color = TextPrimary, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(4.dp))
        Text(subtitle, color = TextSecondary, fontSize = 15.sp, textAlign = TextAlign.Start)
    }
}

// ---------- Logo: globe with layered orbital rings ----------

@Composable
fun OmniLogo(logoSize: Dp = 40.dp) {
    Canvas(Modifier.size(logoSize)) {
        val c = center
        val r = size.minDimension * 0.30f
        drawCircle(
            brush = Brush.verticalGradient(
                listOf(PurpleLight, Purple, Color(0xFF2B7BFF), Green),
                startY = c.y - r, endY = c.y + r
            ),
            radius = r, center = c
        )
        val ringW = size.minDimension * 0.06f
        rotate(degrees = -24f, pivot = c) {
            drawOval(
                color = Green,
                topLeft = Offset(c.x - size.width * 0.46f, c.y - size.height * 0.14f),
                size = Size(size.width * 0.92f, size.height * 0.28f),
                style = Stroke(width = ringW)
            )
        }
        rotate(degrees = 24f, pivot = c) {
            drawOval(
                color = PurpleLight,
                topLeft = Offset(c.x - size.width * 0.46f, c.y - size.height * 0.14f),
                size = Size(size.width * 0.92f, size.height * 0.28f),
                style = Stroke(width = ringW * 0.8f)
            )
        }
    }
}

/** "3 min ago", "2 days ago", or "never". */
fun timeAgo(t: Long): String {
    if (t <= 0) return "never"
    val d = (System.currentTimeMillis() - t) / 1000
    return when {
        d < 60 -> "just now"
        d < 3600 -> "${d / 60} min ago"
        d < 86400 -> "${d / 3600} h ago"
        else -> "${d / 86400} days ago"
    }
}
