package com.omniproxy.app

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Real counters only: bytes through the tunnel, session time, interruptions, reconnects. Stored on this device. */
object UsageStore {
    private var prefs: SharedPreferences? = null

    fun init(ctx: Context) {
        if (prefs == null) prefs = ctx.applicationContext.getSharedPreferences("usage", Context.MODE_PRIVATE)
    }

    private fun month() = SimpleDateFormat("yyyyMM", Locale.US).format(Date())
    private fun day() = SimpleDateFormat("yyyyMMdd", Locale.US).format(Date())

    @Synchronized
    private fun addLong(key: String, v: Long) {
        val p = prefs ?: return
        p.edit().putLong(key, p.getLong(key, 0) + v).apply()
    }

    fun addBytes(serverKey: String, b: Long) {
        if (b <= 0) return
        addLong("m:${month()}:$serverKey", b); addLong("d:${day()}:bytes", b)
    }
    fun addSeconds(s: Long) { if (s > 0) addLong("d:${day()}:secs", s) }
    fun addInterruption() = addLong("d:${day()}:int", 1)
    fun addReconnect() = addLong("d:${day()}:rec", 1)

    private fun get(key: String) = prefs?.getLong(key, 0) ?: 0L
    fun todayBytes() = get("d:${day()}:bytes")
    fun todaySeconds() = get("d:${day()}:secs")
    fun todayInterruptions() = get("d:${day()}:int")
    fun todayReconnects() = get("d:${day()}:rec")

    fun monthBytes(): Long {
        val pre = "m:${month()}:"
        return prefs?.all?.filter { it.key.startsWith(pre) }?.values?.sumOf { (it as? Long) ?: 0L } ?: 0L
    }

    /** (server key, bytes) with the most traffic this month. */
    fun topProfileMonth(): Pair<String, Long>? {
        val pre = "m:${month()}:"
        return prefs?.all?.filter { it.key.startsWith(pre) }
            ?.mapNotNull { e -> (e.value as? Long)?.let { e.key.removePrefix(pre) to it } }
            ?.maxByOrNull { it.second }
    }

    var budgetGb: Int
        get() = prefs?.getInt("budget_gb", 0) ?: 0
        set(v) { prefs?.edit()?.putInt("budget_gb", v)?.apply() }

    /** Percent of the monthly budget used, or null when no budget is set. */
    fun budgetPercent(): Int? {
        val gb = budgetGb
        return if (gb <= 0) null else (monthBytes() * 100 / (gb * 1073741824L)).toInt()
    }

    fun clear() { prefs?.edit()?.clear()?.apply() }
}
