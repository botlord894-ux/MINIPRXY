package com.omniproxy.app.ui.screens

import android.content.Context
import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.omniproxy.app.ConfigIO
import com.omniproxy.app.appearance.AppearanceStore
import com.omniproxy.app.ImportPlan
import com.omniproxy.app.ui.components.*
import com.omniproxy.app.ui.theme.*

@Composable
fun SettingsScreen(onNavigate: (String) -> Unit) {
    val ctx = LocalContext.current
    val prefs = remember { ctx.getSharedPreferences("omni_prefs", Context.MODE_PRIVATE) }
    var killSwitch by remember { mutableStateOf(prefs.getBoolean("kill_switch", true)) }
    var autoReconnect by remember { mutableStateOf(prefs.getBoolean("auto_reconnect", true)) }
    var localOnly by remember { mutableStateOf(prefs.getBoolean("local_only", false)) }
    var devMode by remember { mutableStateOf(prefs.getBoolean("dev_mode", false)) }
    var dialog by remember { mutableStateOf<String?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var plan by remember { mutableStateOf<ImportPlan?>(null) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) message = try {
            ctx.contentResolver.openOutputStream(uri)?.use { it.write(ConfigIO.export(ctx).toByteArray()) }
            "Backup saved. Passwords and usernames are not included."
        } catch (e: Exception) { "Could not save the backup." }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) try {
            val text = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            plan = ConfigIO.parse(text)
        } catch (e: Exception) { message = e.message ?: "Could not read that file." }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(12.dp))
        ScreenHeader("Settings", "Connection, privacy, tools and backup.")
        message?.let { Spacer(Modifier.height(12.dp)); InfoBanner(it) }
        Spacer(Modifier.height(18.dp))

        GroupTitle("PERSONALIZATION")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.Palette, "Theme Studio", "Themes, background, liquid button, buttons and cards",
                onClick = { onNavigate("studio") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.RestartAlt, "Reset personalization", "Back to Omni Purple (your saved themes stay)",
                onClick = { dialog = "resetlook" }) { Chevron() }
        }

        Spacer(Modifier.height(18.dp))
        GroupTitle("CONNECTION")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.PowerSettingsNew, "Auto-connect", "Coming soon") { SoonSwitch() }
            Hairline()
            SettingRow(Icons.Filled.Autorenew, "Reconnect automatically", "Re-establish the tunnel after a network change") {
                AppSwitch(autoReconnect) { autoReconnect = it; prefs.edit().putBoolean("auto_reconnect", it).apply() }
            }
            Hairline()
            SettingRow(Icons.Filled.Timer, "Connection timeout", "Coming soon") { Text("—", color = TextSecondary) }
        }

        Spacer(Modifier.height(18.dp))
        GroupTitle("PRIVACY")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.Dns, "DNS preferences", "Remote via proxy, or 1.1.1.1", onClick = { dialog = "dns" }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Shield, "Kill switch", "Block those apps if the proxy drops") {
                AppSwitch(killSwitch) { killSwitch = it; prefs.edit().putBoolean("kill_switch", it).apply() }
            }
            Hairline()
            SettingRow(Icons.Filled.CloudOff, "Local-Only Mode", "No optional third-party lookups (IP reputation)") {
                AppSwitch(localOnly) { localOnly = it; prefs.edit().putBoolean("local_only", it).apply() }
            }
            Hairline()
            SettingRow(Icons.Filled.LocationOn, "GPS spoofing", "Off, and stays off for safety") { SoonSwitch() }
            Hairline()
            SettingRow(Icons.Filled.VerifiedUser, "Privacy status", "What is verified and what is not", onClick = { onNavigate("privacy") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.History, "Connection history", "Events only, stored on this device", onClick = { onNavigate("history") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Lock, "Privacy information", "What this app does and doesn't do", onClick = { dialog = "privacy" }) { Chevron() }
        }

        Spacer(Modifier.height(18.dp))
        GroupTitle("TOOLS")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.AltRoute, "Route Rules", "Choose a profile or direct for each app", onClick = { onNavigate("rules") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.AccountTree, "Route Simulator", "Preview how your apps connect", onClick = { onNavigate("simulator") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.AutoAwesome, "Profile Templates", "Social, gaming, private browsing, travel", onClick = { onNavigate("templates") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Speed, "Quality Test", "Latency, loss, speed per server", onClick = { onNavigate("quality") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.DataUsage, "Data & Usage", "Real counters and a monthly budget", onClick = { onNavigate("data") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Code, "Developer Mode", "Logs, counters and a diagnostic report") {
                AppSwitch(devMode) { devMode = it; prefs.edit().putBoolean("dev_mode", it).apply() }
            }
            if (devMode) {
                Hairline()
                SettingRow(Icons.Filled.Terminal, "Developer panel", "Open", onClick = { onNavigate("dev") }) { Chevron() }
            }
        }

        Spacer(Modifier.height(18.dp))
        GroupTitle("BACKUP")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.Upload, "Export profiles", "Servers, rules and settings (no passwords)",
                onClick = { exportLauncher.launch("omniproxy-backup.json") }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Download, "Import profiles", "Checked before anything is saved",
                onClick = { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) }) { Chevron() }
        }

        Spacer(Modifier.height(18.dp))
        GroupTitle("APP")
        OmniCard(Modifier.fillMaxWidth()) {
            SettingRow(Icons.Filled.Palette, "Theme", "Change it in Theme Studio") { Text(AppearanceStore.current.themeName, color = TextSecondary) }
            Hairline()
            SettingRow(Icons.Filled.Notifications, "Notifications", "Open system notification settings",
                onClick = { openNotificationSettings(ctx) }) { Chevron() }
            Hairline()
            SettingRow(Icons.Filled.Info, "About OmniProxy", "Version 1.0.0", onClick = { dialog = "about" }) { Chevron() }
        }
        Spacer(Modifier.height(24.dp))
    }

    dialog?.takeIf { it != "resetlook" }?.let { d ->
        val (title, body) = when (d) {
            "dns" -> "DNS preferences" to
                "Servers with UDP relay: DNS goes to 1.1.1.1 (AdGuard in Streaming mode).\n\nServers without UDP: names are resolved by the proxy itself, so DNS never leaks from your phone."
            "privacy" -> "Privacy information" to
                "OmniProxy sends only the apps you choose through your own proxy server. Everything else stays direct. Your servers, profiles and history are stored only on this device, and the app uploads nothing. Your proxy provider can still see connection metadata.\n\nIt cannot guarantee an account won't be banned.\n\nUse 1 IP per real account. Creating many fake accounts violates WhatsApp/TikTok Terms."
            else -> "OmniProxy 1.0.0" to "A privacy-focused proxy manager with sticky per-app IPs, failover, a kill switch and leak protection."
        }
        AlertDialog(
            onDismissRequest = { dialog = null }, containerColor = CardBg,
            title = { Text(title, color = TextPrimary) }, text = { Text(body, color = TextSecondary) },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("OK", color = PurpleLight) } }
        )
    }

    if (dialog == "resetlook") AlertDialog(
        onDismissRequest = { dialog = null }, containerColor = CardBg,
        title = { Text("Reset personalization?", color = TextPrimary) },
        text = { Text("Theme, background, liquid button, button, card and navigation styles go back to the defaults. Your saved custom themes are kept.", color = TextSecondary) },
        confirmButton = { TextButton(onClick = { AppearanceStore.resetAll(ctx); dialog = null; message = "Personalization reset." }) { Text("Reset", color = Danger) } },
        dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel", color = TextSecondary) } }
    )

    plan?.let { p ->
        AlertDialog(
            onDismissRequest = { plan = null }, containerColor = CardBg,
            title = { Text("Import this backup?", color = TextPrimary) },
            text = {
                Text("${p.servers.size} server(s) in the file, ${p.newServers.size} new. " +
                    "Servers you already have are kept as they are.\n\nNo passwords are in the file, so you will need to add logins yourself. " +
                    "Nothing connects automatically.", color = TextSecondary)
            },
            confirmButton = {
                TextButton(onClick = { ConfigIO.apply(ctx, p); plan = null; message = "Imported ${p.newServers.size} new server(s)." }) {
                    Text("Import", color = PurpleLight)
                }
            },
            dismissButton = { TextButton(onClick = { plan = null }) { Text("Cancel", color = TextSecondary) } }
        )
    }
}

private fun openNotificationSettings(ctx: Context) {
    try {
        ctx.startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            .putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Exception) {}
}

@Composable private fun Chevron() { Icon(Icons.Filled.ChevronRight, null, tint = TextSecondary) }

@Composable
private fun AppSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    Switch(checked = checked, onCheckedChange = onChange,
        colors = SwitchDefaults.colors(checkedTrackColor = Purple, checkedThumbColor = Color.White,
            uncheckedTrackColor = Border, uncheckedThumbColor = TextSecondary, uncheckedBorderColor = Border))
}

@Composable
private fun GroupTitle(text: String) {
    Text(text, color = TextSecondary, fontSize = 12.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 6.dp, bottom = 8.dp))
}

/** A switch that is shown but can't be turned on yet. */
@Composable
private fun SoonSwitch() {
    Switch(checked = false, onCheckedChange = null, enabled = false,
        colors = SwitchDefaults.colors(disabledUncheckedTrackColor = Border, disabledUncheckedThumbColor = TextSecondary,
            disabledUncheckedBorderColor = Border))
}

@Composable
private fun SettingRow(
    icon: ImageVector, title: String, subtitle: String,
    onClick: (() -> Unit)? = null, trailing: @Composable () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconBadge(icon, PurpleLight, 40.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextPrimary, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = TextSecondary, fontSize = 12.sp)
        }
        trailing()
    }
}
