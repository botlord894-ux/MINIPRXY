# OmniProxy

Privacy-focused Android proxy app: 4 task modes, sticky per-app IPs, DNS-leak protection, kill switch.

> **Use 1 IP per real account.** Creating many fake accounts violates WhatsApp/TikTok Terms.
> This app is for privacy and account stability, not bulk/fake accounts.

## Build (no laptop)
1. Push this repo to GitHub.
2. Open **Actions** → *Build OmniProxy* → run it (or just push).
3. When it's green, open the run and download the **OmniProxy.apk** artifact (a zip containing `app-debug.apk`).
4. Install the APK on your phone (allow "install unknown apps").

## Add your own proxy servers
Open `app/src/main/java/com/omniproxy/app/SmartRouter.kt` and edit the `SERVERS` list:

```kotlin
ProxyServer("My US", "1.2.3.4", 1080, ProxyType.SOCKS5, "US", user = "name", pass = "secret"),
ProxyServer("My UK", "5.6.7.8", 8080, ProxyType.HTTP,   "GB"),
ProxyServer("Compression", "9.9.9.9", 8080, ProxyType.HTTP, "DE", compression = true),
```
- `type`: `HTTP` (CONNECT proxy) or `SOCKS5`.
- `country`: Streaming mode only uses `US`/`GB` servers.
- `compression = true`: the server Data Saver mode uses.
- Remove `user`/`pass` if your proxy has no login.
Commit the change; Actions builds a new APK.

Optional: put a free ipinfo.io token in `StickyRouter.IPINFO_TOKEN`.

## Choose which apps use the proxy (split tunneling)
Apps in the SharedPreferences set `proxy_apps` (file `omni_prefs`) go through the proxy; all others stay direct.
Default: Chrome and Firefox. (An in-app picker is not built yet.)

## Modes
| Mode | What it does |
|---|---|
| Streaming | Fastest US/GB server + AdGuard DNS (ad-block) |
| Banking | No tunnel at all: your real IP is used, on purpose |
| Data Saver | Uses the server marked `compression = true`; MB saved is an **estimate** (~30%) |
| Gaming | Fastest server by ping, live ping every 2 s |

## Sticky sessions (real per-app routing)
Under "Sticky sessions" in the app, each saved IP is a card listing the apps assigned to it
(WhatsApp, TikTok, Instagram, Telegram...). Tap a card to route exactly those apps through that IP
using the built-in tun2socks core (hev-socks5-tunnel, built by GitHub Actions). Tap again to stop.
- Android allows **one VPN at a time**, so only one sticky session (or one mode) runs at once.
  Apps sharing an IP run together; apps on different IPs need separate sessions.
- Sticky sessions need a **SOCKS5** server. HTTP-type servers only work for browsers.
- Task modes (Streaming/Gaming/Data Saver) only route the apps in `proxy_apps` (default Chrome/Firefox),
  never your sticky accounts, so a mode can't change an account's IP.
- `udp = true` on a `ProxyServer` means your server supports SOCKS5 UDP relay (needed for real UDP such as
  games and QUIC). Without it, DNS is resolved remotely through the proxy (no DNS leak) and UDP apps may not work.

## Known limits (read this)
- The tun2socks core is cloned and built fresh from its `main` branch on every build. If a future change
  upstream breaks the build, pin a tag in `.github/workflows/build.yml` (`git clone --branch <tag>`).
- Per-app IPs rely on one session at a time (see above); true simultaneous per-app IPs would need sing-box.
- Streaming's AdGuard DNS only applies if the server has `udp = true`; otherwise names resolve remotely.
- Data Saver's "MB saved" is an estimate (~30% of tunnel bytes) and depends on a real compression proxy.
- The free ipinfo.io API has no blacklist data, so "Banned" only triggers on Tor flags (token needed) or manual marking.
- Nothing here guarantees an account won't be banned.

## Personalization (Theme Studio)
Settings > Theme Studio. Five tabs with a live preview that uses an unsaved draft: Apply saves it, Cancel discards it.
- **Theme:** 10 built-in themes (protected from deletion), your own custom themes (create, rename, duplicate, delete),
  15 editable colors with a picker and HEX input. Text colors are checked for readability automatically.
- **Background:** original, solid, gradient, photo (system photo picker, no storage permission), dark/color overlay, blur,
  animated gradient. Photos are copied into the app's private storage, so they can't disappear; if one is lost the original
  background is shown.
- **Liquid Button:** presets, colors, material, animation, size, and position (center, bottom, top, lower-left/right, or drag).
  The button always shows the real VPN state. Hold it while connecting to cancel.
- **Buttons / Cards & Nav:** shape, radius, height, style, ripple, shadow; card and navigation styling; high contrast and reduced motion.

Everything is stored locally (SharedPreferences) and survives restarts. Reset: each tab has Reset, and Settings > Reset personalization restores the defaults.

Limits: the liquid effect is drawn with Canvas (no AGSL/RuntimeShader), the built-in wallpapers are gradients (no bundled photos),
and none of this has been run on a device by the author. Unit tests cover only the pure color and readability logic.

## Theme Studio reliability updates

- Appearance snapshots are sanitized before persistence, including bounded layout values and allow-listed private-image / bundled-wallpaper references.
- The SharedPreferences JSON now carries a schema version and old snapshots are normalized on load.
- Five offline bundled wallpapers are available from Theme Studio: Midnight, Deep Ocean, Northern Lights, Abstract Glass, and Dark Technology.
- The Privacy Status screen explicitly reports the current upstream transport's TLS status as unknown because the current SOCKS5/HTTP implementation does not expose a verified TLS handshake. HTTPS-to-destination is a separate layer.
- GitHub Actions runs unit tests as a required step before assembling the debug APK.

The bundled wallpapers and UI changes do not establish encrypted proxy transport or per-app concurrent multi-outbound routing. Those require a transport/core integration and real-server/device verification.
